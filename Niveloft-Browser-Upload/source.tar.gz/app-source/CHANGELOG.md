# Changelog

All notable changes, by phase. Dates are when the phase was delivered.

## The avalanche, a roaming Flurry and the workspace in the same weather (2026-09-29)

The front page's look now carries into the app, Flurry roams until it's called, and the ice-brick mark on the front page is replaced by a scattered avalanche that scrolling disciplines into rows of snow on the mountain.

### Front page
- **The avalanche** replaces the ice-brick mark (`three/snowfield.ts`, `three/LoftWorld.ts`). A mountain face with hundreds of snow blocks (one per sample task, 420 on desktop, 220 on phones) tumbling down it in a loose stream with powder billows. Scrolling the first screen disciplines it: blocks fly out of the stream one after another, lowest rows first, and land in ordered rows on the slope, while the scoured, streaked mountain turns to fresh snow. A block is always either in the stream or flying to its row, never left hanging halfway. Hover lifts the nearest blocks and shows their task keys; a click opens the workspace. The camera then climbs the slope into the cloud before the crystals.
- A readout in the corner (*AVALANCHE_01*, *SCATTERED / SETTLING / IN ROWS*, the share in rows) follows the scroll; the scroll hint reads *Scroll to settle the snow*.
- The platform's first shape is now a mountain with its snow laid in rows.
- **Flurry roams the front page**, never landing on the words or controls; clicking it opens its panel. *Keep Flurry still* is in the *Menu*.
- Phones stand further back so the stream stays below the heading, with a little fog behind the heading.

### Flurry
- **It roams** (`features/flurry/roam.ts`, `useFlurryRoam.ts`): rests a few seconds, then flies in a soft, banking arc to another spot along the edges and empty parts of the page. It never lands on the field you're typing in, under the pointer, on open menus, dialogs or notices, or where it just was; it stays clear of the sidebar and the top bar.
- **It notices you:** its eyes follow the pointer; pointing at it or focusing it with the keyboard holds it still, and it looks back (a *curious* expression).
- **Called, it comes:** it flies to the conversation, perches on the card's top edge (or beside it when there's no room above), waves, and stays while it's open; clicking it then takes you to the question box.
- **Out of your way:** it flies off a field you start typing in, holds still while you type, and naps in its home corner after two quiet minutes (new *sleep* expression).
- **Drag it** anywhere: it stays there for half a minute, and the nearest corner becomes its home.
- **Stopping it:** *Let Flurry roam* (⋯ menu and Settings → Flurry), *Keep Flurry still*, *Minimise* and *Hide*; reduced motion stops it automatically. With roaming off it rests in its home corner and steps aside from fields as before. On phones it moves only along the bottom edge.
- The conversation's header shows a small mark instead of a second Flurry while Flurry perches beside it.

### The workspace
- **Weather behind every page** (`components/layout/AppAtmosphere.tsx`): a faint mountain range with its snow in rows along the bottom of the window and light snowfall, behind all content, still under reduced motion, paused in hidden tabs, and switchable in *Settings → Appearance*.
- **Instrument labels:** a `//` trail and a date-and-time stamp in the top bar, `//////` section marks in the sidebar and the assistant, mono eyebrows on page headers, and page titles that decode into place (screen readers get the real title at once).
- **Each project's Overview has its avalanche** (`features/overview/ProjectAvalancheCard.tsx`, `three/ProjectAvalanche.ts`): the project's own tasks as snow on a mountain. Approved work settles into rows in the order it was approved, work in review hovers over its place, the rest is still coming down, and work that holds others up glows amber. Hover a block for its key, title and state; click to open the task. The same information is beside it in words and as a list. It follows statuses only and changes nothing.

### Checks
- New unit tests: the avalanche's settling order and share (`three/snowMath.test.ts`), Flurry's roaming (spots, never under the pointer or on a field, fleeing a field, flights and banking, gaze, perching; `features/flurry/roam.test.ts`) and the project avalanche model (order, blocking, targets, the sentence; `features/overview/avalancheModel.test.ts`).
- The Niveloft browser suite covers the avalanche settling, the front page's Flurry, Flurry roaming, perching, dodging, dragging, roaming off and the rest of its menu, and a new *workspace* part (weather, instrument labels, the project avalanche and its list).

## The front page, as a cinematic journey (2026-09-29)

The front page now looks and moves like the reference video the owner sent: a monochrome 3D world with small monospaced instrument labels, built as Niveloft's own (no name, logo, character, text or brand logos from the reference).

### Added
- **The ridge:** a misty snow ridge with mountains, and the Niveloft mark built from ice bricks, lit from inside, with glowing seams (`three/LoftWorld.ts`). Each brick is a task from the sample project: hovering lifts the nearest bricks and shows their task keys with leader lines; clicking opens the workspace. The promise is the page's heading, in the corner, with one action.
- **The crystals:** a fly-through into a bright void with five faceted ice crystals, one per screen, each with a raised symbol, a label, readings from the sample and *Click to explore*. Each opens a dark summary panel (mono text that brightens under the pointer) with the real thing inside: the sample workspace and the demo sign-in, the role graphs, the forecast playground, Flurry, the questions.
- **The platform:** a ring platform where particles gather into the next step (the mark, Flurry, create, log in, the introduction), with arrows between steps.
- **The instrument frame:** the mark and a *Demo* tag, a *Menu* (sections, pages, search, theme, contact, cookies, legal), *Sound: Off/On*, bracketed controls, decoding labels. IBM Plex Mono is back, for these labels only.
- Deep links (`/#product` and the other sections) open their panels, so site search and the other pages' navigation still land on the right thing.

### Changed
- The earlier ice-sculpture story and the long scrolling sections are replaced by the three places and their panels; all their content is still there, inside the panels.
- New stills, social image and brand guide section.
- Speed: the world is built in two steps (the ridge first, the rest when the browser is idle), its reflection map is small, shaders compile without blocking where possible, phones get lighter materials, and slow hardware drops resolution and then animation.

### Checks
- The Niveloft, polish and calm browser suites were rewritten for the new page; the site-search and FAQ tests understand the crystals' anchors.

## Improvements: delivery forecast first, role graphs, a quieter Flurry and the ice story (2026-09-29)

This release answers two reviews: a hard critique of the product (forecasting, graphs, Flurry, reports, the front page) and a design critique (colour, type, layout, the front page's order). The product is now positioned around one promise: **see what will finish, when, and what’s in the way**, for small software and student teams.

### Flurry
- **AI replies that aren't clean JSON no longer break.** The browser's raw parser error (*Unexpected non-whitespace character after JSON…*) was shown to people. Replies are now read by a balanced-brace scanner that tries each JSON object in the text, falls back to a prose answer when there's no JSON (labelled with a note that the AI didn't use the expected format), and otherwise says in one plain sentence that the reply couldn't be read, with **Try again**. The technical detail goes to the browser console. The backend reads replies the same way (`AiService.parseReply`, with a new test).
- **Small by default.** Flurry rests in a corner as a small figure; opening it shows a compact card (400 px, 520 px for a plan or agenda, at most 640 px tall) instead of a full-height side panel. **Pin** docks it beside the page, and the page makes room. Phones get a full-screen sheet and a small, still button.
- **Corners, never covering fields.** Dragging snaps it to the nearest corner; the menu has *Rest in a corner* for keyboard users. When a field you focus would sit under it, it moves to the opposite corner and comes back after you leave the field. It never pops up on its own and has no speech bubbles; its idle motion is smaller and slower.
- **Greetings and thanks** get a short reply (*Hi Aarav. I’m Flurry…*) instead of a search. New questions: *When will I finish?* (your own forecast) and *Will we make the deadline?* now quote the delivery forecast.
- **It never invents dates.** Dates in an AI answer may only come from the forecast range and scheduler estimate it's given; the range is now part of the prompt (and of the server request, `forecast.range`).
- The owner suggestion in *Review blockers* now says plainly: *a manager can give each one an owner… I won’t assign people for you.*

### Forecasting
- **A delivery forecast leads the Overview and Reports:** the likely finish as a window, the most likely date, the chance of the deadline, what holds it up and the next move, then *remaining work*, *blocked tasks* and *available capacity*, then the timeline, then breakdowns.
- **Three separate answers:** remaining effort, *your* finish (after the work you wait on) and the project's finish. It names the main dependency, the availability assumption, data quality and when the records last changed. *Your time for this project* is a what-if that moves dates, not effort.
- **The engine is dependency-aware:** a Monte Carlo list scheduler where a task starts only when what it waits on is approved, each person does one task at a time and picks up other ready work while waiting, review time is added after submission, and unowned tasks start today (flagged).
- **Calibration is checked, not assumed:** each forecast reports how often its 80% ranges held for finished tasks (leave-one-out), or says there are too few to judge.
- **The plan and the forecast no longer contradict each other:** the scheduler's date is labelled *the plan, if every task takes exactly its estimate*, and the forecast explains why it differs. A health badge that disagrees with the forecast explains itself.
- **Demo data** now has realistic estimates, so its forecast is believable (it had said 0% chance for a project that was on track).
- **No productivity rankings:** the per-person table is labelled as not a ranking, and the Pace tile is replaced by *How good are the ranges?*

### Graphs
- **A 2D work graph is the default** (the chapter is renamed *Graph*): time across, one row per person, recorded work solid, planned work outlined, the forecast as a band, priority as a badge, the Today and Deadline lines, dependencies drawn only for the selected task, and everything else faded while one is selected. Labels stay fixed while time scrolls.
- **A view per role:** a member opens on *What should I work on, and when am I likely to finish?*, a reviewer on *Whose delivery am I blocking?*, an owner or manager on *What threatens delivery, and what change would help?*, a viewer or client on the delivery forecast by milestone.
- Always there: 2D or 3D, a date range, **Show as a list**, **Reset**, and keyboard access (arrow keys, Home, End, Enter, Escape).
- **The 3D model** is quieter: every block has the same height (priority is in the details, never size), matte materials, dependencies only for the selected chain unless you ask for all, a readable default camera, and sentence-case labels.

### Reports and numbers
- Reports open with a compact title row and a project selector, then the forecast, three numbers, the timeline and the breakdowns.
- Progress is **tasks approved** (*N of M*); effort-weighted progress appears only when at least 70% of tasks have estimates.
- **Cycle time** shows its definition, *n*, the median, the middle half and the full range, with a dot strip of every task.
- The project header says *N of M tasks approved* and *X% of the time to the deadline has passed*.

### Design
- **The palette from the design review:** canvas `#F6F7F9`, cards `#FFF`, ink `#17212B`, secondary `#596575`, primary `#245B78`, borders `#DCE3E9`; dark `#10151B` / `#18212B` / `#EDF2F7` / `#A5B2C0` / primary `#A8D8EE` with dark text / `#33404D`.
- **One family, Inter,** with the review's type scale, sentence case everywhere (no uppercase overlines), and tabular figures for keys, tables, dates and metrics. Manrope and IBM Plex Mono are removed.
- Fewer borders and shadows, 12 px card radii, flat primary buttons, no glass behind text. Buttons keep their label in place under the spinner while working. *Saved* notes appear only after a successful save and clear on the next attempt.

### Front page
- **New order:** the promise and one action over a restrained ice sculpture → four short, skippable steps (*Scattered*, *Assembled*, *Timeline*, *Forecast*, where the window, the deadline and the one blocker appear) → the sample workspace → *The same project, a different question for each person* (the four role graphs on the sample) → *Change an assumption. Watch the forecast move.* (three what-ifs, computed in the browser by the app's own engine) → Flurry → questions → a final action.
- The sculpture is built from the sample project's tasks (`IceSculpture.ts`); the alpine scene is removed. New stills, social image and page title and description.
- The navigation is *Product · Views · Forecast*; site search and footer links point at sections that exist (checked by a test and by the browser suite).
- Demo mode stays explicit: a *Demo* badge in the public header and a notice in the app's sidebar that everything stays in this browser.

### Fixed
- Front page role graphs: one-row lanes no longer overlap their labels, task keys aren't truncated before titles, dates don't hide under the Today and Deadline tags, and the delivery view's rows have room for two lines.
- The public footer leaves room for the floating Contact button.

## Niveloft: rebrand, the alpine front page and Flurry (2026-09-29)

ProjectFlow is now **Niveloft** (a working name: availability is still to be checked), *Project workspace for focused teams. Great work. Clear direction.* See [docs/BRAND.md](docs/BRAND.md).

### Added
- **Brand:** the Niveloft palette (snow, white, graphite, slate, ice blue, glacier, frost, glow) in light and dark, Manrope for display, Inter for text and IBM Plex Mono for keys and numbers (all self-hosted), a new mark (three planes: an *n* and a lit shelter) and wordmark (the i's dot is an ice-blue diamond), and regenerated favicons, app icons, manifest and social image. Radii are 8/12/16 px; main buttons are 48 px, everyday ones 40 px (44 px on touch screens).
- **The front page** is a scroll story inside an original alpine scene drawn with three.js: an illuminated glass pavilion, terrace and tower in a snowy valley. The sample project's tasks rearrange in four chapters: Projects, Tasks, Team and Progress. It has:
  - a still of the same scene that shows at once and stays without WebGL;
  - a separate phone composition, fewer particles and no shadow maps on small screens;
  - reduced motion (chapters snap, no snow), rendering paused off screen and in hidden tabs;
  - optional sound, off by default;
  - chapter buttons, a text equivalent for every chapter, and a *Skip the story* path.
  Then: the product preview, *Plan. Assign. Track.*, features, the interactive sample workspace, Flurry, a use case (no invented customers), questions, a closing call to action and a new footer. The header is *Product · How it works · Log in · Explore demo*.
- **The sample workspace**, *Launch the mobile onboarding update*: 17 tasks, 6 people, 3 milestones, a late task that holds others up, a waiting review and two unowned tasks. Board, list and timeline views, a person filter, a task panel with the app's workflow rules, owners, *Reset*, clearly labelled as a sample that saves nothing. The same project is in both demo datasets.
- **Flurry**, the AI project assistant (replaces *Assistant*):
  - **Plan a project:** a brief becomes up to 12 draft tasks (AI) or tasks drafted from the brief's own lines (no AI, labelled), reviewed before anything is created, then created through the normal endpoint with the suggested order as dependencies, with **Undo**. Server: `POST /api/projects/{id}/ai/plan` (needs permission to create tasks; nothing is saved by the endpoint itself).
  - **Summarise progress:** what the records show, what that suggests (estimates) and what the records don't show, kept apart.
  - **Review blockers:** late work that holds other work up, work without an owner, long review waits, each with a next move and *Dismiss*. It never assigns or reschedules.
  - **Meeting agendas** drafted from the records.
  - **Undo** for tasks it created or started.
  - **In the corner of every signed-in page:** drag it anywhere (remembered per person), move left or right from its menu, minimise, hide, sounds (off by default), *Keep Flurry still*, and reduced motion. It thinks, cheers and frowns only in response to what you asked, and settles while you type elsewhere. On phones it's a compact button. **Settings → Flurry** has the same switches.
  - *Ask Flurry* in the sidebar and in ⌘K, with shortcuts for its three abilities.
- **The app's sidebar:** a stable sidebar with the places, active projects, *Ask Flurry*, help, settings and the account menu, and a top bar naming where you are; a drawer on phones and tablets.
- **Tests:** Flurry's reports, plan drafting from a brief, the plan prompt and its validation (browser and server), the new sample project, and a Spring test for the plan endpoint.

### Changed
- Every page, email, API title, policy and FAQ answer says Niveloft. Internal identifiers keep the old name (`dev.projectflow`, the `projectflow` database, `projectflow.*` storage keys, `@projectflow.dev` demo accounts), so existing data and sign-ins keep working.
- *Sign in* is now *Log in*, and *Create account* is *Create your workspace*.
- The masthead is replaced by the sidebar; the old *Assistant* button by Flurry.

### Fixed
- The account and Flurry menus opened off screen near the bottom of the window; they now open upwards.
- The cookie banner covered the sidebar.
- Focus didn't return to the task after closing the sample workspace's panel.
- three.js r186 warnings in the console (the deprecated `Clock` and the removed soft shadow maps).

## Help, contact, forms and the Arena (2026-09-28)

### Added
- **Site search:** `/`, ⌘K or the header's search button on public pages finds FAQ answers, introduction chapters and policy sections as you type, with the matched words highlighted. In the app, ⌘K lists the same answers under *Help*.
- **Questions and answers** (`/faq`): 24 expandable answers in 7 topics, with links to each answer, *Copy link*, *Expand all* / *Collapse all*, a filter, *Print*, *Last updated* and FAQPage structured data. The front page shows five of them.
- **Contact:** a floating *Contact* button on public pages, and *Contact us* in the app's menus and on error messages. Messages are saved for the operators and emailed to `CONTACT_EMAIL` when email is set up. Honeypot, rate limit and optional Turnstile, as on sign-up. A message sent twice is saved once.
- **Site health** (`/site-health`), for accounts listed in `OPERATOR_EMAILS`: form success rates, sign-up sources, contact messages (mark answered), spending against the caps, and a tagged-link builder.
- **Form success rates:** every form reports shown / sent / accepted / refused / failed as daily counts (no contents, no identity).
- **UTM tracking:** campaign tags (or the referring site) are kept for the visit, removed from the address bar and saved with new accounts and contact messages. With analytics consent, Google Analytics gets them on the first page view.
- **The Arena** (`/arena`): two answer sources (the built-in model, the AI in Chrome, and each chat model installed in Ollama on the server) answer the same question about a project blind; you vote, the names are revealed, and a site-wide scoreboard counts the wins. Only the outcome is stored.
- **Server:** `GET /api/ai/models` and a `model` choice when asking about a project; `POST /api/contact`, `POST /api/metrics/forms`, `GET /api/site-health`, `PATCH /api/site-health/contact/{id}`, `POST /api/arena/votes`, `GET /api/arena/scoreboard`; migration V6 (contact messages, sign-up source columns, Arena votes); `operator` on the signed-in user.
- **Scrolling aids:** a reading-progress line and a shadow on the sticky header, a *back to top* button (it also returns focus to the content), and a down arrow on the front page that skips past the 3D preview.
- **Phone menu** for the public pages (pages, search, contact, sign-in, theme).
- **Copy buttons** for FAQ links, task keys, AI drafts, assistant answers, error references and tagged links. They say *Copied* (and announce it), and fall back when the clipboard is blocked.
- **Print stylesheet:** white paper, dark text, no navigation or buttons, answers expanded, link addresses printed, a header with the page and time, and a note in place of 3D scenes. *Print* buttons on FAQ, Reports, project summary, Prediction model and Site health.
- **Last updated** stamps with a refresh button on Today, My work, Projects, Inbox, Reports, the project summary, the Prediction model and Site health.
- **Loading:** a thin progress bar at the top whenever data loads (quick loads show nothing), page-shaped placeholders with a soft shimmer instead of spinners.
- **Password rules** that tick off as you type on sign-up, reset and change password.
- **Error summaries** listing every problem when a form has more than one, each linking to its field; **success panels** and *Saved* notes.
- **Confirmations** before discarding a changed form (and before leaving the page with one), revoking an invitation, removing a dependency, applying a plan and marking many notifications read.
- **Tests:** site search, the FAQ's links and structured data, UTM parsing and clean-up, form counts, Arena pairs, the demo API's new endpoints, and Spring tests for contact, form counts, sign-up sources, Site health access and Arena votes.

### Changed
- **Sticky headers:** a project's chapters and views stay under the masthead while its pages scroll (views scroll away on phones, to leave room).
- **Hover and press states:** every link and button now visibly reacts to the pointer; buttons press down a pixel when clicked.
- **ARIA:** confirmations are `alertdialog`s; menu buttons say whether they're open; icon-only buttons, the search box and progress bars are named; live regions announce copying, saving and results.
- **The built-in model** answers deadline questions ("Will we make the deadline?"): the scheduler's finish against the deadline, and the tasks most likely to be late.
- **Privacy policy** lists contact messages, UTM tags, form counts and Arena votes.

### Fixed
- Ticking a checklist item on a task page emptied the page until it was reloaded (the saved task was put back into the cache through `transformResponse` a second time).

## Prediction model, and running safely under load (2026-09-28)

### Added
- **Prediction model:** a new project chapter (IV), with a 3D chart of each person's progress, grouped by role (owner, manager, member, viewer).
  - History is a staircase of tasks each person got approved, from the project's recorded status changes.
  - The forecast runs 400 simulations of the work that's left. Each one uses that person's own pace against their estimates (shrunk towards the team's pace while there's little history) and the time reviews usually take.
  - It shows the likely finish (p50) and a range (p10 to p90) for each person, each role and the project, and compares them with the deadline.
  - It says what it learned from, and says plainly when no finished task has an estimate yet (so ranges are wide). Pointing at a row in the table below the chart highlights that person's line; the table gives the same numbers to keyboard and screen-reader users.
  - Loading, empty (no tasks, nobody with a role) and failed states each have their own message.
- **Rate limits:** 300 requests a minute per person, 120 per address without sign-in, 60 changes a minute and 60 uploads an hour. Going over answers 429 with `Retry-After`. Each limit is a setting; 0 turns it off.
- **API limits:** JSON bodies up to 512 KB (413 beyond), up to 5,000 tasks per project, 100 projects per person, 200 members per project and 1 GB of evidence per project (422 `LIMIT_REACHED` beyond).
- **Spending caps** for paid services, counted in the database so restarts don't reset them: AI requests a day, AI tokens a month, emails a day and a month. At a cap, AI answers say so and emails are skipped and logged, so nothing is charged beyond it.
- **No duplicates:** every create and submit from the app carries an `Idempotency-Key`. A retried request gets the first answer back (`Idempotent-Replayed: true`); one still running gets 409; the same key with a different body gets 422. Submitting work also locks the task, so a double click or two tabs make one submission. (ProjectFlow has no payments or subscriptions, so there were none to protect.)
- **Request ids:** every response has `X-Request-Id`, every log line carries it, and error messages show it as a reference.
- **Browser error reports:** crashes and unhandled errors in the browser are sent to `/api/client-errors` and logged (message and page only, no personal data; rate-limited). The privacy page says so.
- **Offline banner** when the browser loses its connection.
- **Database indexes** (migration V5) for notifications by person and type, tasks and milestones by due date, submissions by status, invitations, sign-in tokens and files.
- **Uptime monitoring:** `.github/workflows/uptime.yml` checks the frontend and the backend's readiness every 15 minutes (set `FRONTEND_URL` and `BACKEND_URL` as repository variables). Railway uses `backend/railway.json` to wait for readiness before switching traffic and to restart on failure.
- **Scripts:** `scripts/load-test.mjs` (simultaneous users, with a race check), `scripts/backup.sh`, `scripts/restore.sh` and `scripts/test-backup-restore.sh` (backs up, restores into a scratch database and compares every table).
- **Tests:** retried creates happen once, ten simultaneous submits make one submission, request ids, oversized bodies, error reports, usage counters, rate limits and quotas.

### Changed
- **Timeouts and retries:** requests from the app time out after 20 s (uploads 2 min, AI 200 s). Reads and keyed writes are retried twice on network errors, 502, 503, 504 and 429 (waiting as long as `Retry-After` asks, up to 10 s). AI requests are never retried.
- **Server timeouts:** 20 s for a slow client, 10 s to get a database connection, 15 s for a query, 30 s for a transaction. Running out of any of these answers 503 "busy, try again" instead of hanging. Shutdown finishes the requests in flight.
- **Faster queries:** notifications are filtered and paged by the database; the projects list loads tasks and member counts only for the page shown; *My work* loads only your tasks. Page sizes are capped (100 for lists, 500 for board tasks).
- **Cache:** project analytics and status history are cached per project and cleared as soon as anything in that project changes.
- **Uploads:** a failed submission deletes the files it uploaded.
- **Error messages** for 429, offline, timeouts, limits and caps say what happened and what to do.

## A working AI assistant, free (2026-09-28)

### Added
- **Ollama, found automatically:** the new default is `AI_PROVIDER=auto`. When a free Ollama model runs on the same computer as the backend, it's used with no keys or settings.
  - It picks a good chat model (llama3.2 first) and skips embedding models, or uses `AI_MODEL`.
  - It looks again every few seconds while nothing's found, so Ollama can start after the backend.
  - It talks to Ollama's own API, with JSON output and an 8,000-token context, so a whole project fits.
- **`scripts/setup-local-ai.sh`:** installs Ollama (Homebrew), starts it, downloads llama3.2 and checks it answers.
- **The AI built into Chrome:** with no server AI, the assistant offers *Turn on AI in this browser*. Chrome downloads Gemini Nano once, then answers run on the device, from the records the page already has.
  - The same rules as the server's AI apply: records marked as data, invented task keys dropped, suggestions checked and confirmed by a person.
  - When a project is too big, the prompt is cut down to fit, or it says the project doesn't fit.
  - It works in the Assistant panel and in the Model page's *Ask about this project*, and in demo mode too.

### Changed
- **Free questions** go to the server's AI, else the AI in Chrome, else the built-in model. Every answer says which one wrote it.
- **"No AI" messages** now say how to turn AI on for free, instead of only naming settings.

## Calm and organised: built-in model, free AI, roles, tidy pop-ups (2026-09-27)

### Added
- **Built-in model:** answers free questions without an AI service. It's trained in the browser, each time you ask, on that project's records:
  - each person's pace against their estimates;
  - a lateness model (logistic regression, with its accuracy measured on tasks it didn't see);
  - a search index over the records.
  Answers say what it learned from and how accurate it was, and are labelled *Built-in model · no AI service*.
- **Free AI providers:** `AI_PROVIDER=openai` works with any OpenAI-compatible service, including Ollama on your computer (no key) and the free tiers of Groq and Gemini. Claude stays available with `anthropic`.
- **"How will you use ProjectFlow?"** on the front page and the sign-up form. It sets the start page and a *Your first steps* card on Today, with steps ticked automatically when the records prove them. In demo mode it signs you in as the sample person with that role. It never grants permissions.
- **Roles guide:** *You: Owner* in every project header opens what each role can do, and what an assignee is. The Team card has *Roles explained*.
- **Pop-up lists:**
  - The Overview's To Do, In Progress, In Review, Done and Overdue counts open their tasks in a pop-up, grouped by person, due date or priority. Every row uses the same columns and the same order.
  - Each board column has a *Show as a grouped list* button that opens the same pop-up.

### Changed
- **Light theme:** cool neutral greys and one blue accent replace the stone-and-bronze palette. Cards have soft corners and a faint lift. Buttons use sentence case. Display type is light rather than extra-light. Dark mode matches, and every text colour still meets WCAG AA. The favicon, app icons and social image were regenerated.
- **Overview:** laid out on a strict grid of six equal cards, each previewing at most four rows with a *View all* bar in the same place, opening the rest in a pop-up.
- **Board messages** name the assignee: *Only Priya Nair, the assignee, can submit this task*.
- **Sign-in** goes to the start page for how you said you'd work (for example, My tasks for "I do the work"), unless a link asked for somewhere else.

## Launch-ready: real accounts, emails, legal pages, SEO and audits (2026-09-27)

### Added
- **Real accounts and email:**
  - sign-up with email confirmation;
  - a sign-in alert on every sign-in;
  - forgot password, and reset password (which signs out everywhere);
  - a "password changed" email;
  - emails sent through Resend's HTTPS API (or written to the log for local testing);
  - a new migration: V4 (confirmed email, accepted terms, session version, emailed-link tokens).
- **Bot protection:** a honeypot field, limits per IP address and per account (sign-in counts only failures), and optional Cloudflare Turnstile.
- **Pages:**
  - privacy policy (`/privacy`) and terms (`/terms`), with an "I agree" box on sign-up;
  - a custom 404, served with a real 404 status;
  - check-email, confirm-email, forgot-password and reset-password pages.
- **Cookie consent and analytics:**
  - a banner with equal yes/no, and *Cookie settings* in the footer and in Settings;
  - Vercel Web Analytics and/or GA4, loaded only after consent, with ids and tokens removed from addresses.
- **SEO:**
  - per-page titles, descriptions, canonical links and social-preview tags, also written into static HTML per public page;
  - `noindex` on signed-in pages;
  - sitemap.xml and robots.txt, generated at build time.
- **Social preview image and favicon set:** a 1200×630 image from a real frame of the 3D model; SVG with a dark-tab variant, ICO, Apple touch and app icons, and a web manifest.
- **Security headers and HTTPS:** a Content-Security-Policy and other security headers, HSTS, and a backend HTTPS redirect (`REQUIRE_HTTPS`).

### Changed
- **One call to action on the front page:** *Create your free account*.
- **Colours:** lightest grey, muted grey, warning amber and the wordmark now meet WCAG AA contrast in both themes.
- **Grids** without explicit columns can shrink, so nothing makes a phone page scroll sideways.
- **Tap targets:** bigger footer links, contents links and model checkboxes.
- **3D exhibits** on public pages load once the browser is idle.
- **Sample evidence links** use the reserved `.example` domain.

### Fixed
- **After sign-up**, new accounts sometimes landed on Today instead of the introduction: two redirects raced. Sign-in and sign-up now make one redirect.

### Security
- **Secrets:**
  - the backend refuses to start with the public default `JWT_SECRET` against a non-local database;
  - `vite build` fails if the bundle contains a secret key, or (with the real backend) the demo data;
  - the build refuses an `http://` API address.
- **Sessions:** tokens carry a session version; a password reset or change ends every other session.
- **Emailed links** are single-use (even when clicked twice at once), stored as SHA-256 hashes, and removed from the address bar once read.
- **Password reset and change** retire every older emailed link and close the account's live-update streams.
- **Confirming an email** doesn't sign in, so an address registered by someone else can't be taken over.
- **Sign-in limits** count only wrong passwords, per address and per account-and-address. There's no account-wide lockout that could be used against someone. IPv6 addresses are limited per /64 network.
- **Passwords over 72 bytes** get a clear message instead of a server error.
- **After a password change in one tab**, other tabs adopt the new session instead of signing the first tab out.
- **Google Analytics**' automatic events carry the redacted address too.
- **Names** are left out of confirmation and reset emails.

## Ready to host (2026-09-26)

### Added
- **Hosting files:**
  - `backend/Dockerfile` (a Java 21 container, running as a non-root user) and `.dockerignore`;
  - `frontend/vercel.json`, so app routes work on refresh;
  - a *Deploy it* section in the README listing every setting.

### Changed
- **Port:** the backend listens on the host's `PORT` when one is set (`SERVER_PORT` still wins).

### Fixed
- **False "backend isn't running" warning on a hosted site:** when the frontend and backend are on different addresses, the sign-in page's health check was blocked by CORS. `/actuator/health` now allows the configured origins.
- **Hosted wording:** the sign-in warning no longer gives local terminal commands when the backend is hosted.

## The assistant, with voice; the graph moves inside the app (2026-09-26)

### Added
- **Assistant:** an *Assistant* button on every signed-in page, plus Alt+A and the ⌘K palette, opens a side panel for the current or chosen project.
- **Predictive analysis:** forecast, risks, recent changes and "what should I work on next" are computed from the records and labelled *no AI*. Other questions go to the AI when a provider is configured, or get an honest "needs AI" reply.
- **Task management by command:** "Create a task … due Friday, high priority, assign it to Rohan" becomes a draft that opens the normal task form, filled in. "Start LIB-8" becomes a confirm button, and "Open LIB-8" or "Show the 3D model" navigate. Everything goes through the usual endpoints and permission checks, and nothing changes without a click.
- **AI suggestions:** AI answers may carry suggested actions (*create task*, *start task*). The server keeps only those two types and only real task keys, and shows them as the same confirm cards (also under *Ask about this project* on the Model page).
- **Voice:** push-to-talk, an optional "Hey ProjectFlow" wake phrase and answers read aloud, using the browser's speech recognition and synthesis.
  - The wake phrase is off by default, remembered per user on this browser, and listens only while the tab is visible.
  - The Assistant button and the panel header show whether it's listening now or paused. If the microphone is blocked or the speech service keeps stopping, it switches off and says why.
  - The panel says where audio goes.
  - Voice can prepare a change but never confirm one.
- **Keyboard and focus:** Alt+A opens the panel, moves into it when it's open, and closes it from inside (when the text box is empty). Focus returns to the Assistant button on close. The conversation is kept while the panel is closed.
- **Overview graph:** a *History and forecast* card on each project's Overview, with the graph and the analysis lines that need attention, linking to the 3D model.

### Changed
- **Front page:** keeps a small 3D preview of the sample project. The history-and-forecast graph, analysis and assistant are inside the app only; the sign-in and introduction exhibits no longer show the graph.
- **Model and Overview pages:** now share one hook for building the model (cached queries).
- **Task form:** can start from a draft (title, description, priority, due date, assignee, estimate).

## Front page, introduction, sign-in, history-and-forecast graph and AI assistant (2026-09-26)

### Added
- **Front page (`/`):**
  - a live exhibit of a fictional sample project, using the same 3D model, camera views, replay, graph and analysis as a real project;
  - three ideas, how work moves, a roles table computed from the permission rules, and everything inside the app.
- **Introduction (`/introduction`):** nine short chapters with a sticky index, including an interactive life of a task, how to read the model and forecast, and what the AI assistant can and can't do. New accounts land here unless an invitation link sent them elsewhere.
- **Sign-in and registration:**
  - redesigned under the public header;
  - on large screens, the sample project (sign-in) or the four-stage sculpture (registration);
  - *Keep me signed in* (off keeps the session in this tab only);
  - a Caps Lock warning;
  - sample accounts, shown in demo mode, or with the backend when `VITE_SHOW_SAMPLE_ACCOUNTS=true`.
- **History and forecast graph:** on every project's Model page, under the 3D model. It shows all tasks and approved tasks day by day, recorded up to today and dashed as an estimate after it. It's synced with the replay (click or drag to scrub), with a table of the numbers.
- **Analysis:** beside the model, computed from records and marked *Recorded* or *Estimate*, with the tone in words as well as colour. It covers:
  - the estimated finish against the deadline;
  - open tasks without an estimate (the forecast assumes 1 day each and says so);
  - overdue work and what it holds up;
  - reviews waiting and rework;
  - open tasks per person, listed alphabetically with no ranking.
- **AI assistant:** *Ask about this project*, backed by `POST /api/projects/{id}/ai/ask`.
  - Any member may ask; the server checks membership before gathering the project's records.
  - The page's scheduler estimate is sent along, filtered to the project's own task keys and labelled as an estimate.
  - Answers cite task keys (invented keys are dropped) and list what the records don't show.
  - With no provider configured it says it's unavailable, in demo mode too.

### Changed
- **AI prompts:** user-written text is escaped so it can't close its `<record>` wrapper.
- **Hourly AI limit:** a request counts once the provider replies, even if the reply is unusable; only transport failures are refunded.
- **Long answers:** trimmed so follow-up questions stay within the history limit.
- **Calendar days in the model:** rounded, so due dates don't shift by a day across daylight-saving changes.
- **Touch scrolling:** 3D views embedded in pages (the sample project, the sculpture, the skyline) leave touch scrolling to the page and don't zoom on the mouse wheel.
- **Sign-in on phones:** the exhibit isn't mounted at all, so no three.js download or WebGL.
- **Camera fitting:** the camera centres the model's projection.

## Fix: backend compile error, and run instructions that survive copy and paste (2026-09-26)

- **Backend didn't compile:** `GlobalExceptionHandler` imported `MissingServletRequestPartException` from `org.springframework.web.bind`; it lives in `org.springframework.web.multipart.support`.
- **Why it slipped through:** earlier compile checks used hand-written stand-ins for the Spring APIs, and they had the same mistake.
- **New checks:**
  - The backend (main and tests) is now compiled against the real source code of every library, at the versions Spring Boot 3.5.16 selects. It reports 0 errors.
  - Repository query method names, JPQL queries and entity column names are checked against the entities and migrations.
  - The frontend is type-checked against the libraries' real types. It reports 0 errors, and every imported lucide icon exists in 0.525.
- **README commands:** the command blocks no longer have `# comments` after commands. The macOS terminal (zsh) passes them to the command as arguments, so `npm install  # first time only` failed with `EINVALIDTAGNAME "#"`, and the dev server then couldn't find `@tailwindcss/vite`. Troubleshooting now covers both errors.
- **Changelog:** entries are back in date order.

## Redesign: a project you can walk around (2026-09-26)

Answers the design review in [docs/DESIGN_REVIEW.md](docs/DESIGN_REVIEW.md); the spec is [docs/REDESIGN.md](docs/REDESIGN.md).

### Added
- **Project Model** (chapter III, `/projects/:id/model`): a three.js model built from the project's records.
  - Layout: time runs left to right, one lane per person, and height is priority. Materials are stone, graphite, amber and bronze (approved). Dependency threads, a glass Today plane, milestone obelisks and the deadline are drawn in.
  - Replay: a scrubber rebuilds any day from the recorded status history; past today, scheduler estimates show as labelled ghosts.
  - Controls: camera presets (Overview, Plan, Elevation, Today), toggles, hover details, and a selection panel that highlights what the task waits on and what it unblocks.
  - Keyboard: full keyboard navigation with screen-reader announcements.
- **Portfolio Skyline** on Today: one tower per project, layered by status, with a red sleeve for overdue work, synchronised with a text list.
- **Flow Sculpture** on sign-in and registration: four stages as an interactive sculpture, with the stage names as real text.
- `GET /api/projects/{id}/history` (members only) and the same route in the demo API: every recorded status change, oldest first (time, then id).
- Project cards show a small **tower glyph** of their tasks instead of a coloured letter tile.
- Tests: the 3D model's geometry and replay logic, history ordering and access (backend and demo API).

### Changed
- **Navigation:** the sidebar and top bar are replaced by a typographic **masthead** with five places, and by a full-screen numbered index on phones. Projects have six numbered **chapters** instead of eleven tabs.
- **Today** (formerly Mission Control): the stat tiles, trend chart, project list and activity feed are gone; it's now the skyline, the decisions list, and up next, proven done and next three weeks. *My tasks* is now *My work* and *Analytics* is now *Reports*.
- **Loading:** pages load on demand; three.js only downloads with a 3D view.
- **Autofill:** autofilled inputs keep the app's colours (fixes the blue-grey fields in the registration screenshot).
- **Timeline:** month names no longer run together, and the Today/Deadline labels have their own row.
- **Demo indicator:** the badge by the wordmark no longer repeats as a live-status "Demo".

### Dependencies
- `three` ~0.186.0 and `@types/three` ~0.186.0. Run `npm install` in `frontend` after updating.

## Diagnostics for a backend that isn't reachable (2026-09-26)

- When Spring Boot isn't running, the Vite dev proxy now answers with the API's error shape (`503 BACKEND_UNAVAILABLE`) and a message saying how to start it, instead of an empty 500 that the app could only report as "The server ran into a problem".
- Sign-in and registration pages check `/actuator/health` in backend mode and show what to do if the backend is down or reports `DOWN` (usually MySQL); the notice clears itself once the backend answers.
- A 5xx without details now points to the backend terminal.
- README: *Troubleshooting* table for the common start-up failures.
- Verification: the backend **tests** now also compile against API stubs (main and test sources, 0 errors).

## Review fixes after Phases 2–6 (2026-09-26)

An independent read-through of Phases 2–6 found the issues below; all are fixed.

- **Plan apply stale check covers the whole basis.** The request now carries every open task's version and every dependency id the scenario used (`basis`); if any task was edited, added, finished or deleted, or a dependency changed, nothing is applied (`409 EDIT_CONFLICT`). Previously only the changed tasks were checked. Mock API matches; tests extended.
- **Plan page:** a rejected apply no longer refetches and silently recalculates the scenario; *Recalculate with the latest data* is the only way to clear the stale state. Fixed a TypeScript narrowing error in the scenario builder that would have failed `tsc -b`. The scenario tile no longer turns grey.
- **Per-project page state** (saved plan scenarios) can no longer carry over between projects when navigating back/forward.
- **Dependencies:** concurrent "A waits on B" and "B waits on A" requests can no longer both pass the loop check (row lock on the project). Deleting a dependency you can't access returns 404, the same as an unknown id.
- **Live updates:** removed members and everyone in a deleted project are now told to drop it; SSE timeouts and disconnects are closed quietly instead of logging errors; per-user ticket cap; member lookups are cached briefly so a large plan apply doesn't query once per event.
- **AI:** the provider call no longer holds a database connection (the prompt is built in a short read-only transaction first); a failed provider call no longer uses up the caller's hourly quota.
- **Timeline:** the *Today* and *Deadline* labels were hidden under the sticky header; they now sit in the header and are in the legend. Copy no longer says there are no estimates.
- **Dependency map:** no longer re-scrolls on every click and background refresh.
- **⌘K palette:** Enter can no longer open a result for the previous search text.
- **Task form:** server errors for the estimate now appear on the estimate field; an invalid estimate on the task page is reset to the saved value.

## Phase 6 — Live updates, accessibility and verification

- **Server-Sent Events** (`GET /api/events/stream`) with one-time tickets (`POST /api/events/ticket`, 60 s) because `EventSource` can't send a bearer token. Events are sent after commit, only to current project members, and carry ids only; clients refetch through the normal authorised endpoints. Automatic reconnect with back-off; demo mode syncs across tabs through storage events.
- Contrast and reduced-motion fixes across the new pages.

## Phase 5 — Event-based analytics and focused AI

- Analytics from recorded events: work in each status over time (from `task_status_events`), review turnaround (median hours to review), rework rate and rounds to approval, median time in each status. Workload is shown alphabetically; people are never ranked.
- **AI assistance (optional, server-side):** review notes per criterion with a draft of feedback, acceptance-criteria suggestions, and a draft project status update. Keys stay on the server; context is limited to records the caller can see; the model is told it cannot open links or files and every answer lists its limits; nothing is saved or applied without a person choosing to. With no provider configured every AI endpoint returns `503 AI_UNAVAILABLE` and the UI says so — no simulated answers. Per-user hourly limit.

## Phase 4 — Estimates and the what-if planner

- Optional estimates in working days on tasks (`V3__task_estimates.sql`), always labelled as estimates.
- **Plan** tab: a deterministic scheduler (working days, dependencies, one task at a time per person) projects finish dates. Build a scenario — reassign, re-estimate, add time off — compare it with the current projection, then apply the resulting changes in one transaction (owners/managers). People whose dates move are notified with the reason.

## Phases 2–3 — Mission Control, search, calendar agenda, dependencies, map, timeline

- **Mission Control** dashboard: "what needs attention", each item with the rule that raised it and the records behind it (reviews waiting, changes requested, overdue, due soon and not started, own work awaiting review, project and milestone risk, workload, unassigned work due soon, blocked and blocking tasks); recently approved work with its evidence.
- **⌘K / Ctrl K command palette:** pages, commands and server-side search over the projects and tasks you can access (`GET /api/search`).
- **Calendar agenda view** with *Hide completed*.
- **Dependencies** (`V2__task_dependencies.sql`): finish-to-start, same project only, loops rejected with the chain that would close them; blocked/blocking shown on cards, task pages and Mission Control. Demo data includes overdue blockers (CCP-10, MBA-4).
- **Map** tab: interactive dependency graph (layered, keyboard-focusable, upstream/downstream highlighting) plus an equivalent list view. It shows the longest chain of open tasks counted in tasks and explicitly doesn't call it a critical path.
- **Timeline** tab: tasks grouped by milestone on a date axis with a Today rule and the project deadline, drawn from recorded dates only.

## Phase 1 — Backend, persistence, permissions and the review workflow (2026-09-26)

### Added — backend (`backend/`, new)
- Spring Boot 3.5.16 / Java 21 application with Flyway (`V1__initial_schema.sql`) on MySQL 8.4, `docker-compose.yml` for local MySQL, `.env.example` without secrets, Maven Wrapper.
- Stateless JWT auth (jjwt 0.12.7, BCrypt), consistent `{success, message, data, timestamp}` envelope and `{success:false, status, code, …}` errors.
- Per-project roles enforced on the server: `@PreAuthorize("@projectAccess…")` on every project/task route, then role rules in services (`Permissions`).
- Every endpoint the frontend uses: auth, profile, dashboard, calendar, projects, members, invitations, milestones, tasks (list/filter/sort/paginate, board moves with fractional ordering), comments, notifications, activity, analytics.
- **Acceptance criteria and checklists** on tasks; criteria are snapshotted into each submission.
- **Evidence-based submissions**: typed evidence (repository, deployment, link, screenshot, file), multipart upload to local storage, member-only download at `GET /api/files/{id}` (`nosniff`, inline only for safe image types).
- **Criteria-based review**: approval requires every criterion marked met; changes requested requires feedback; nobody reviews their own work; In Review/Done are unreachable by drag or direct status calls; all versions and reviews are kept.
- Optimistic locking (`@Version` + client version) → `409 EDIT_CONFLICT`.
- `task_status_events` history used for cycle time; first-time approval rate.
- Demo data seeder (empty database only) with overdue work, review revisions (CCP-5, CCP-13, MBA-3), workload imbalance and completed milestones.
- MockMvc integration tests on H2 (MySQL mode): role boundaries, approval bypass, submission preconditions, full request-changes → resubmit → approve cycle, own-review block, evidence access, edit conflicts.
- Swagger UI at `/swagger-ui.html`.

### Added — frontend
- **Review workspace** (`/projects/:id/tasks/:taskId/review`): evidence on the left, per-criterion Met/Not met verdicts and feedback on the right, version switcher, "what was asked in the previous version".
- **Definition of done** card on tasks: editable acceptance criteria and checklist, locked in review/done.
- Submit dialog rebuilt around evidence: repository and deployment fields, extra links, screenshots with previews, checklist blockers you can tick in place, the criteria the reviewer will check.
- Authorised file previews/downloads (token-bearing fetch → object URL).
- Acceptance criteria on task creation (one per line).
- `EDIT_CONFLICT` handling with a reload action.

### Changed
- Frontend dev server moved to **port 5174**; backend mode calls same-origin `/api` through a Vite proxy to `localhost:8080`.
- API contract: `Submission.links/attachments` replaced by `criteria` + typed `evidence`; `Review.results`; `Task.acceptanceCriteria/checklist/version/startedAt`; `ProjectDetail.version`; new activity types and `EDIT_CONFLICT`.
- Board drops that mean "review" now open the review workspace instead of a dialog (the old `ReviewDialog` was removed).
- Analytics: cycle time measured from first start (not creation) to approval; "first-time approval" is the share of reviewed tasks approved on their first submission.
- Demo (mock) API brought to parity with the backend; stored schema bumped to v3 (older browser data is reseeded).
- Visual direction changed to a "gallery" catalogue look: stone canvas, square white panels, thin display type, tracked capitals for navigation and buttons, a single bronze accent.

### Verification
- Ran: TypeScript syntax parse of all frontend sources (0 errors).
- Not run (no registry access in the build sandbox): `./mvnw verify`, `npm run typecheck`, `npm run lint`, `npm test`, `npm run build`, and the manual demo flow. See README → *Verify locally*.

## Phase 0 — Frontend with in-browser mock API

- Complete React frontend (projects, board, list, task detail, comments, notifications, milestones, calendar, analytics) running against an in-browser mock API.
