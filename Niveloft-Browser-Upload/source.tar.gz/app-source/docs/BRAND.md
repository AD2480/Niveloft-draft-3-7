# Niveloft brand guide

> **Working name.** "Niveloft" hasn't been checked for trademark, domain or social-handle availability. Do that before any public launch. Internal identifiers (the `dev.projectflow` Java package, the `projectflow` database, `projectflow.*` storage keys, `@projectflow.dev` demo accounts) keep the original name on purpose.

## The idea

**See what will finish, when, and what’s in the way.**

Niveloft is for small software and student teams who share work and reviews. It gives their work a home and answers the questions a team actually asks about delivery: what will finish, when, and what is holding it up. The picture behind it is a loft built of ice on a misty ridge: every block a task, lit from inside, in a cinematic, monochrome world read through quiet instrument labels.

| | |
| --- | --- |
| **Name** | Niveloft (from *nivel*, snow and level, and *loft*, a place up high to work in) |
| **Promise (headline)** | See what will finish, when, and what’s in the way. |
| **Descriptor** | Project workspace for focused teams. |
| **Audience line** | Built for small software and student teams who share work and reviews. |
| **Spelling** | Always *Niveloft* (*niveloft* in the wordmark). Artwork that says anything else, such as the ice render spelling "NIVELOGT", isn't used until it's corrected. |
| **The assistant** | Flurry. Its calls to action are *Ask Flurry* and *Find your next move.* |

### Voice

- Plain, calm and specific. Say what happens, in the order it happens.
- Name the thing, not the feeling: "2 open tasks have no owner", not "Some things might need attention!"
- Never overclaim. Estimates are called estimates. What isn't recorded is "not in the records", never a finding.
- No invented customers, testimonials, logos or numbers. Examples are labelled as samples.
- Buttons are verbs: *Explore the demo*, *Create your workspace*, *Log in*, *Ask Flurry*.
- Sentence case everywhere, including labels and overlines. No all-caps text.
- Forecasts are windows, not dates: *likely 14–21 Oct*, with the chance of the deadline and what it assumes. Never rank people.

## Colour

Light mode is the signature: a pale cool canvas, white cards, graphite ink and one deep ice blue for primary actions and interaction. Fewer borders; colour carries meaning, not decoration.

| Token | Light | Dark | Role |
| --- | --- | --- | --- |
| Canvas | `#F6F7F9` | `#10151B` | Page background |
| Surface | `#FFFFFF` | `#18212B` | Cards, panels, inputs |
| Ink | `#17212B` | `#EDF2F7` | Text |
| Secondary | `#596575` | `#A5B2C0` | Secondary text (≥ 4.5:1 on every surface) |
| Primary | `#245B78` | `#A8D8EE` (with dark text) | Primary buttons, links, focus rings, the active place, the fold of the logo |
| Border | `#DCE3E9` | `#33404D` | Lines, used sparingly |
| Glacier / Frost | `#DCE7ED` / `#A9CEDF` | `#1D2A33` / `#5F8EA6` | Decorative fills and lines only |
| Glow | `#E9C99A` | `#E9C99A` | The one warm highlight: the blocking task in the front page's forecast. Never text. |

Rules:
- Components use the semantic tokens (`bg-surface`, `text-muted`, `border-line`, `text-accent`, `bg-brand`), never raw palette colours for chrome. The tokens live in `frontend/src/index.css`.
- Primary buttons are flat: no gradients, no glow, and almost no shadow. No glass or blur behind text.
- Decorative colours (glacier, frost, glow) never carry text or status.
- Status colours (success, warning, danger, info) and the chart and 3D model colours are separate from the brand palette, and were checked for contrast (WCAG 2.2 AA) and colour-blind separation.

## Type

**Inter** (variable, `@fontsource-variable/inter`) for the product and for headlines everywhere except the front page's world. **IBM Plex Mono** (400 and 500, `@fontsource/ibm-plex-mono`) for the front page's instrument labels only: section marks, readings, bracketed controls and the summary panels. Both are SIL Open Font License and self-hosted, so no font request leaves the site. Code uses the system monospace.

| Level | Size | Weight |
| --- | --- | --- |
| Front page heading (mono, in the corner, like the video's manifesto) | 17–19 px | Medium |
| Front page panels: title / body | 22–26 px / 14 px, line height 1.75 | Medium / Regular |
| App page title | 28–32 px | SemiBold |
| Section title | 18–20 px | SemiBold |
| Body | 14–16 px | Regular |
| Labels and captions | 11–13 px | Medium |

- Sentence case, except the crystal names and readings, which are set in capitals like instrument readings.
- Tabular figures wherever numbers are compared: task keys, tables, dates and metrics.
- The instrument language: `//////` marks a section (*////// Manifesto*, *////// Summary*), `///` a sub-section, and controls sit in bracket corners (*[ Close ]*, *[ Explore the demo ]*). Readings are real figures from the sample, never invented telemetry.

## Logo

**The mark** is three planes that read as a lowercase *n* and as a lit shelter seen from the valley: a left wall, a folded roof plane running down to the right, and a shorter right wall, with light falling between. The fold is ice blue; the walls are ink. Paths are in `frontend/src/components/layout/Logo.tsx` (`MARK_PATHS`, 32 × 32 grid).

**The wordmark** is *niveloft* in Inter SemiBold, lowercase, tight. Its one distinctive detail: the i's dot is a small ice-blue diamond, a lit window.

| Variant | Use |
| --- | --- |
| Mark + wordmark | Headers, footers, emails |
| Mark alone | Favicon, app icons, the collapsed sidebar, social avatars |
| Inverted | Always-dark backgrounds: snow walls, frost fold |
| Mono | One-colour print and embossing |

Keep clear space of one wall-width around the mark. Don't recolour the fold outside the palette, add effects, or set the wordmark in another face.

Generated files: `public/favicon.svg` (switches with the system theme), `favicon.ico`, `apple-touch-icon.png`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png` and `og-image.png` (1200 × 630, the headline beside a frame of the front page's ice sculpture).

## Shape and layout

- **Spacing:** an 8 px grid.
- **Radii:** 8 px for inputs and small controls, 12 px for cards, menus and panels. Pills are fully round.
- **Buttons:** primary is ice blue with white text (pale blue with dark text in the dark theme); secondary is white with a line; quiet is text only. Main actions are 48 px tall; everyday buttons are 40 px with a mouse and 44 px on touch screens. While a button works, its label keeps its place under a spinner, so nothing jumps.
- **Width:** public pages up to 1280 px; the app up to 1440 px beside a 256 px sidebar.
- **Shadows:** minimal. Cards have none; only floating things (menus, Flurry's card) lift slightly.
- **Focus:** a 2 px ice-blue ring, always visible for keyboard users.
- **Saved indicators** appear only after a save succeeded, and disappear when you try again.

## The front page

A journey in three places (`frontend/src/three/LoftWorld.ts`, `frontend/src/features/public/loft/`), cinematic and monochrome, in the style of the reference the owner supplied, but Niveloft's own: its name, logo, character, text and brand logos aren't used.

1. **The mountain.** A misty mountain face with an avalanche coming down it: snow blocks, one per task from the sample project, tumbling in a scattered stream with powder around them; their seams glow. Scrolling disciplines it: block after block lands in ordered rows on the slope, lowest rows first, and the scoured mountain turns to fresh snow. Work arrives as an avalanche; Niveloft lays it down in order. The pointer lifts the nearest blocks and shows their task keys; a click opens the workspace. The promise is the page's heading, in the corner, with one action.
2. **The crystals.** The camera climbs the slope into the cloud, whites out, and comes out in a bright void: five ice crystals, one per screen, each with its symbol raised on its face (a board, rows in time, a window with its likely point, a snowflake, a question mark), a label with a leader line, real readings and *Click to explore*. Each opens a dark summary panel: the text brightens under the pointer, and the real thing sits below it.
3. **The platform.** A ring platform under a ring of light, where particles gather into the next step's shape: a mountain with its snow in rows, Flurry, a plus, a door, a book.

Requirements it keeps:
- The words are ordinary page content; the world is decoration (`aria-hidden`) behind them. Every crystal is a real button; the menu reaches everything; deep links open panels.
- A still (`public/home/loft-{light,dark}-{wide,tall}.webp`) shows at once and stays without WebGL.
- Reduced motion jumps between places. Rendering pauses off screen, in hidden tabs and while a panel is open. Slow hardware gets a lower resolution, then a world that only redraws on change.
- Sound (wind, a glassy tick when the snow is touched, a chime between places) is off until turned on.
- Light theme: overcast day, dark ink labels. Dark theme: night, pale labels. Panels and the menu are always dark.

## Flurry

**Flurry** is Niveloft's AI project assistant: a small floating snow creature with graphite eyes, tiny arms, a swept snow tuft and an ice-blue glow. The detailed artwork (`docs/brand/flurry-source.png`, published as `public/flurry/flurry-*.webp`) is for marketing; the app uses a light vector version (`FlurryFigure.tsx`) that's sharp at any size and cheap to animate.

| Expression | When |
| --- | --- |
| Idle | Floats gently and blinks now and then |
| Listening | The "Hey Flurry" wake phrase is on and the microphone is live |
| Thinking | It's working on something you asked |
| Success | Something you asked for worked |
| Error | Something failed (the message says what) |
| Settled | You're typing elsewhere; it sinks a little and fades back |
| Curious | You're pointing at it (or near it): it leans in and its eyes widen |
| Wave | It has just arrived at the conversation you called it to |
| Asleep | A quiet spell: it naps in its home corner, small *z*s drifting up |

Personality: attentive, brief and honest. It suggests; people decide. It never approves work, never assigns people or changes deadlines on its own, and never claims to have opened a link or file. Everything it changes is previewed first, saved only when you confirm, and can be undone.

Motion: a gentle float and a blink; its eyes follow the pointer; it flies between spots in a soft arc and banks into turns. *Keep Flurry still* and the system's reduced-motion setting stop all of it. The figure is decorative (`aria-hidden`); whatever it expresses is also said in words.

Presence: alive but polite. Flurry roams the page until it's called, keeping to the edges and empty space, never landing on what you're working on, holding still when you point at it or type, and napping when things are quiet. Called, it flies to the conversation and perches on it while it's open. It never pops up on its own and has no speech bubbles. *Let Flurry roam* off keeps it in a home corner of your choosing (it steps aside from a field you're typing in); pinning docks the conversation beside the page, which makes room. The menu has roaming, the home corner, *Minimise*, sounds, *Keep Flurry still* and *Hide*.

In the workspace, the front page's weather stays faintly behind every page (a distant range with its snow in rows, and light snowfall), labels read like instruments in IBM Plex Mono, and each project's Overview shows its own avalanche: approved work settled into rows, the rest still coming down.

## Imagery

- Real product screens and the sample project, labelled as samples.
- The avalanche (made from the sample project's tasks, or a project's own on its Overview), the crystals and Flurry.
- No stock photos of people, no fabricated dashboards with invented numbers, no customer logos until there are customers.
