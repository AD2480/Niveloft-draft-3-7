import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/cn';

const GLYPHS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/#<>_-+=*';

/**
 * Letters that decode into place, left to right, when `play` turns on. Screen readers get the
 * real text at once; the scrambled letters are decoration. Reduced motion shows the text as is.
 */
export function Scramble({ text, play = true, className, duration = 700 }: { text: string; play?: boolean; className?: string; duration?: number }) {
  const [shown, setShown] = useState<string | null>(null);
  const reduce = useRef(typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
  useEffect(() => {
    if (!play || reduce.current) {
      setShown(null);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const upto = Math.floor(t * text.length);
      let out = text.slice(0, upto);
      for (let i = upto; i < text.length; i++) out += text[i] === ' ' ? ' ' : GLYPHS[Math.floor(Math.random() * GLYPHS.length)];
      setShown(t < 1 ? out : null);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [play, text, duration]);
  if (shown === null) return <span className={className}>{text}</span>;
  return (
    <span className={cn('relative', className)}>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">{shown}</span>
    </span>
  );
}
