import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';
import { Scramble } from './Scramble';

/**
 * Page header: a compact title row (28–30px), an optional one-line description, and actions
 * aligned to it. The eyebrow reads like an instrument label ("// Account"), and a plain-text
 * title decodes into place when the page opens (not under reduced motion; screen readers get the
 * real title at once).
 */
export function PageHeader({
  title,
  description,
  actions,
  eyebrow,
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  eyebrow?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex flex-col gap-4 pb-6 sm:flex-row sm:items-end sm:justify-between', className)}>
      <div className="min-w-0">
        {eyebrow && (
          <p className="eyebrow mb-1.5 font-hud text-[12px] tracking-[0.02em]">
            <span aria-hidden="true">// </span>
            {eyebrow}
          </p>
        )}
        <h1 className="text-[28px] leading-tight font-semibold tracking-[-0.02em] text-ink sm:text-[30px]">{typeof title === 'string' ? <Scramble text={title} duration={420} /> : title}</h1>
        {description && <p className="mt-1.5 max-w-2xl text-[14px] leading-relaxed text-muted">{description}</p>}
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2" data-print="hide">
          {actions}
        </div>
      )}
    </div>
  );
}
