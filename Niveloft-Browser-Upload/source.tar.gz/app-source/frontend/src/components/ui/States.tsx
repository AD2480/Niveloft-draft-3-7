import { AlertTriangle, MessageCircle, type LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import { getErrorMessage, getRequestId } from '@/api/errors';
import { openContact } from '@/features/contact/contactStore';
import { cn } from '@/lib/cn';
import { Button } from './Button';
import { CopyButton } from './CopyButton';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: ReactNode;
  action?: ReactNode;
  className?: string;
  compact?: boolean;
}

export function EmptyState({ icon: Icon, title, description, action, className, compact }: EmptyStateProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center text-center', compact ? 'px-4 py-8' : 'px-6 py-14', className)}>
      <div className={cn('flex items-center justify-center rounded-xl bg-surface-2 text-muted ring-1 ring-line', compact ? 'size-10' : 'size-12')}>
        <Icon className={compact ? 'size-5' : 'size-6'} aria-hidden="true" />
      </div>
      <h3 className={cn('font-semibold text-ink', compact ? 'mt-3 text-sm' : 'mt-4 text-[15px]')}>{title}</h3>
      {description && <p className="mt-1 max-w-sm text-[13px] leading-relaxed text-muted">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/**
 * A failed load: what went wrong in plain words, a way to try again and, when the server gave the
 * failure a reference, the reference with a copy button and a way to report it.
 */
export function ErrorState({ error, onRetry, title = 'Couldn’t load this', className }: { error: unknown; onRetry?: () => void; title?: string; className?: string }) {
  const reference = getRequestId(error);
  const message = getErrorMessage(error).replace(/ \(Reference: [^)]+\)$/, '');
  return (
    <div role="alert" className={cn('flex flex-col items-center justify-center px-6 py-14 text-center', className)} data-error-state="">
      <div className="flex size-12 items-center justify-center rounded-xl bg-danger-soft text-danger ring-1 ring-danger/20">
        <AlertTriangle className="size-6" aria-hidden="true" />
      </div>
      <h3 className="mt-4 text-[15px] font-semibold text-ink">{title}</h3>
      <p className="mt-1 max-w-md text-[13px] text-muted">{message}</p>
      {reference && (
        <p className="mt-3 flex flex-wrap items-center justify-center gap-x-1.5 gap-y-1 text-[12px] text-muted">
          Reference <code className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[12px] text-ink-2">{reference}</code>
          <CopyButton text={reference} what="the reference" iconOnly />
        </p>
      )}
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        {onRetry && (
          <Button variant="secondary" size="sm" onClick={onRetry}>
            Try again
          </Button>
        )}
        {reference && (
          <Button variant="ghost" size="sm" leftIcon={<MessageCircle aria-hidden="true" />} onClick={() => openContact({ topic: 'PROBLEM', reference })}>
            Report this problem
          </Button>
        )}
      </div>
    </div>
  );
}
