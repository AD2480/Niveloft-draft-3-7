import * as DM from '@radix-ui/react-dropdown-menu';
import { Check } from 'lucide-react';
import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

export const Menu = DM.Root;
export const MenuTrigger = DM.Trigger;

export function MenuContent({ children, align = 'end', side = 'bottom', className }: { children: ReactNode; align?: 'start' | 'center' | 'end'; side?: 'top' | 'bottom'; className?: string }) {
  return (
    <DM.Portal>
      <DM.Content
        align={align}
        side={side}
        sideOffset={6}
        collisionPadding={8}
        className={cn('z-[60] min-w-44 overflow-hidden rounded-lg border border-line bg-surface p-1 shadow-pop animate-fade-in', className)}
      >
        {children}
      </DM.Content>
    </DM.Portal>
  );
}

export function MenuItem({
  children,
  onSelect,
  icon,
  danger,
  disabled,
}: {
  children: ReactNode;
  onSelect?: () => void;
  icon?: ReactNode;
  danger?: boolean;
  disabled?: boolean;
}) {
  return (
    <DM.Item
      disabled={disabled}
      onSelect={onSelect}
      className={cn(
        'flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-[13px] outline-none select-none [&_svg]:size-4 [&_svg]:text-muted',
        'data-[highlighted]:bg-surface-2 data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50',
        danger ? 'text-danger [&_svg]:!text-danger' : 'text-ink',
      )}
    >
      {icon}
      {children}
    </DM.Item>
  );
}

/** A menu item that toggles something on or off (announced as a checkbox item with its state). */
export function MenuCheckItem({ children, checked, onSelect, disabled }: { children: ReactNode; checked: boolean; onSelect: () => void; disabled?: boolean }) {
  return (
    <DM.CheckboxItem
      checked={checked}
      disabled={disabled}
      onSelect={onSelect}
      className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-[13px] text-ink outline-none select-none data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50 data-[highlighted]:bg-surface-2"
    >
      <span className="flex size-4 items-center justify-center">{checked && <Check className="size-4 text-accent" />}</span>
      {children}
    </DM.CheckboxItem>
  );
}

export function MenuLabel({ children }: { children: ReactNode }) {
  return <DM.Label className="px-2 pt-1.5 pb-1 text-[12px] font-medium text-muted">{children}</DM.Label>;
}

export function MenuSeparator() {
  return <DM.Separator className="my-1 h-px bg-line" />;
}
