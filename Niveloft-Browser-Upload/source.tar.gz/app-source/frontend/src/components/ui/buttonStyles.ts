import { cn } from '@/lib/cn';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'link';
export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg' | 'icon' | 'icon-sm';

const variants: Record<ButtonVariant, string> = {
  // Deep blue with white text (ice blue with dark text in the dark theme): the one dominant action. Flat: no gradient, glow or shadow.
  primary: 'bg-brand text-white hover:bg-brand-hover dark:text-canvas disabled:hover:bg-brand',
  secondary: 'bg-surface text-ink border border-line-strong hover:border-ink hover:bg-surface-2',
  outline: 'border border-line-strong text-ink hover:bg-surface-2',
  ghost: 'text-ink-2 hover:bg-surface-2 hover:text-ink',
  danger: 'bg-danger text-white hover:opacity-90 dark:text-canvas',
  link: 'text-accent hover:underline underline-offset-4 !px-0 !h-auto !rounded-none',
};

/*
 * Sentence-case labels. Main actions are 48px tall (lg); everyday ones are 40px (md) with a mouse and
 * 44px on touch screens; sm and xs are for dense rows.
 */
const sizes: Record<ButtonSize, string> = {
  xs: 'h-7 px-2.5 text-[12px] gap-1',
  sm: 'h-8 px-3 text-[12.5px] gap-1.5',
  md: 'h-10 pointer-coarse:min-h-11 px-4 text-[13.5px] gap-2',
  lg: 'h-12 px-6 text-[15px] gap-2',
  icon: 'h-10 w-10 pointer-coarse:min-h-11 pointer-coarse:min-w-11',
  'icon-sm': 'h-8 w-8',
};

/** Button styling for elements that aren't <button>, e.g. a router <Link> that looks like a button. */
export function buttonClass(variant: ButtonVariant = 'primary', size: ButtonSize = 'md', className?: string): string {
  return cn(
    // Hover changes colour; pressing nudges the button down a pixel, so a click is felt.
    'inline-flex shrink-0 items-center justify-center rounded-md font-medium whitespace-nowrap select-none',
    'transition-[color,background-color,border-color,opacity,transform] duration-150 active:not-disabled:translate-y-px',
    '[&_svg]:size-4 [&_svg]:shrink-0',
    variants[variant],
    sizes[size],
    className,
  );
}
