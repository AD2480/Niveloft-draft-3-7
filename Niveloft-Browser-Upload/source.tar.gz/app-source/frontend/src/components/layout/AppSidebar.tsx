import * as RD from '@radix-ui/react-dialog';
import { BarChart3, CalendarDays, ChevronsUpDown, CircleCheckBig, FolderKanban, House, Inbox, LifeBuoy, Menu as MenuIcon, Plus, Search, Settings, X, type LucideIcon } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router';
import { useProjectsQuery, useUnreadCountQuery } from '@/api/endpoints';
import { loggedOut, useAppDispatch, useAppSelector } from '@/app/store';
import { mobileNavSet, themeChanged, type ThemePreference } from '@/app/uiSlice';
import { USE_MOCK_API } from '@/config';
import { useOptionalAssistant } from '@/features/assistant/assistantContext';
import { openContact } from '@/features/contact/contactStore';
import { FlurryFigure } from '@/features/flurry/FlurryFigure';
import { useFlurryPrefs } from '@/features/flurry/flurryPrefs';
import type { LiveStatus } from '@/features/live/useLiveUpdates';
import { cn } from '@/lib/cn';
import { useMediaQuery } from '@/lib/hooks';
import { PALETTE_SHORTCUT } from '../CommandPalette';
import { ScrollProgress } from '../ScrollAids';
import { Avatar } from '../ui/Avatar';
import { Menu, MenuCheckItem, MenuContent, MenuItem, MenuLabel, MenuSeparator, MenuTrigger } from '../ui/Menu';
import { Logo } from './Logo';

/** The places. Everything else is reached from these, from a project, or from ⌘K. */
export const PRIMARY_NAV: { to: string; label: string; icon: LucideIcon }[] = [
  { to: '/dashboard', label: 'Today', icon: House },
  { to: '/my-tasks', label: 'My work', icon: CircleCheckBig },
  { to: '/inbox', label: 'Inbox', icon: Inbox },
  { to: '/projects', label: 'Projects', icon: FolderKanban },
  { to: '/calendar', label: 'Calendar', icon: CalendarDays },
  { to: '/analytics', label: 'Reports', icon: BarChart3 },
];

const THEMES: { value: ThemePreference; label: string }[] = [
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
  { value: 'system', label: 'Match system' },
];

const LIVE: Record<LiveStatus, { label: string; dot: string }> = {
  live: { label: 'Live updates on', dot: 'bg-success' },
  connecting: { label: 'Connecting', dot: 'bg-warning' },
  reconnecting: { label: 'Reconnecting', dot: 'bg-warning' },
  offline: { label: 'Offline', dot: 'bg-danger' },
  demo: { label: 'Demo', dot: 'bg-accent' },
};

export const SIDEBAR_WIDTH = 256;

/**
 * The signed-in frame's navigation: a stable sidebar on large screens (logo, search, the places,
 * your active projects, Flurry, help and your account) and the same content in a drawer on
 * smaller ones, opened from the top bar.
 */
export function AppSidebar({ onOpenSearch, onNewProject, live }: { onOpenSearch: () => void; onNewProject: () => void; live: LiveStatus }) {
  const dispatch = useAppDispatch();
  const open = useAppSelector((s) => s.ui.mobileNavOpen);
  const location = useLocation();
  const wide = useMediaQuery('(min-width: 1024px)');
  // A new page closes the drawer.
  useEffect(() => {
    dispatch(mobileNavSet(false));
  }, [location.pathname, dispatch]);

  return (
    <>
      <aside
        className="fixed inset-y-0 left-0 z-30 hidden flex-col border-r border-line bg-surface lg:flex"
        style={{ width: SIDEBAR_WIDTH }}
        aria-label="Sidebar"
        data-print="hide"
        data-app-sidebar=""
      >
        {wide && <SidebarContent onOpenSearch={onOpenSearch} onNewProject={onNewProject} live={live} />}
      </aside>
      <RD.Root open={open && !wide} onOpenChange={(o) => dispatch(mobileNavSet(o))}>
        <RD.Portal>
          <RD.Overlay className="fixed inset-0 z-50 bg-graphite/40 animate-fade-in lg:hidden" />
          <RD.Content
            className="fixed inset-y-0 left-0 z-50 flex w-[min(20rem,88vw)] flex-col border-r border-line bg-surface shadow-pop animate-slide-in-left focus:outline-none lg:hidden"
            data-app-drawer=""
            aria-describedby={undefined}
          >
            <RD.Title className="sr-only">Menu</RD.Title>
            <RD.Close className="absolute top-3.5 right-3 flex size-9 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-ink" aria-label="Close the menu">
              <X className="size-4" aria-hidden="true" />
            </RD.Close>
            <SidebarContent
              onOpenSearch={() => {
                dispatch(mobileNavSet(false));
                onOpenSearch();
              }}
              onNewProject={() => {
                dispatch(mobileNavSet(false));
                onNewProject();
              }}
              live={live}
            />
          </RD.Content>
        </RD.Portal>
      </RD.Root>
    </>
  );
}

function SidebarContent({ onOpenSearch, onNewProject, live }: { onOpenSearch: () => void; onNewProject: () => void; live: LiveStatus }) {
  const location = useLocation();
  // The live connection pushes new notifications; poll only as a fallback when it isn't live.
  const { data: unread = 0 } = useUnreadCountQuery(undefined, { pollingInterval: live === 'live' || live === 'demo' ? 0 : 60_000 });
  const { data: projects } = useProjectsQuery({ status: 'ACTIVE', size: 8 });
  const activeProject = /^\/projects\/(\d+)/.exec(location.pathname)?.[1];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex h-16 shrink-0 items-center gap-2 px-5">
        <Link to="/dashboard" className="rounded-md transition-opacity hover:opacity-80" aria-label="Niveloft, today">
          <Logo />
        </Link>
        {USE_MOCK_API && (
          <span className="rounded-full border border-accent/40 bg-brand-soft px-2 py-0.5 text-[11.5px] font-medium text-brand-ink" title="Demo mode: data lives in this browser only">
            Demo
          </span>
        )}
      </div>

      <div className="px-3">
        <button
          type="button"
          onClick={onOpenSearch}
          className="flex h-10 w-full items-center gap-2.5 rounded-md border border-line bg-canvas px-3 text-[13px] text-muted transition-colors hover:border-line-strong hover:text-ink"
          aria-label={`Search and commands (${PALETTE_SHORTCUT})`}
          data-sidebar-search=""
        >
          <Search className="size-4" aria-hidden="true" />
          <span className="flex-1 text-left">Search or jump to…</span>
          <kbd className="rounded border border-line-strong px-1.5 font-sans text-[11.5px] text-subtle">{PALETTE_SHORTCUT}</kbd>
        </button>
      </div>

      <nav aria-label="Main" className="scrollbar-thin mt-4 min-h-0 flex-1 overflow-y-auto px-3 pb-4">
        <ul className="space-y-0.5">
          {PRIMARY_NAV.map((item) => (
            <li key={item.to}>
              <NavLink to={item.to} className={({ isActive }) => navClass(isActive)} aria-label={item.to === '/inbox' ? `Inbox, ${unread} unread` : undefined}>
                <item.icon className="size-[18px] shrink-0" aria-hidden="true" />
                <span className="flex-1">{item.label}</span>
                {item.to === '/inbox' && unread > 0 && (
                  <span className="rounded-full bg-brand-soft px-1.5 py-px text-[12px] font-semibold text-brand-ink tabular">{unread > 99 ? '99+' : unread}</span>
                )}
              </NavLink>
            </li>
          ))}
        </ul>

        <div className="mt-7 flex items-center justify-between px-3">
          <p className="font-hud text-[11.5px] tracking-[0.02em] text-muted">
            <span aria-hidden="true">////// </span>Active projects
          </p>
          <button type="button" onClick={onNewProject} className="flex size-7 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-ink" aria-label="New project" title="New project">
            <Plus className="size-4" aria-hidden="true" />
          </button>
        </div>
        <ul className="mt-1.5 space-y-0.5" data-sidebar-projects="">
          {projects?.content.map((p) => {
            const active = activeProject === String(p.id);
            return (
              <li key={p.id}>
                <Link to={`/projects/${p.id}`} className={navClass(active)} aria-current={active ? 'page' : undefined} title={p.name}>
                  <span className="flex size-[18px] shrink-0 items-center justify-center" aria-hidden="true">
                    <span className="size-2.5 rounded-[3px]" style={{ backgroundColor: p.color }} />
                  </span>
                  <span className="min-w-0 flex-1 truncate">{p.name}</span>
                  <span className="font-mono text-[11.5px] text-subtle">{p.key}</span>
                </Link>
              </li>
            );
          })}
          {projects && projects.content.length === 0 && (
            <li>
              <button type="button" onClick={onNewProject} className="w-full rounded-md px-3 py-2 text-left text-[13px] text-muted hover:bg-surface-2 hover:text-ink">
                No active projects yet. Create one.
              </button>
            </li>
          )}
        </ul>
      </nav>

      <div className="shrink-0 space-y-1 border-t border-line px-3 pt-3 pb-3">
        {USE_MOCK_API && (
          // Demo mode is always explicit: this isn't the real, shared backend.
          <p className="mb-2 rounded-md bg-warning-soft px-3 py-2 text-[12px] leading-snug text-warning" data-demo-notice="">
            <span className="font-semibold">Demo mode.</span> Everything you do stays in this browser; nothing is shared or saved on a server.
          </p>
        )}
        <AskFlurryItem />
        <NavLink to="/faq" className={({ isActive }) => navClass(isActive)}>
          <LifeBuoy className="size-[18px] shrink-0" aria-hidden="true" />
          Help and FAQ
        </NavLink>
        <NavLink to="/settings" className={({ isActive }) => navClass(isActive)}>
          <Settings className="size-[18px] shrink-0" aria-hidden="true" />
          Settings
        </NavLink>
        <AccountMenu live={live} />
      </div>
    </div>
  );
}

function navClass(active: boolean): string {
  return cn(
    'flex h-9 items-center gap-3 rounded-md px-3 text-[13.5px] font-medium transition-colors',
    active ? 'bg-brand-soft text-brand-ink [&_svg]:text-accent' : 'text-ink-2 hover:bg-surface-2 hover:text-ink [&_svg]:text-muted',
  );
}

/** Opens Flurry's panel, and brings Flurry back if it was hidden. */
function AskFlurryItem() {
  const a = useOptionalAssistant();
  const userId = useAppSelector((s) => s.auth.user?.id ?? 0);
  const [prefs] = useFlurryPrefs(userId);
  const reduceMotion = useMediaQuery('(prefers-reduced-motion: reduce)');
  if (!a) return null;
  return (
    <button type="button" onClick={() => a.setOpen(true)} className={cn(navClass(false), 'w-full')} data-sidebar-flurry="">
      <FlurryFigure mood={a.mood === 'settled' ? 'idle' : a.mood} still={prefs.still || reduceMotion} glow={false} className="-ml-1 size-7 shrink-0" />
      <span className="flex-1 text-left">Ask Flurry</span>
      <kbd className="font-sans text-[11.5px] text-subtle">Alt A</kbd>
    </button>
  );
}

function AccountMenu({ live }: { live: LiveStatus }) {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const user = useAppSelector((s) => s.auth.user);
  const theme = useAppSelector((s) => s.ui.theme);
  const signOut = () => {
    dispatch(loggedOut());
    navigate('/login', { replace: true });
  };
  return (
    <Menu>
      <MenuTrigger asChild>
        <button type="button" className="mt-1 flex w-full items-center gap-2.5 rounded-md px-2 py-2 text-left transition-colors hover:bg-surface-2" aria-label="Account and appearance" data-account-menu="">
          <Avatar user={user} size="md" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[13px] font-medium text-ink">{user?.name}</span>
            <span className="flex items-center gap-1.5 text-[12px] text-muted" role="status">
              <span className={cn('size-1.5 rounded-full', LIVE[live].dot)} aria-hidden="true" />
              {LIVE[live].label}
            </span>
          </span>
          <ChevronsUpDown className="size-4 shrink-0 text-muted" aria-hidden="true" />
        </button>
      </MenuTrigger>
      <MenuContent align="start" side="top" className="w-64">
        <div className="px-2 py-2">
          <p className="truncate text-[13px] font-medium text-ink">{user?.name}</p>
          <p className="truncate text-xs text-muted">{user?.email}</p>
        </div>
        <MenuSeparator />
        <MenuItem onSelect={() => navigate('/settings')}>Profile</MenuItem>
        <MenuItem onSelect={() => navigate('/settings?tab=security')}>Password and sign-in</MenuItem>
        <MenuItem onSelect={() => navigate('/arena')}>AI arena</MenuItem>
        {user?.operator && <MenuItem onSelect={() => navigate('/site-health')}>Site health</MenuItem>}
        <MenuSeparator />
        <MenuItem onSelect={() => navigate('/introduction')}>Introduction</MenuItem>
        <MenuItem onSelect={() => openContact()}>Contact us</MenuItem>
        <MenuSeparator />
        <MenuLabel>Appearance</MenuLabel>
        {THEMES.map((t) => (
          <MenuCheckItem key={t.value} checked={theme === t.value} onSelect={() => dispatch(themeChanged(t.value))}>
            {t.label}
          </MenuCheckItem>
        ))}
        <MenuSeparator />
        <MenuItem onSelect={signOut}>Sign out</MenuItem>
      </MenuContent>
    </Menu>
  );
}

/**
 * The top bar: on small screens the menu button and logo; on every screen the current place,
 * search and the inbox. It carries the reading-progress line.
 */
export function AppTopBar({ onOpenSearch, live, children }: { onOpenSearch: () => void; live: LiveStatus; children?: ReactNode }) {
  const dispatch = useAppDispatch();
  const drawerOpen = useAppSelector((s) => s.ui.mobileNavOpen);
  const { data: unread = 0 } = useUnreadCountQuery(undefined, { pollingInterval: live === 'live' || live === 'demo' ? 0 : 60_000 });
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-canvas/90 backdrop-blur supports-[backdrop-filter]:bg-canvas/80" data-print="hide" data-scrolled="false" data-app-topbar="">
      <div className="flex h-14 items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          className="-ml-1.5 flex size-10 items-center justify-center rounded-md text-ink transition-colors hover:bg-surface-2 lg:hidden"
          onClick={() => dispatch(mobileNavSet(true))}
          aria-label="Open the menu"
          aria-haspopup="dialog"
          aria-expanded={drawerOpen}
          data-index-button=""
        >
          <MenuIcon className="size-5" aria-hidden="true" />
        </button>
        <Link to="/dashboard" className="lg:hidden" aria-label="Niveloft, today">
          <Logo />
        </Link>
        {USE_MOCK_API && (
          <span className="rounded-full border border-accent/40 bg-brand-soft px-2 py-0.5 text-[11.5px] font-medium text-brand-ink lg:hidden" title="Demo mode: data lives in this browser only">
            Demo
          </span>
        )}
        <div className="hidden min-w-0 flex-1 lg:block">{children}</div>
        <div className="ml-auto flex items-center gap-1">
          <Stamp />
          <button type="button" onClick={onOpenSearch} className="flex size-10 items-center justify-center rounded-md text-muted transition-colors hover:bg-surface-2 hover:text-ink lg:hidden" aria-label={`Search and commands (${PALETTE_SHORTCUT})`}>
            <Search className="size-[18px]" aria-hidden="true" />
          </button>
          <Link to="/inbox" className="relative flex size-10 items-center justify-center rounded-md text-muted transition-colors hover:bg-surface-2 hover:text-ink lg:hidden" aria-label={`Inbox, ${unread} unread`}>
            <Inbox className="size-[18px]" aria-hidden="true" />
            {unread > 0 && <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-accent" aria-hidden="true" />}
          </Link>
        </div>
      </div>
      <ScrollProgress />
    </header>
  );
}

/** The date and time, read off like an instrument (large screens). */
function Stamp() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 30_000);
    return () => window.clearInterval(id);
  }, []);
  const pad = (n: number) => String(n).padStart(2, '0');
  return (
    <time dateTime={now.toISOString()} className="mr-1 hidden font-hud text-[11.5px] text-muted tabular-nums lg:inline" data-app-stamp="">
      {pad(now.getDate())}.{pad(now.getMonth() + 1)}.{now.getFullYear()} · {pad(now.getHours())}:{pad(now.getMinutes())}
    </time>
  );
}
