import { cn } from '@/lib/cn';

/**
 * The Niveloft symbol: an abstract N built from three architectural planes, like the section of a
 * loft. Two upright walls carry a pitched roof plane that folds across them, and the gaps between
 * the planes keep the three parts readable at favicon size, even in one colour.
 *
 * Paths live here and in public/favicon.svg (keep them in step).
 */
export const MARK_PATHS = {
  /** Left wall: its top is cut to the roof's pitch. */
  left: 'M5 10 11 6.5V26H5z',
  /** The folded roof plane, running from the top of the left wall down to the foot of the right. */
  fold: 'M12.8 6.5 27 24V26h-4.2L12.8 13.6z',
  /** Right wall: shorter, so light falls between it and the roof. */
  right: 'M21 6.5h6v14l-6-7.4z',
} as const;

export function LogoMark({ className, inverted = false, mono = false }: { className?: string; inverted?: boolean; mono?: boolean }) {
  // `inverted` is for always-dark backgrounds in either theme; `mono` draws every plane in one colour.
  const wall = inverted ? '#f4f6f7' : 'var(--ink)';
  const fold = mono ? wall : inverted ? '#a9cedf' : 'var(--accent)';
  return (
    <svg viewBox="0 0 32 32" className={cn('size-8', className)} aria-hidden="true" data-logo-mark="">
      <path d={MARK_PATHS.left} fill={wall} />
      <path d={MARK_PATHS.fold} fill={fold} />
      <path d={MARK_PATHS.right} fill={wall} />
    </svg>
  );
}

/**
 * The wordmark: "niveloft" in Inter SemiBold, lowercase, with one distinctive detail: the dot of the i is
 * a small diamond in ice blue, like a lit window seen from the valley.
 */
export function Wordmark({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  return (
    <span
      className={cn('relative inline-flex items-baseline font-display text-[19px] leading-none font-semibold tracking-[-0.035em]', inverted ? 'text-[#f4f6f7]' : 'text-ink', className)}
      aria-label="Niveloft"
      role="img"
      data-wordmark=""
    >
      <span aria-hidden="true">n</span>
      <span aria-hidden="true" className="relative">
        {/* Dotless i with a diamond for its dot. */}
        ı
        <span
          className={cn('absolute left-1/2 top-[-0.02em] size-[0.2em] -translate-x-1/2 rotate-45 rounded-[1px]', inverted ? 'bg-[#a9cedf]' : 'bg-accent')}
          aria-hidden="true"
        />
      </span>
      <span aria-hidden="true">veloft</span>
    </span>
  );
}

export function Logo({ collapsed = false, className, inverted = false }: { collapsed?: boolean; className?: string; inverted?: boolean }) {
  return (
    <span className={cn('inline-flex items-center gap-2', className)}>
      <LogoMark className="size-7" inverted={inverted} />
      {!collapsed && <Wordmark inverted={inverted} />}
    </span>
  );
}
