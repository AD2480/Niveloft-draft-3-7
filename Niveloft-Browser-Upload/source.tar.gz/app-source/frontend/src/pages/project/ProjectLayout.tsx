import { Suspense, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate, useParams } from 'react-router';
import { useProjectQuery } from '@/api/endpoints';
import { errorStatus } from '@/api/errors';
import type { Health, ProjectStatus } from '@/api/types';
import { Button } from '@/components/ui/Button';
import { Skeleton } from '@/components/ui/Spinner';
import { ErrorState } from '@/components/ui/States';
import type { ProjectOutletContext } from '@/features/projects/projectContext';
import { TaskFormDialog } from '@/features/tasks/TaskFormDialog';
import { MyRoleButton } from '@/features/roles/RoleGuide';
import { cn } from '@/lib/cn';
import { formatDate } from '@/lib/dates';
import { useDocumentTitle } from '@/lib/hooks';
import { can } from '@/lib/permissions';
import { NotFoundPage } from '../NotFoundPage';

/**
 * Seven chapters instead of eleven tabs. Each chapter owns one or more existing routes; chapters
 * with several routes show them as modes underneath (e.g. Work: Board · List).
 */
interface Chapter {
  numeral: string;
  label: string;
  /** Where the chapter link goes. */
  to: string;
  /** Route segments (first segment after /projects/:id) that belong to this chapter. */
  segments: string[];
  modes?: { to: string; label: string }[];
}

const CHAPTERS: Chapter[] = [
  {
    numeral: 'I',
    label: 'Overview',
    to: '',
    segments: ['', 'analytics', 'activity'],
    modes: [
      { to: '', label: 'Summary' },
      { to: 'analytics', label: 'Analytics' },
      { to: 'activity', label: 'Activity' },
    ],
  },
  {
    numeral: 'II',
    label: 'Work',
    to: 'board',
    segments: ['board', 'tasks'],
    modes: [
      { to: 'board', label: 'Board' },
      { to: 'tasks', label: 'List' },
    ],
  },
  { numeral: 'III', label: 'Graph', to: 'model', segments: ['model'] },
  { numeral: 'IV', label: 'Prediction model', to: 'predictions', segments: ['predictions'] },
  {
    numeral: 'V',
    label: 'Schedule',
    to: 'timeline',
    segments: ['timeline', 'map', 'plan', 'milestones'],
    modes: [
      { to: 'timeline', label: 'Timeline' },
      { to: 'map', label: 'Dependencies' },
      { to: 'plan', label: 'What if' },
      { to: 'milestones', label: 'Milestones' },
    ],
  },
  { numeral: 'VI', label: 'People', to: 'team', segments: ['team'] },
  { numeral: 'VII', label: 'Settings', to: 'settings', segments: ['settings'] },
];

const HEALTH_WORD: Record<Health, string> = {
  NOT_STARTED: 'Not started',
  ON_TRACK: 'On track',
  AT_RISK: 'At risk',
  OFF_TRACK: 'Off track',
  COMPLETED: 'Completed',
};

const STATUS_WORD: Record<ProjectStatus, string> = { ACTIVE: 'Active', ON_HOLD: 'On hold', COMPLETED: 'Completed', ARCHIVED: 'Archived' };

function ModesNav({ chapter, base }: { chapter: Chapter; base: string }) {
  return (
    <nav className="scrollbar-thin mx-auto flex max-w-[1600px] gap-5 overflow-x-auto px-4 sm:px-6 lg:px-8" aria-label={`${chapter.label} views`}>
      {chapter.modes!.map((m) => (
        <NavLink
          key={m.label}
          to={m.to ? `${base}/${m.to}` : base}
          end={m.to === '' || m.to === 'tasks'}
          className={({ isActive }) =>
            cn('flex h-10 shrink-0 items-center text-[13px] transition-colors', isActive ? 'text-ink underline decoration-accent underline-offset-[14px]' : 'text-muted hover:text-ink')
          }
        >
          {m.label}
        </NavLink>
      ))}
    </nav>
  );
}

export function ProjectLayout() {
  const { projectId } = useParams();
  const id = Number(projectId);
  const navigate = useNavigate();
  const location = useLocation();
  const { data: project, isLoading, isError, error, refetch } = useProjectQuery(id, { skip: !Number.isFinite(id) });
  const [newTask, setNewTask] = useState<{ open: boolean; defaults?: Parameters<ProjectOutletContext['openNewTask']>[0] }>({ open: false });
  useDocumentTitle(project?.name);

  if (!Number.isFinite(id)) return <NotFoundPage />;

  if (isLoading) {
    return (
      <div className="border-b border-line">
        <div className="mx-auto max-w-[1600px] space-y-4 px-4 py-8 sm:px-6 lg:px-8">
          <Skeleton className="h-3 w-40" />
          <Skeleton className="h-10 w-96 max-w-full" />
          <Skeleton className="h-3 w-full max-w-xl" />
        </div>
      </div>
    );
  }

  if (isError || !project) {
    const status = errorStatus(error);
    if (status === 404) return <NotFoundPage title="Project not found" description="It may have been deleted, or the link is wrong." />;
    if (status === 403) {
      return (
        <div className="mx-auto max-w-[1600px] px-4 py-16 sm:px-6 lg:px-8">
          <p className="eyebrow">No access</p>
          <h1 className="mt-3 font-display text-[34px] font-semibold tracking-[-0.03em] text-ink">You aren’t a member of this project.</h1>
          <p className="mt-2 text-[14px] text-muted">Ask the owner or a manager to invite you.</p>
          <Button variant="secondary" className="mt-6" onClick={() => navigate('/projects')}>
            Back to projects
          </Button>
        </div>
      );
    }
    return <ErrorState error={error} onRetry={refetch} className="min-h-[60vh]" />;
  }

  const context: ProjectOutletContext = {
    project,
    openNewTask: (defaults) => setNewTask({ open: true, defaults }),
  };

  // Which chapter and mode are we in? Task pages (/tasks/:id…) belong to Work but no mode.
  const rest = location.pathname.replace(`/projects/${project.id}`, '').replace(/^\//, '');
  const segments = rest.split('/');
  const first = segments[0] ?? '';
  const deep = first === 'tasks' && segments.length > 1 && segments[1] !== '';
  const chapter = CHAPTERS.find((c) => c.segments.includes(first)) ?? CHAPTERS[0];
  const base = `/projects/${project.id}`;
  const expected = project.status === 'ACTIVE' ? project.expectedProgress : null;
  const TitleTag = deep ? 'p' : 'h1';

  return (
    <div>
      <div className="border-b border-line">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-8">
          <div className={cn('flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between', deep ? 'pt-5 pb-4' : 'pt-6 pb-5')}>
            <div className="min-w-0">
              <nav aria-label="Breadcrumb" className="caps flex items-center gap-2 text-muted">
                <Link to="/projects" className="transition-colors hover:text-ink">
                  Projects
                </Link>
                <span aria-hidden="true">/</span>
                <span className="font-mono tracking-normal text-ink-2">{project.key}</span>
              </nav>
              <TitleTag
                className={cn(
                  'mt-2 font-semibold tracking-[-0.02em] break-words text-ink',
                  deep ? 'text-[20px] leading-tight' : 'text-[28px] leading-tight sm:text-[32px]',
                )}
              >
                {deep ? <Link to={base} className="transition-colors hover:text-accent">{project.name}</Link> : project.name}
              </TitleTag>
              {!deep && (
                <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-muted">
                  <span className={cn('font-medium', project.health === 'OFF_TRACK' ? 'text-danger' : project.health === 'AT_RISK' ? 'text-warning' : 'text-ink')}>
                    {project.status === 'ACTIVE' ? HEALTH_WORD[project.health] : STATUS_WORD[project.status]}
                  </span>
                  <MyRoleButton role={project.myRole} projectName={project.name} className="-my-1" />
                  <span>
                    {formatDate(project.startDate, 'd MMM')} — {project.deadline ? formatDate(project.deadline, 'd MMM yyyy') : 'No deadline'}
                  </span>
                  <span>{project.memberCount} people</span>
                </p>
              )}
            </div>
            <div className="flex items-end gap-6">
              {!deep && (
                // Counts, not effort: a small task and a big one count the same, so this says "tasks".
                <div className="w-52" data-project-count="">
                  <p className="text-[13px] text-muted">
                    <span className="text-[20px] font-semibold text-ink">{project.taskCounts.done}</span> of {project.taskCounts.total} tasks approved
                  </p>
                  <div className="relative mt-2 h-1 rounded-full bg-surface-3" aria-hidden="true">
                    <div className="absolute inset-y-0 left-0 rounded-full bg-accent" style={{ width: `${project.progress}%` }} />
                    {expected !== null && <div className="absolute -top-1 h-3 w-px bg-ink" style={{ left: `${expected}%` }} />}
                  </div>
                  <p className="mt-1.5 text-[12px] text-muted">
                    {expected !== null ? `${expected}% of the time to the deadline has passed` : 'No deadline set'}
                  </p>
                </div>
              )}
              {can.createTask(project.myRole) && project.status !== 'ARCHIVED' && (
                <Button onClick={() => setNewTask({ open: true })} data-print="hide">
                  New task
                </Button>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* The chapters (and the chapter's views) stay under the top bar while the page scrolls. */}
      <div className="sticky top-14 z-10 border-b border-line bg-canvas" data-print="hide" data-project-bar="">
        <div className="mx-auto max-w-[1600px] px-4 sm:px-6 lg:px-8">
          <nav className="scrollbar-thin -mx-4 flex gap-6 overflow-x-auto px-4 sm:mx-0 sm:px-0" aria-label="Project chapters">
            {CHAPTERS.map((c) => {
              const active = c === chapter;
              return (
                <Link
                  key={c.label}
                  to={c.to ? `${base}/${c.to}` : base}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'relative flex h-11 shrink-0 items-center gap-2 text-[13.5px] font-medium transition-colors',
                    active ? 'text-ink after:absolute after:inset-x-0 after:bottom-0 after:h-px after:bg-accent' : 'text-muted hover:text-ink',
                  )}
                >
                  {c.label}
                </Link>
              );
            })}
          </nav>
        </div>
        {chapter.modes && !deep && (
          <div className="hidden border-t border-line bg-surface/60 sm:block">
            <ModesNav chapter={chapter} base={base} />
          </div>
        )}
      </div>
      {/* Phones: the views scroll away with the page, to leave room for the content. */}
      {chapter.modes && !deep && (
        <div className="border-b border-line bg-surface/60 sm:hidden" data-print="hide">
          <ModesNav chapter={chapter} base={base} />
        </div>
      )}

      {/* Keyed by project so per-project page state (e.g. saved plan scenarios) never carries over. */}
      <Suspense fallback={<div className="mx-auto max-w-[1600px] px-4 py-8 sm:px-6 lg:px-8"><Skeleton className="h-96" /></div>}>
        <Outlet key={context.project.id} context={context} />
      </Suspense>

      <TaskFormDialog open={newTask.open} onOpenChange={(open) => setNewTask((s) => ({ ...s, open }))} project={project} defaults={newTask.defaults} />
    </div>
  );
}
