import { LoftHome } from '@/features/public/loft/LoftHome';
import { usePageMeta } from '@/lib/pageMeta';

/**
 * The front page: a journey in three places (the avalanche on the mountain, the crystals, the platform), drawn with
 * three.js behind ordinary, accessible page content. See features/public/loft.
 */
export function HomePage() {
  usePageMeta({ title: 'Niveloft', path: '/' });
  return <LoftHome />;
}
