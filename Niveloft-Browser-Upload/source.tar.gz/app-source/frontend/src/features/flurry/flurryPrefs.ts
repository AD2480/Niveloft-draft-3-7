/**
 * Flurry's settings, per person on this browser: whether the floating companion is shown or
 * minimised, whether it roams the page or keeps to its corner (and which corner is home), whether
 * the conversation is pinned beside the page, whether its sounds are on and whether it moves.
 *
 * A tiny external store (useSyncExternalStore), so the companion, the assistant panel and the
 * settings page all see the same values at once.
 */
import { useSyncExternalStore } from 'react';
import { readJson, writeStorage } from '@/lib/storage';

export interface FlurryPosition {
  /** Distance from the right edge of the window, in CSS pixels. */
  right: number;
  /** Distance from the bottom edge of the window, in CSS pixels. */
  bottom: number;
}

import { FLURRY_CORNERS, type FlurryCorner } from './flurryPlacement';

export { FLURRY_CORNERS, nearestCorner, oppositeCorner, overlaps, type FlurryCorner } from './flurryPlacement';

export interface FlurryPrefs {
  /** Not shown on pages at all (Alt+A still opens the assistant). */
  hidden: boolean;
  /** Shown as a small tab at the edge instead of the full figure. */
  minimised: boolean;
  /** Small sounds when Flurry opens, finishes or hits a problem. Off unless turned on. */
  sounds: boolean;
  /** No floating, blinking or reactions (also automatic under the system's reduced-motion setting). */
  still: boolean;
  /** Flies from place to place around the page until it's called (otherwise it stays in its corner). */
  roam: boolean;
  /** Home: where it rests when it isn't roaming, and where it naps. */
  corner: FlurryCorner;
  /** The conversation is docked beside the page (which makes room for it) instead of floating. */
  pinned: boolean;
}

export const DEFAULT_FLURRY_PREFS: FlurryPrefs = { hidden: false, minimised: false, sounds: false, still: false, roam: true, corner: 'bottom-right', pinned: false };

const listeners = new Set<() => void>();
const cache = new Map<string, FlurryPrefs>();

const key = (userId: number) => `projectflow.flurry.${userId}`;

function sanitise(raw: (Partial<FlurryPrefs> & { position?: FlurryPosition | null }) | null): FlurryPrefs {
  const p = { ...DEFAULT_FLURRY_PREFS, ...(raw ?? {}) };
  let corner: FlurryCorner = FLURRY_CORNERS.includes(p.corner) ? p.corner : 'bottom-right';
  // Settings saved before corners: a free position becomes the nearest bottom corner.
  if (raw && !raw.corner && raw.position && Number.isFinite(raw.position.right) && typeof window !== 'undefined') {
    corner = raw.position.right > window.innerWidth / 2 ? 'bottom-left' : 'bottom-right';
  }
  return { hidden: !!p.hidden, minimised: !!p.minimised, sounds: !!p.sounds, still: !!p.still, roam: p.roam !== false, corner, pinned: !!p.pinned };
}

export function readFlurryPrefs(userId: number): FlurryPrefs {
  const k = key(userId);
  let v = cache.get(k);
  if (!v) {
    v = sanitise(readJson<Partial<FlurryPrefs>>(k));
    cache.set(k, v);
  }
  return v;
}

export function updateFlurryPrefs(userId: number, change: Partial<FlurryPrefs>): FlurryPrefs {
  const next = sanitise({ ...readFlurryPrefs(userId), ...change });
  const k = key(userId);
  cache.set(k, next);
  writeStorage(k, JSON.stringify(next));
  for (const l of listeners) l();
  return next;
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  // Another tab changed the settings.
  const onStorage = (e: StorageEvent) => {
    if (e.key && e.key.startsWith('projectflow.flurry.')) {
      cache.delete(e.key);
      listener();
    }
  };
  window.addEventListener('storage', onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener('storage', onStorage);
  };
}

export function useFlurryPrefs(userId: number): [FlurryPrefs, (change: Partial<FlurryPrefs>) => void] {
  const prefs = useSyncExternalStore(subscribe, () => readFlurryPrefs(userId), () => DEFAULT_FLURRY_PREFS);
  return [prefs, (change) => updateFlurryPrefs(userId, change)];
}

/** Keeps a position on screen: at least `margin` from every edge. */
export function clampPosition(pos: FlurryPosition, size: { width: number; height: number }, viewport: { width: number; height: number }, margin = 8): FlurryPosition {
  const maxRight = Math.max(margin, viewport.width - size.width - margin);
  const maxBottom = Math.max(margin, viewport.height - size.height - margin);
  return { right: Math.min(Math.max(pos.right, margin), maxRight), bottom: Math.min(Math.max(pos.bottom, margin), maxBottom) };
}
