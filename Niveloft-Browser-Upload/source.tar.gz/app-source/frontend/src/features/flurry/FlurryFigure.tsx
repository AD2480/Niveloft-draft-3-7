import { useId } from 'react';
import { cn } from '@/lib/cn';

export type FlurryMood = 'idle' | 'thinking' | 'success' | 'error' | 'settled' | 'listening' | 'curious' | 'sleep' | 'wave';

/**
 * Flurry, the lightweight application version: a vector drawing of the character (a floating snow
 * creature with graphite eyes, tiny arms, a swept snow tuft and an ice-blue glow) that can blink,
 * look around, follow the pointer with its eyes (the --gx/--gy custom properties, set by whoever
 * moves it), think, react, wave, nap and settle. The detailed marketing artwork is the image in
 * public/flurry; this one is small, sharp at any size and cheap to animate.
 *
 * Decorative: it's always aria-hidden, and whatever it expresses is also said in words nearby.
 * `still` turns every animation off (reduced motion, or the person's own choice).
 */
export function FlurryFigure({ mood = 'idle', still = false, glow = true, className }: { mood?: FlurryMood; still?: boolean; glow?: boolean; className?: string }) {
  const id = useId().replace(/:/g, '');
  const u = (name: string) => `url(#${id}-${name})`;
  return (
    <svg
      viewBox="0 0 120 120"
      className={cn('flurry', `flurry--${mood}`, still && 'flurry--still', className)}
      aria-hidden="true"
      focusable="false"
      data-flurry-mood={mood}
    >
      <defs>
        <radialGradient id={`${id}-glow`} cx="50%" cy="55%" r="50%">
          <stop offset="0" stopColor="#a9cedf" stopOpacity=".4" />
          <stop offset=".7" stopColor="#a9cedf" stopOpacity=".12" />
          <stop offset="1" stopColor="#a9cedf" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}-body`} cx="40%" cy="38%" r="70%">
          <stop offset="0" stopColor="#ffffff" />
          <stop offset=".5" stopColor="#f5f9fc" />
          <stop offset=".82" stopColor="#dcecf6" />
          <stop offset="1" stopColor="#b9d9ee" />
        </radialGradient>
        <linearGradient id={`${id}-tint`} x1="0" y1="0" x2=".3" y2="1">
          <stop offset=".45" stopColor="#9cc9e4" stopOpacity="0" />
          <stop offset="1" stopColor="#86bde2" stopOpacity=".6" />
        </linearGradient>
        <linearGradient id={`${id}-tuft`} x1=".2" y1="1" x2=".6" y2="0">
          <stop offset=".35" stopColor="#ffffff" stopOpacity="0" />
          <stop offset="1" stopColor="#8fc3e6" stopOpacity=".85" />
        </linearGradient>
        <radialGradient id={`${id}-eye`} cx="42%" cy="38%" r="70%">
          <stop offset="0" stopColor="#546a80" />
          <stop offset=".55" stopColor="#22303d" />
          <stop offset="1" stopColor="#131b23" />
        </radialGradient>
        <linearGradient id={`${id}-arm`} x1="0" y1="1" x2="1" y2="0">
          <stop offset="0" stopColor="#f6fafd" />
          <stop offset=".55" stopColor="#e2f0f8" />
          <stop offset="1" stopColor="#9fcbe8" />
        </linearGradient>
      </defs>

      {glow && <ellipse className="flurry__glow" cx="60" cy="64" rx="56" ry="54" fill={u('glow')} />}

      <g className="flurry__float">
        <g className="flurry__body">
          <path className="flurry__arm-left" d="M34 80C28 84 21 88 19 93c-1.5 4.5 2.5 6.5 6.5 4C31 94 35 90 38 86z" fill={u('arm')} />
          <path
            d="M36 98C27 88 23 74 25 60c2-16 11-27 21-31-2-5-1-10 2-13.5 1 4.5 3 7.5 6 9.5 3-10 12-17 23-22-5 7-5 15-1.5 23 4.5-3.5 9.5-6 15-7-3.5 5-3.5 11-2 16 6.5 9 7.5 21 4.5 33-3 14-7 24-8 33 0 6 4 10 10 13-10 3-24 2-32-4-9 0-20-4-27-12z"
            fill={u('body')}
          />
          <path d="M46 29c-2-5-1-10 2-13.5 1 4.5 3 7.5 6 9.5 3-10 12-17 23-22-5 7-5 15-1.5 23 4.5-3.5 9.5-6 15-7-3.5 5-3.5 11-2 16-10.5-6-26.5-9-42.5-6z" fill={u('tuft')} />
          <path d="M25 60c-2 14 2 28 11 38 7 8 18 12 27 12 8 6 22 7 32 4-6-3-10-7-10-13 1-9 5-19 8-33-13 8-43 8-68-8z" fill={u('tint')} />
          <path className="flurry__arm-right" d="M83 82c5-10 11-20 15.5-26.5 2.5-4.5 8-5.5 9.5-1 1.5 5.5-4 14-16 29.5z" fill={u('arm')} />

          <g className="flurry__eyes">
            <g className="flurry__gaze">
              <g className="flurry__eye flurry__eye--left">
                <ellipse cx="48" cy="60" rx="7.6" ry="8.6" fill={u('eye')} />
                <circle cx="50.6" cy="56" r="2.5" fill="#fff" />
                <circle cx="45.6" cy="63.4" r="1" fill="#fff" opacity=".55" />
              </g>
              <g className="flurry__eye flurry__eye--right">
                <ellipse cx="72.5" cy="59" rx="7.6" ry="8.6" fill={u('eye')} />
                <circle cx="75.1" cy="55" r="2.5" fill="#fff" />
                <circle cx="70.1" cy="62.4" r="1" fill="#fff" opacity=".55" />
              </g>
            </g>
          </g>
          {mood === 'error' ? (
            <path d="M56.6 72.6q4-2.4 8 0" fill="none" stroke="#1d2a36" strokeWidth="1.9" strokeLinecap="round" />
          ) : mood === 'success' ? (
            <path d="M55.4 70q5.2 6.2 10.4 0" fill="#1d2a36" stroke="#1d2a36" strokeWidth="1.6" strokeLinejoin="round" />
          ) : (
            <path d="M56.2 70.5q4.4 3.9 8.8-.1" fill="none" stroke="#1d2a36" strokeWidth="1.9" strokeLinecap="round" />
          )}
          <g fill="#fff" opacity=".7">
            <circle cx="40" cy="48" r=".6" />
            <circle cx="66" cy="86" r=".5" />
            <circle cx="80" cy="44" r=".5" />
            <circle cx="53" cy="95" r=".6" />
            <circle cx="34" cy="72" r=".5" />
          </g>
        </g>
      </g>

      {/* Thinking: three flakes circle the head. */}
      <g className="flurry__flakes" fill="#8fc3e6">
        <path d="M60 4.5l1.6 2.8-1.6 2.8-1.6-2.8z" />
        <path d="M60 4.5l1.6 2.8-1.6 2.8-1.6-2.8z" />
        <path d="M60 4.5l1.6 2.8-1.6 2.8-1.6-2.8z" />
      </g>
      {/* Napping: a couple of small z's drift up. */}
      <g className="flurry__zzz" fill="none" stroke="#8fc3e6" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M88 30h7l-7 8h7" />
        <path d="M100 16h5l-5 6h5" />
      </g>
      {/* Success: a few sparkles, once. */}
      <g className="flurry__sparkles" fill="#e9c99a">
        <path d="M104 30l1.8 4.2 4.2 1.8-4.2 1.8-1.8 4.2-1.8-4.2-4.2-1.8 4.2-1.8z" />
        <path d="M16 44l1.3 3 3 1.3-3 1.3-1.3 3-1.3-3-3-1.3 3-1.3z" />
        <path d="M98 94l1.1 2.5 2.5 1.1-2.5 1.1-1.1 2.5-1.1-2.5-2.5-1.1 2.5-1.1z" />
      </g>
    </svg>
  );
}

/** The detailed artwork (marketing version), with the right size for where it's shown. */
export function FlurryPortrait({ className, size = 480, alt = 'Flurry, Niveloft’s AI assistant: a small, friendly snow creature with a swept snow tuft, waving.', priority = false }: { className?: string; size?: 240 | 480 | 960; alt?: string; priority?: boolean }) {
  const srcSet = size === 240 ? '/flurry/flurry-240.webp 1x, /flurry/flurry-480.webp 2x' : size === 480 ? '/flurry/flurry-480.webp 1x, /flurry/flurry-960.webp 2x' : '/flurry/flurry-960.webp';
  return (
    <img
      src={`/flurry/flurry-${size}.webp`}
      srcSet={srcSet}
      width={size}
      height={size}
      alt={alt}
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      className={cn('select-none', className)}
      draggable={false}
    />
  );
}
