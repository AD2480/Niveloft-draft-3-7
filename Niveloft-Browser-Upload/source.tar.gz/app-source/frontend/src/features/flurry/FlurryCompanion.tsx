import { Check, Mic, MoreHorizontal } from 'lucide-react';
import { useEffect, useLayoutEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { toast } from 'sonner';
import { useAppSelector } from '@/app/store';
import { Menu, MenuCheckItem, MenuContent, MenuItem, MenuLabel, MenuSeparator, MenuTrigger } from '@/components/ui/Menu';
import { useAssistant } from '@/features/assistant/assistantContext';
import { cn } from '@/lib/cn';
import { useMediaQuery } from '@/lib/hooks';
import { FlurryFigure, type FlurryMood } from './FlurryFigure';
import { FLURRY_CORNERS, nearestCorner, oppositeCorner, overlaps, useFlurryPrefs, type FlurryCorner } from './flurryPrefs';
import { clampInto, perchBeside, type Box, type Pt, type Size } from './roam';
import { busyUnder, overlayRects, useFlurryRoam } from './useFlurryRoam';

/** A press that moves less than this is a click, not a drag. */
const DRAG_THRESHOLD = 5;
/** Space between Flurry and the window's edges (and the sidebar, and the top bar). */
export const CORNER_GAP = 20;
/** The top bar's height: top corners sit below it. */
export const TOP_BAR = 56;
/** After you put Flurry somewhere, it stays there this long before roaming again. */
const DROP_STAY = 30_000;
/** A quiet spell this long and Flurry naps in its home corner. */
const NAP_AFTER = 120_000;
/** Typing: Flurry holds still until this long after the last key. */
const TYPING_PAUSE = 4000;

export const CORNER_LABEL: Record<FlurryCorner, string> = {
  'bottom-right': 'Bottom right',
  'bottom-left': 'Bottom left',
  'top-right': 'Top right',
  'top-left': 'Top left',
};

/** Where the left edge of the page is (beside the sidebar on large screens). */
export function pageLeft(): number {
  if (typeof window === 'undefined' || !window.matchMedia('(min-width: 1024px)').matches) return 0;
  return parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--app-sidebar')) || 0;
}

/** The top-left point for something of `size` resting in `corner`. */
export function cornerPoint(corner: FlurryCorner, size: { width: number; height: number }): { x: number; y: number } {
  const [v, h] = corner.split('-');
  const x = h === 'left' ? pageLeft() + CORNER_GAP : window.innerWidth - size.width - CORNER_GAP;
  const y = v === 'top' ? TOP_BAR + CORNER_GAP : window.innerHeight - size.height - CORNER_GAP;
  return { x: Math.max(8, x), y: Math.max(8, y) };
}

const isField = (el: Element | null): el is HTMLElement =>
  el instanceof HTMLElement && (el.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName)) && (el as HTMLInputElement).type !== 'checkbox' && (el as HTMLInputElement).type !== 'radio';

const rectOf = (el: Element): Box => {
  const r = el.getBoundingClientRect();
  return { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
};

/**
 * Flurry, on every signed-in page. Click it (or press Alt+A, or say "Hey Flurry") to open the
 * assistant.
 *
 * - It roams: it rests a while, then flies to another spot, keeping to the edges and the empty
 *   parts of the page. It never lands on the field you're typing in, under the pointer, on an open
 *   menu or dialog, or back where it just was. Its eyes follow the pointer; point at it and it
 *   stops and looks at you. After a couple of quiet minutes it naps in its home corner.
 * - Called, it flies to the conversation and perches beside it for as long as it's open, then
 *   goes back to roaming.
 * - While you type it holds still; if it's over the field you start typing in, it gets out of the
 *   way first.
 * - Drag it anywhere: it stays there a while, and the nearest corner becomes its home.
 * - "Let Flurry roam" off, "Keep Flurry still", the minimised tab or the system's reduced-motion
 *   setting keep it in its home corner (as the only movement: none at all when still).
 * - It never pops up on its own and has no speech bubbles.
 * - On phones it's a small button that moves only along the bottom edge.
 */
export function FlurryCompanion() {
  const a = useAssistant();
  const userId = useAppSelector((s) => s.auth.user?.id ?? 0);
  const [prefs, setPrefs] = useFlurryPrefs(userId);
  const compact = !useMediaQuery('(min-width: 640px)');
  const reduceMotion = useMediaQuery('(prefers-reduced-motion: reduce)');
  const still = prefs.still || reduceMotion;
  const roaming = prefs.roam && !still && !prefs.minimised;
  const root = useRef<HTMLDivElement>(null);
  const button = useRef<HTMLButtonElement>(null);
  const [size, setSize] = useState<Size>({ width: 64, height: 64 });
  const [, setViewport] = useState(0);
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [dropped, setDropped] = useState<Pt | null>(null);
  const [perch, setPerch] = useState<Pt | null>(null);
  const [typing, setTyping] = useState(false);
  const [wave, setWave] = useState(false);
  // In its corner (not roaming), it steps aside to the other corner on that edge.
  const [dodge, setDodge] = useState<FlurryCorner | null>(null);
  const drag = useRef<{ x: number; y: number; start: Pt; moved: boolean; id: number } | null>(null);
  const suppressClick = useRef(false);
  // On phones the conversation covers the screen, so Flurry steps out while it's open.
  const hiddenNow = prefs.hidden || (compact && a.open);
  const corner = dodge ?? prefs.corner;

  // Its size, for placing it (the figure and its options button, or the small tab).
  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const w = el.offsetWidth;
    const h = el.offsetHeight;
    if (w && h) setSize((s) => (s.width === w && s.height === h ? s : { width: w, height: h }));
  }, [compact, prefs.minimised, hiddenNow]);
  useEffect(() => {
    const onResize = () => setViewport((n) => n + 1);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  const home = (): Pt =>
    compact ? { x: corner.endsWith('left') ? 16 : window.innerWidth - size.width - 16, y: window.innerHeight - size.height - 16 } : cornerPoint(corner, size);
  const area = (): Box =>
    compact
      ? { left: 16, top: TOP_BAR + 16, right: window.innerWidth - 16, bottom: window.innerHeight - 16 }
      : { left: pageLeft() + CORNER_GAP, top: TOP_BAR + CORNER_GAP, right: window.innerWidth - CORNER_GAP, bottom: window.innerHeight - CORNER_GAP };
  const avoid = (): Box[] => {
    const out = overlayRects();
    const f = document.activeElement;
    if (isField(f) && !root.current?.contains(f)) out.push(rectOf(f));
    return out;
  };

  const anchor: Pt | null = a.open && perch ? perch : dropped ? dropped : !roaming && typeof window !== 'undefined' ? clampInto(home(), { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight }, size) : null;

  const roam = useFlurryRoam({
    el: root,
    size,
    roam: roaming && !a.open && !hiddenNow,
    motion: !still,
    mode: compact ? 'bottom' : 'free',
    area,
    anchor,
    hold: hovered || focused || menuOpen || dragging || typing,
    avoid,
    busy: (b) => busyUnder(b, root.current),
    home,
    napAfter: NAP_AFTER,
    restMs: compact ? [9000, 16000] : [6500, 14000],
  });

  // Called: fly to the conversation and perch beside it while it's open.
  useEffect(() => {
    if (!a.open || compact) {
      setPerch(null);
      return;
    }
    let raf = 0;
    let ro: ResizeObserver | null = null;
    const measure = () => {
      const panel = document.querySelector('[data-assistant-panel]');
      if (!panel) {
        raf = requestAnimationFrame(measure);
        return;
      }
      const next = perchBeside(rectOf(panel), size, { width: window.innerWidth, height: window.innerHeight }, 12, TOP_BAR + 8);
      setPerch((p) => (p && Math.abs(p.x - next.x) < 1 && Math.abs(p.y - next.y) < 1 ? p : next));
      if (!ro && typeof ResizeObserver !== 'undefined') {
        ro = new ResizeObserver(() => measure());
        ro.observe(panel);
      }
    };
    measure();
    // Once more after the panel's entrance has finished moving.
    const settle = window.setTimeout(measure, 400);
    window.addEventListener('resize', measure);
    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(settle);
      ro?.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [a.open, compact, size]);

  // A wave on arriving.
  useEffect(() => {
    if (!a.open || still) return;
    setWave(true);
    const t = window.setTimeout(() => setWave(false), 1600);
    return () => window.clearTimeout(t);
  }, [a.open, still]);

  // Put down somewhere: stay there a while, then roam again.
  useEffect(() => {
    if (!dropped) return;
    const t = window.setTimeout(() => setDropped(null), DROP_STAY);
    return () => window.clearTimeout(t);
  }, [dropped]);
  useEffect(() => {
    if (!roaming) setDropped(null);
  }, [roaming]);

  // Typing: hold still; if Flurry is over the field, get out of the way first.
  useEffect(() => {
    if (hiddenNow) return;
    let clear = 0;
    let quiet = 0;
    const own = (el: Element) => root.current?.contains(el) || !!el.closest('[data-assistant-panel]');
    const onFocusIn = (e: FocusEvent) => {
      const el = e.target as Element | null;
      if (!isField(el) || own(el)) return;
      window.clearTimeout(clear);
      const field = rectOf(el);
      if (roaming) {
        if (roam.covers(field, 24)) roam.moveNow(field);
        return;
      }
      if (compact) return;
      // In its corner: compare with where it rests, not where it happens to be mid-move.
      const at = cornerPoint(prefs.corner, size);
      if (overlaps({ left: at.x, top: at.y, right: at.x + size.width, bottom: at.y + size.height }, field, 24)) setDodge((d) => d ?? oppositeCorner(prefs.corner));
    };
    const onFocusOut = () => {
      window.clearTimeout(clear);
      clear = window.setTimeout(() => {
        if (!isField(document.activeElement)) setDodge(null);
      }, 500);
    };
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as Element | null;
      if (!isField(el) || own(el)) return;
      setTyping(true);
      window.clearTimeout(quiet);
      quiet = window.setTimeout(() => setTyping(false), TYPING_PAUSE);
    };
    document.addEventListener('focusin', onFocusIn);
    document.addEventListener('focusout', onFocusOut);
    document.addEventListener('keydown', onKey, true);
    return () => {
      window.clearTimeout(clear);
      window.clearTimeout(quiet);
      document.removeEventListener('focusin', onFocusIn);
      document.removeEventListener('focusout', onFocusOut);
      document.removeEventListener('keydown', onKey, true);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [compact, hiddenNow, roaming, prefs.corner, size]);
  // A new home corner of your own choosing ends any stepping aside.
  useEffect(() => setDodge(null), [prefs.corner]);

  // When the panel closes with focus inside it (or lost), focus comes back to Flurry.
  const wasOpen = useRef(a.open);
  useEffect(() => {
    if (wasOpen.current && !a.open) {
      const active = document.activeElement;
      const panel = document.querySelector('[data-assistant-panel]');
      if (!active || active === document.body || panel?.contains(active)) button.current?.focus();
    }
    wasOpen.current = a.open;
  }, [a.open]);

  if (hiddenNow) return null;

  const wakeText = a.wakeActive ? 'Listening for “Hey Flurry”.' : a.wakeEnabled ? 'Wake phrase on, not listening right now.' : '';
  const label = a.open ? 'Flurry is here: go to the question box' : `Ask Flurry, the AI assistant (Alt+A)${wakeText ? `. ${wakeText}` : ''}`;

  // Flurry's expression: what the assistant is doing first, then what Flurry itself is up to.
  let mood: FlurryMood = a.mood;
  if (a.mood === 'idle' || a.mood === 'settled') {
    if (wave) mood = 'wave';
    else if (roam.phase === 'nap') mood = 'sleep';
    else if (a.mood === 'idle' && (roam.curious || hovered)) mood = 'curious';
  }
  const flying = roam.phase === 'flying';

  const activate = () => {
    if (a.open) {
      document.querySelector<HTMLTextAreaElement>('[data-assistant-input]')?.focus();
      setWave(true);
      window.setTimeout(() => setWave(false), 1400);
    } else a.setOpen(true);
  };

  const onPointerDown = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const at = roam.pos.current;
    if (compact || a.open || e.button !== 0 || !at) return;
    drag.current = { x: e.clientX, y: e.clientY, start: at, moved: false, id: e.pointerId };
    // Capture at once, so a quick flick that leaves the button still drags it.
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const d = drag.current;
    if (!d || d.id !== e.pointerId) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
    if (!d.moved) {
      d.moved = true;
      setDragging(true);
    }
    roam.place({ x: Math.min(Math.max(8, d.start.x + dx), window.innerWidth - size.width - 8), y: Math.min(Math.max(8, d.start.y + dy), window.innerHeight - size.height - 8) });
  };
  const endDrag = (e: ReactPointerEvent<HTMLButtonElement>) => {
    const d = drag.current;
    if (!d || d.id !== e.pointerId) return;
    drag.current = null;
    if (!d.moved) return;
    suppressClick.current = true;
    setDragging(false);
    const at = roam.pos.current ?? d.start;
    const next = nearestCorner(at.x + size.width / 2, at.y + size.height / 2, { width: window.innerWidth, height: window.innerHeight });
    // Roaming: it stays where it was put for a while. Either way the nearest corner becomes home.
    if (roaming) setDropped({ ...at });
    if (next !== prefs.corner) setPrefs({ corner: next });
    else if (!roaming) roam.place(cornerPoint(next, size));
  };

  const hide = () => {
    setPrefs({ hidden: true });
    toast('Flurry is hidden', { description: 'Alt+A and “Ask Flurry” in the sidebar still open it. Show Flurry again in Settings → Flurry.' });
  };

  const common = {
    ref: root,
    'data-print': 'hide',
    'data-flurry-corner': corner,
    'data-flurry-phase': roam.phase,
    'data-flurry-roaming': roaming ? '' : undefined,
    'data-flurry-perched': a.open && perch ? '' : undefined,
    'data-flurry-dodging': dodge ? '' : undefined,
    onPointerEnter: (e: ReactPointerEvent) => e.pointerType !== 'touch' && setHovered(true),
    onPointerLeave: () => setHovered(false),
    // Keyboard focus holds it still (so it's where you left it); a click's focus doesn't.
    onFocus: (e: React.FocusEvent) => setFocused((e.target as Element).matches(':focus-visible')),
    onBlur: (e: React.FocusEvent) => !e.currentTarget.contains(e.relatedTarget as Node | null) && setFocused(false),
  } as const;

  // Phones: a small button that roams along the bottom edge.
  if (compact) {
    return (
      <div {...common} data-flurry-companion="compact" className="invisible fixed top-0 left-0 z-30">
        <button
          ref={button}
          type="button"
          data-assistant-button=""
          onClick={activate}
          className="relative flex size-12 items-center justify-center rounded-full border border-line bg-surface shadow-float"
          style={{ transform: 'rotate(var(--tilt, 0deg))' }}
          aria-label={label}
          title="Ask Flurry"
        >
          <FlurryFigure mood={mood === 'settled' ? 'idle' : mood} still={still} glow={false} className={cn('size-9', flying && 'flurry-flying')} />
          {a.wakeEnabled && <WakeDot active={a.wakeActive} />}
        </button>
      </div>
    );
  }

  const settled = !prefs.minimised && a.mood === 'settled' && !a.open;
  const menuSide = corner.startsWith('top') ? 'bottom' : 'top';
  const onLeft = corner.endsWith('left');

  return (
    <div
      {...common}
      data-flurry-companion={prefs.minimised ? 'minimised' : 'full'}
      className={cn('group/flurry invisible fixed top-0 left-0 z-30 flex items-end gap-1.5', onLeft && 'flex-row-reverse', dragging && 'select-none')}
    >
      <Menu onOpenChange={setMenuOpen}>
        <MenuTrigger asChild>
          <button
            type="button"
            className={cn(
              'mb-1 flex size-8 items-center justify-center rounded-full border border-line bg-surface text-muted shadow-card transition-opacity hover:text-ink focus-visible:opacity-100',
              'opacity-0 group-hover/flurry:opacity-100 group-focus-within/flurry:opacity-100 data-[state=open]:opacity-100',
            )}
            aria-label="Flurry options"
            data-flurry-options=""
          >
            <MoreHorizontal className="size-4" aria-hidden="true" />
          </button>
        </MenuTrigger>
        <MenuContent align={onLeft ? 'start' : 'end'} side={menuSide} className="w-64">
          <MenuItem onSelect={() => a.setOpen(true)}>Ask Flurry · Alt+A</MenuItem>
          <MenuItem onSelect={() => setPrefs({ minimised: !prefs.minimised })}>{prefs.minimised ? 'Show the full figure' : 'Minimise to a small tab'}</MenuItem>
          <MenuSeparator />
          <MenuCheckItem checked={roaming} disabled={still || prefs.minimised} onSelect={() => setPrefs({ roam: !prefs.roam })}>
            {still ? 'Roam (off while Flurry is still)' : 'Let Flurry roam the page'}
          </MenuCheckItem>
          <MenuLabel>Home corner</MenuLabel>
          {FLURRY_CORNERS.map((c) => (
            <MenuCheckItem key={c} checked={prefs.corner === c} onSelect={() => setPrefs({ corner: c })}>
              {CORNER_LABEL[c]}
            </MenuCheckItem>
          ))}
          <MenuSeparator />
          <MenuCheckItem checked={prefs.sounds} onSelect={() => setPrefs({ sounds: !prefs.sounds })}>
            Sounds
          </MenuCheckItem>
          <MenuCheckItem checked={still} disabled={reduceMotion} onSelect={() => setPrefs({ still: !prefs.still })}>
            {reduceMotion ? 'Still (your system reduces motion)' : 'Keep Flurry still'}
          </MenuCheckItem>
          <MenuSeparator />
          <MenuItem onSelect={hide}>Hide Flurry</MenuItem>
        </MenuContent>
      </Menu>

      <button
        ref={button}
        type="button"
        data-assistant-button=""
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onClick={(e) => {
          if (suppressClick.current) {
            suppressClick.current = false;
            e.preventDefault();
            return;
          }
          activate();
        }}
        aria-label={label}
        title={a.open ? 'Flurry is here' : roaming ? 'Ask Flurry · Alt+A · drag to put it somewhere' : 'Ask Flurry · Alt+A · drag to another corner'}
        className={cn(
          'relative flex touch-none items-center',
          dragging ? 'cursor-grabbing' : 'cursor-pointer',
          prefs.minimised
            ? 'h-11 gap-2 rounded-full border border-line bg-surface py-1 pr-4 pl-1 shadow-float hover:border-line-strong'
            : 'size-14 justify-center rounded-full ring-line-strong transition-[opacity,box-shadow,scale,translate] duration-500 hover:bg-surface/60 hover:ring-1',
          settled && 'translate-y-1 scale-95 opacity-60',
        )}
      >
        {prefs.minimised ? (
          <>
            <FlurryFigure mood={mood} still={still} glow={false} className="size-9" />
            <span className="text-[13px] font-medium text-ink">Ask Flurry</span>
          </>
        ) : (
          <span className="block" style={{ transform: 'rotate(var(--tilt, 0deg))' }}>
            <FlurryFigure mood={mood} still={still} glow={false} className={cn('size-14 drop-shadow-[0_6px_10px_rgb(23_33_43/0.16)]', flying && 'flurry-flying')} />
          </span>
        )}
        {a.wakeEnabled && <WakeDot active={a.wakeActive} />}
      </button>
    </div>
  );
}

/** Shows that the "Hey Flurry" listener is on, so listening is never hidden. */
function WakeDot({ active }: { active: boolean }) {
  return (
    <span className="absolute -top-0.5 -right-0.5 flex items-center gap-0.5 rounded-full border border-line bg-surface px-1 py-0.5 shadow-card" aria-hidden="true">
      <Mic className={cn('size-3 text-accent', !active && 'opacity-50')} />
      {active ? <span className="size-1.5 animate-pulse rounded-full bg-[var(--model-review)]" /> : <Check className="size-2.5 text-muted" />}
    </span>
  );
}
