import { lazy, Suspense, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router';
import { useBoardTasksQuery, useDependenciesQuery } from '@/api/endpoints';
import { Card, CardHeader } from '@/components/ui/Card';
import { Skeleton } from '@/components/ui/Spinner';
import { cn } from '@/lib/cn';
import { snowSentence, snowSummary, snowTasks, type SnowTask } from './avalancheModel';

// three.js is only downloaded when the avalanche is shown.
const AvalancheCanvas = lazy(() => import('./AvalancheCanvas'));

/**
 * The project as an avalanche: the same picture as the front page, made from this project's real
 * tasks. Approved work has settled into rows on the mountain; work waiting for review hovers over
 * its place; the rest is still coming down; what holds other work up glows amber. Beside it, the
 * same thing in words and as a list (the picture is decoration for screen readers).
 */
export function ProjectAvalancheCard({ projectId }: { projectId: number }) {
  const tasks = useBoardTasksQuery(projectId);
  const deps = useDependenciesQuery(projectId);
  const list = useMemo(() => snowTasks(tasks.data ?? [], deps.data ?? []), [tasks.data, deps.data]);
  const s = snowSummary(list);
  const [active, setActive] = useState<number | null>(null);
  const index = useMemo(() => new Map(list.map((t, i) => [t.id, i])), [list]);

  const group = (title: string, items: SnowTask[], tone: string, note?: ReactNode) =>
    items.length > 0 && (
      <section aria-label={title}>
        <h3 className="flex items-baseline gap-2 px-4 pt-3 pb-1 font-hud text-[11px] tracking-[0.04em] text-muted uppercase">
          <span className={cn('size-2 shrink-0 rounded-[2px]', tone)} aria-hidden="true" />
          {title}
          <span className="tabular">{items.length}</span>
          {note}
        </h3>
        <ul>
          {items.map((t) => (
            <li key={t.id}>
              <Link
                to={`/projects/${projectId}/tasks/${t.id}`}
                onMouseEnter={() => setActive(index.get(t.id) ?? null)}
                onMouseLeave={() => setActive(null)}
                onFocus={() => setActive(index.get(t.id) ?? null)}
                onBlur={() => setActive(null)}
                className={cn('flex items-baseline gap-3 px-4 py-1.5 text-[13px] transition-colors', active === index.get(t.id) ? 'bg-surface-2' : 'hover:bg-surface-2')}
              >
                <span className="w-16 shrink-0 font-hud text-[11.5px] text-muted">{t.key}</span>
                <span className="min-w-0 flex-1 truncate text-ink">{t.title}</span>
                {t.overdue && <span className="shrink-0 text-[11.5px] text-danger">overdue</span>}
              </Link>
            </li>
          ))}
        </ul>
      </section>
    );

  return (
    <Card data-project-avalanche="">
      <CardHeader
        title={
          <span className="flex items-baseline gap-2">
            <span className="font-hud text-[12px] font-normal text-muted" aria-hidden="true">
              //////
            </span>
            The avalanche
          </span>
        }
        description="Every block is a task. Approved work has settled into rows; work in review hovers over its place; the rest is still coming down. Amber holds other work up. Nothing here changes a task."
      />
      <div className="grid gap-px border-t border-line bg-line lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="relative h-[280px] bg-surface sm:h-[340px]" aria-hidden="true">
          {tasks.isLoading ? (
            <Skeleton className="h-full w-full rounded-none" />
          ) : (
            <Suspense fallback={<Skeleton className="h-full w-full rounded-none" />}>
              <AvalancheCanvas list={list} projectId={projectId} active={active} onActive={setActive} />
            </Suspense>
          )}
        </div>
        <div className="flex min-h-0 flex-col bg-surface">
          <p className="border-b border-line px-4 py-3 text-[13px] leading-relaxed text-ink-2" data-avalanche-summary="">
            {tasks.isLoading ? 'Reading the tasks…' : tasks.isError ? 'The tasks couldn’t be loaded, so the avalanche isn’t shown. Nothing about them is assumed.' : snowSentence(list)}
          </p>
          <div className="max-h-[280px] flex-1 overflow-y-auto pb-2 lg:max-h-[288px]" data-avalanche-list="">
            {group(
              'Holding others up',
              list.filter((t) => t.blocking),
              'bg-[var(--model-review)]',
            )}
            {group(
              'Waiting for review',
              list.filter((t) => t.state === 'review' && !t.blocking),
              'bg-ink-2',
            )}
            {group(
              'Still coming down',
              list.filter((t) => t.state === 'moving' && !t.blocking),
              'bg-line-strong',
            )}
            {s.settled > 0 && (
              <details className="disclosure">
                <summary className="flex cursor-pointer items-baseline gap-2 px-4 pt-3 pb-1 font-hud text-[11px] tracking-[0.04em] text-muted uppercase hover:text-ink">
                  <span className="size-2 shrink-0 rounded-[2px] border border-line-strong bg-surface" aria-hidden="true" />
                  Settled (approved) <span className="tabular">{s.settled}</span>
                </summary>
                {group(
                  'Approved',
                  list.filter((t) => t.state === 'settled'),
                  'bg-surface border border-line-strong',
                )}
              </details>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
