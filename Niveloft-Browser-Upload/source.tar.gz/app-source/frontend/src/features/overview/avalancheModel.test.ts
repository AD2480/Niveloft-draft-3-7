import { describe, expect, it } from 'vitest';
import { snowSentence, snowSummary, snowTargets, snowTasks } from './avalancheModel';

const t = (id: number, status: 'TODO' | 'IN_PROGRESS' | 'IN_REVIEW' | 'DONE', extra: { overdue?: boolean; completedAt?: string } = {}) => ({
  id,
  key: `ONB-${id}`,
  title: `Task ${id}`,
  status,
  overdue: extra.overdue ?? false,
  completedAt: extra.completedAt ?? null,
});
const dep = (blocker: { id: number; status: string }, blocked: { id: number; status: string }) => ({ blocker, blocked }) as never;

describe('a project as an avalanche', () => {
  const tasks = [t(1, 'DONE', { completedAt: '2026-09-10' }), t(2, 'TODO'), t(3, 'IN_REVIEW'), t(4, 'DONE', { completedAt: '2026-09-02' }), t(5, 'IN_PROGRESS', { overdue: true }), t(6, 'TODO')];
  const deps = [dep({ id: 6, status: 'TODO' }, { id: 2, status: 'TODO' }), dep({ id: 4, status: 'DONE' }, { id: 5, status: 'IN_PROGRESS' })];

  it('settles approved work first, in the order it was approved, then review, then what moves', () => {
    const list = snowTasks(tasks, deps);
    expect(list.map((x) => x.key)).toEqual(['ONB-4', 'ONB-1', 'ONB-3', 'ONB-6', 'ONB-5', 'ONB-2']);
    expect(list.map((x) => x.state)).toEqual(['settled', 'settled', 'review', 'moving', 'moving', 'moving']);
  });

  it('marks only unfinished work that holds up unfinished work', () => {
    const list = snowTasks(tasks, deps);
    expect(list.filter((x) => x.blocking).map((x) => x.key)).toEqual(['ONB-6']);
  });

  it('puts approved blocks in their rows, review just above, the rest in the stream', () => {
    const { targets, warm } = snowTargets(snowTasks(tasks, deps));
    expect(targets).toEqual([1, 1, 0.85, 0, 0, 0]);
    expect(warm).toEqual([0, 0, 0, 1, 0, 0]);
  });

  it('says the same thing in words', () => {
    const list = snowTasks(tasks, deps);
    expect(snowSummary(list)).toEqual({ total: 6, settled: 2, review: 1, moving: 3, blocking: 1 });
    expect(snowSentence(list)).toBe('2 of 6 tasks approved and settled, 1 waiting for review, 3 still moving. 1 unfinished task holds other work up.');
    expect(snowSentence([])).toMatch(/No tasks yet/);
  });

  it('never approves anything itself: a task only settles when its status is Done', () => {
    const list = snowTasks([t(1, 'IN_REVIEW'), t(2, 'IN_PROGRESS')], []);
    expect(snowTargets(list).targets.every((x) => x < 1)).toBe(true);
  });
});
