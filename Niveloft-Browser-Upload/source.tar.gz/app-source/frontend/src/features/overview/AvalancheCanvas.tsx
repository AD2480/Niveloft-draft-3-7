import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { ProjectAvalancheScene } from '@/three/ProjectAvalanche';
import { onThemeChange, webglAvailable } from '@/three/sceneUtils';
import { snowTargets, type SnowTask } from './avalancheModel';

const STATE_LABEL = { settled: 'Approved · settled', review: 'Waiting for review', moving: 'Still coming down' } as const;

/** The 3D avalanche for a project (three.js, loaded lazily). The list beside it says the same. */
export default function AvalancheCanvas({ list, projectId, active, onActive }: { list: SnowTask[]; projectId: number; active: number | null; onActive: (i: number | null) => void }) {
  const host = useRef<HTMLDivElement>(null);
  const scene = useRef<ProjectAvalancheScene | null>(null);
  const navigate = useNavigate();
  const canRender = useMemo(() => webglAvailable(), []);
  const [hover, setHover] = useState<{ i: number; x: number; y: number } | null>(null);
  const listRef = useRef(list);
  listRef.current = list;

  useEffect(() => {
    if (!canRender || !host.current) return;
    const s = new ProjectAvalancheScene(
      host.current,
      (i, x, y) => {
        setHover(i === null ? null : { i, x, y });
        onActive(i);
      },
      (i) => {
        const t = listRef.current[i];
        if (t) navigate(`/projects/${projectId}/tasks/${t.id}`);
      },
    );
    scene.current = s;
    const stop = onThemeChange(() => s.refreshTheme());
    return () => {
      stop();
      s.dispose();
      scene.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canRender, navigate, projectId]);

  useEffect(() => {
    const { targets, warm } = snowTargets(list);
    scene.current?.setBlocks(list.map((t, i) => ({ key: t.key, target: targets[i], warm: warm[i] })));
  }, [list]);

  useEffect(() => {
    if (!hover) scene.current?.highlight(active);
  }, [active, hover]);

  if (!canRender) {
    return <p className="flex h-full items-center justify-center px-6 text-center text-[13px] text-muted">This browser can’t show the 3D avalanche. The list beside it says the same.</p>;
  }
  const t = hover ? list[hover.i] : undefined;
  return (
    <>
      <div ref={host} className="absolute inset-0" data-avalanche-canvas="" />
      {t && hover && (
        <div className="pointer-events-none fixed z-50 border border-line bg-surface px-3 py-2 shadow-pop" style={{ left: hover.x, top: hover.y, transform: 'translate(-50%, calc(-100% - 18px))' }} data-avalanche-tip="">
          <p className="font-hud text-[11.5px] text-muted">{t.key}</p>
          <p className="max-w-[260px] truncate text-[13px] font-medium text-ink">{t.title}</p>
          <p className="mt-0.5 text-[11.5px] text-muted">
            {STATE_LABEL[t.state]}
            {t.blocking ? ' · holds other work up' : ''}
            {t.overdue ? ' · overdue' : ''}
          </p>
        </div>
      )}
    </>
  );
}
