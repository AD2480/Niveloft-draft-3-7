/**
 * A project's tasks as an avalanche: approved work has settled into rows on the mountain, work
 * waiting for review hovers just above its place, and everything else is still coming down the
 * slope. Tasks that hold others up glow. Pure, so it's tested, and so the picture and its text
 * equivalent always say the same thing.
 */
import type { TaskStatus } from '@/api/types';

export type SnowState = 'settled' | 'review' | 'moving';

export interface SnowTask {
  id: number;
  key: string;
  title: string;
  state: SnowState;
  /** Not done, and at least one unfinished task waits on it. */
  blocking: boolean;
  overdue: boolean;
}

interface TaskLike {
  id: number;
  key: string;
  title: string;
  status: TaskStatus;
  overdue: boolean;
  completedAt: string | null;
}
interface DependencyLike {
  blocker: { id: number; status: TaskStatus };
  blocked: { id: number; status: TaskStatus };
}

const stateOf = (s: TaskStatus): SnowState => (s === 'DONE' ? 'settled' : s === 'IN_REVIEW' ? 'review' : 'moving');
const keyNumber = (k: string) => Number(/(\d+)$/.exec(k)?.[1] ?? 0);

/**
 * The tasks in the order they take their places: settled work first (lowest rows, in the order
 * it was approved), then work in review, then what's still moving (what holds others up first,
 * then what's overdue, then by key).
 */
export function snowTasks(tasks: readonly TaskLike[], deps: readonly DependencyLike[]): SnowTask[] {
  const blocking = new Set<number>();
  for (const d of deps) if (d.blocker.status !== 'DONE' && d.blocked.status !== 'DONE') blocking.add(d.blocker.id);
  const rank: Record<SnowState, number> = { settled: 0, review: 1, moving: 2 };
  const withDone = tasks.map((t) => ({ t, state: stateOf(t.status) }));
  withDone.sort((a, b) => {
    if (a.state !== b.state) return rank[a.state] - rank[b.state];
    if (a.state === 'settled') return (a.t.completedAt ?? '').localeCompare(b.t.completedAt ?? '') || keyNumber(a.t.key) - keyNumber(b.t.key);
    if (a.state === 'moving') {
      const ab = Number(blocking.has(b.t.id)) - Number(blocking.has(a.t.id));
      if (ab) return ab;
      const ao = Number(b.t.overdue) - Number(a.t.overdue);
      if (ao) return ao;
    }
    return keyNumber(a.t.key) - keyNumber(b.t.key);
  });
  return withDone.map(({ t, state }) => ({ id: t.id, key: t.key, title: t.title, state, blocking: state !== 'settled' && blocking.has(t.id), overdue: t.overdue }));
}

/** Where each block should be (1 in its row, 0.85 hovering over it, 0 in the stream) and how warm it glows. */
export function snowTargets(list: readonly SnowTask[]): { targets: number[]; warm: number[] } {
  return {
    targets: list.map((t) => (t.state === 'settled' ? 1 : t.state === 'review' ? 0.85 : 0)),
    warm: list.map((t) => (t.blocking ? 1 : 0)),
  };
}

export function snowSummary(list: readonly SnowTask[]): { total: number; settled: number; review: number; moving: number; blocking: number } {
  return {
    total: list.length,
    settled: list.filter((t) => t.state === 'settled').length,
    review: list.filter((t) => t.state === 'review').length,
    moving: list.filter((t) => t.state === 'moving').length,
    blocking: list.filter((t) => t.blocking).length,
  };
}

/** The whole picture in one sentence (the text equivalent's first line). */
export function snowSentence(list: readonly SnowTask[]): string {
  const s = snowSummary(list);
  if (!s.total) return 'No tasks yet: nothing has come down the mountain.';
  const parts = [`${s.settled} of ${s.total} tasks approved and settled`];
  if (s.review) parts.push(`${s.review} waiting for review`);
  if (s.moving) parts.push(`${s.moving} still moving`);
  let out = parts.join(', ') + '.';
  if (s.blocking) out += s.blocking === 1 ? ' 1 unfinished task holds other work up.' : ` ${s.blocking} of the unfinished tasks hold other work up.`;
  return out;
}
