/**
 * The front page's optional sound: a soft mountain wind made with the Web Audio API (filtered
 * noise with a slow swell), a faint chime when a new place settles, and a tick when the ice is touched. Off until the visitor
 * turns it on; nothing is downloaded.
 */
export class AmbientSound {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private source: AudioBufferSourceNode | null = null;
  private lfo: OscillatorNode | null = null;

  get playing(): boolean {
    return this.source !== null;
  }

  /** Starts the wind. Call it from a click (browsers only allow sound after one). */
  start(): boolean {
    if (this.source) return true;
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return false;
    try {
      this.ctx ??= new Ctor();
      const ctx = this.ctx;
      void ctx.resume();
      // Two seconds of brown noise, looped.
      const buffer = ctx.createBuffer(2, ctx.sampleRate * 2, ctx.sampleRate);
      for (let ch = 0; ch < 2; ch++) {
        const data = buffer.getChannelData(ch);
        let last = 0;
        for (let i = 0; i < data.length; i++) {
          last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02;
          data[i] = last * 3.2;
        }
      }
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.loop = true;
      const low = ctx.createBiquadFilter();
      low.type = 'lowpass';
      low.frequency.value = 520;
      low.Q.value = 0.4;
      const swell = ctx.createGain();
      swell.gain.value = 0.55;
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.07;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 0.35;
      lfo.connect(lfoGain).connect(swell.gain);
      const master = ctx.createGain();
      master.gain.setValueAtTime(0, ctx.currentTime);
      master.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 1.6);
      src.connect(low).connect(swell).connect(master).connect(ctx.destination);
      src.start();
      lfo.start();
      this.source = src;
      this.lfo = lfo;
      this.master = master;
      return true;
    } catch {
      return false;
    }
  }

  stop(): void {
    const ctx = this.ctx;
    if (!ctx || !this.source || !this.master) return;
    const src = this.source;
    const lfo = this.lfo;
    this.master.gain.cancelScheduledValues(ctx.currentTime);
    this.master.gain.setValueAtTime(this.master.gain.value, ctx.currentTime);
    this.master.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6);
    window.setTimeout(() => {
      try {
        src.stop();
        lfo?.stop();
      } catch {
        /* already stopped */
      }
    }, 700);
    this.source = null;
    this.lfo = null;
    this.master = null;
  }

  /** A faint two-note chime (only while the wind is on). */
  chime(): void {
    const ctx = this.ctx;
    if (!ctx || !this.source) return;
    const t = ctx.currentTime + 0.02;
    for (const [f, d] of [
      [1318.5, 0],
      [1760, 0.12],
    ] as const) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = f;
      g.gain.setValueAtTime(0, t + d);
      g.gain.linearRampToValueAtTime(0.02, t + d + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d + 1.4);
      o.connect(g).connect(ctx.destination);
      o.start(t + d);
      o.stop(t + d + 1.5);
    }
  }

  /** A tiny glassy tick, for touching the ice (only while the wind is on). */
  tick(): void {
    const ctx = this.ctx;
    if (!ctx || !this.source) return;
    const t = ctx.currentTime + 0.01;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'triangle';
    o.frequency.setValueAtTime(2600 + Math.random() * 700, t);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.012, t + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
    o.connect(g).connect(ctx.destination);
    o.start(t);
    o.stop(t + 0.2);
  }

  dispose(): void {
    this.stop();
    const ctx = this.ctx;
    this.ctx = null;
    window.setTimeout(() => void ctx?.close(), 800);
  }
}
