import { useRef, useState } from 'react';
import { FlurryFigure, type FlurryMood } from '@/features/flurry/FlurryFigure';
import type { Box, Pt } from '@/features/flurry/roam';
import { busyFromRects, overlayRects, useFlurryRoam } from '@/features/flurry/useFlurryRoam';
import { cn } from '@/lib/cn';
import { useMediaQuery } from '@/lib/hooks';

/** The words and controls on the front page Flurry must never land on. */
const WORDS = '[data-loft] main :is(h1,h2,p,dl,a,button,[data-next-steps]), [data-loft] header :is(a,button), [data-sound-toggle]';

/** How visible an element really is (its own opacity times its ancestors'), up to the page. */
function shownOpacity(el: Element): number {
  let o = 1;
  for (let e: Element | null = el; e && !e.hasAttribute('data-loft'); e = e.parentElement) {
    const cs = getComputedStyle(e);
    if (cs.visibility === 'hidden' || cs.display === 'none') return 0;
    o *= Number(cs.opacity);
    if (o < 0.15) return o;
  }
  return o;
}

function wordRects(): Box[] {
  const out: Box[] = [];
  for (const el of document.querySelectorAll(WORDS)) {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height || r.bottom < 0 || r.top > window.innerHeight || r.right < 0 || r.left > window.innerWidth) continue;
    if (el.closest('.sr-only') || shownOpacity(el) < 0.15) continue;
    out.push({ left: r.left, top: r.top, right: r.right, bottom: r.bottom });
  }
  return out;
}

/**
 * Flurry on the front page. It roams over the world while you look around: rests a while, flies
 * somewhere else, looks at the pointer, and naps after a quiet spell. It never lands on the words
 * or the controls. Click it (or focus it and press Enter) to meet it properly: its panel opens.
 * Pointing at it or focusing it holds it still; "Keep Flurry still" in the menu, or the system's
 * reduced-motion setting, keeps it in the corner without moving at all.
 */
export function LoftFlurry({ onOpen, still }: { onOpen: () => void; still: boolean }) {
  const root = useRef<HTMLDivElement>(null);
  const compact = !useMediaQuery('(min-width: 640px)');
  const size = compact ? { width: 48, height: 48 } : { width: 64, height: 64 };
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const home = (): Pt => ({ x: window.innerWidth - size.width - (compact ? 16 : 32), y: window.innerHeight - size.height - (compact ? 150 : 110) });
  const area = (): Box => ({ left: 16, top: compact ? 80 : 96, right: window.innerWidth - 16, bottom: window.innerHeight - (compact ? 100 : 16) });
  const words = useRef<{ at: number; rects: Box[] }>({ at: 0, rects: [] });
  const rects = () => {
    // Measured once per choice of spot (the hook asks for them together).
    if (performance.now() - words.current.at > 250) words.current = { at: performance.now(), rects: wordRects() };
    return words.current.rects;
  };

  const roam = useFlurryRoam({
    el: root,
    size,
    roam: !still,
    motion: !still,
    mode: compact ? 'bottom' : 'free',
    area,
    anchor: still && typeof window !== 'undefined' ? home() : null,
    hold: hovered || focused,
    avoid: () => [...overlayRects(), ...rects()],
    busy: (b) => busyFromRects(b, rects()),
    home,
    napAfter: 90_000,
    restMs: [5000, 11000],
  });

  let mood: FlurryMood = 'idle';
  if (roam.phase === 'nap') mood = 'sleep';
  else if (roam.curious || hovered) mood = 'curious';

  return (
    <div
      ref={root}
      className="invisible fixed top-0 left-0 z-20"
      data-loft-flurry={roam.phase}
      data-print="hide"
      onPointerEnter={(e) => e.pointerType !== 'touch' && setHovered(true)}
      onPointerLeave={() => setHovered(false)}
    >
      <button
        type="button"
        onClick={onOpen}
        onFocus={(e) => setFocused(e.currentTarget.matches(':focus-visible'))}
        onBlur={() => setFocused(false)}
        className={cn('flex items-center justify-center rounded-full outline-offset-4 transition-[scale] duration-300 hover:scale-110 focus-visible:outline-2 focus-visible:outline-accent', compact ? 'size-12' : 'size-16')}
        style={{ transform: 'rotate(var(--tilt, 0deg))' }}
        aria-label="Meet Flurry, Niveloft’s AI assistant"
        title="Meet Flurry"
      >
        <FlurryFigure mood={mood} still={still} glow className={cn('drop-shadow-[0_6px_12px_rgb(23_33_43/0.22)]', compact ? 'size-12' : 'size-16', roam.phase === 'flying' && 'flurry-flying')} />
      </button>
    </div>
  );
}
