import { useRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Link, type LinkProps } from 'react-router';
import { cn } from '@/lib/cn';

/**
 * The front page's instrument language: small monospaced labels, "//////" section marks and
 * bracketed controls, as if read off a gauge. Everything here is ordinary, accessible HTML.
 */

export const HUD = 'font-hud tracking-[0.02em]';

/** "////// Manifesto": a section mark. */
export function Mark({ children, className, n = 6 }: { children: ReactNode; className?: string; n?: number }) {
  return (
    <p className={cn(HUD, 'text-[12px] text-ink-2', className)}>
      <span aria-hidden="true">{'/'.repeat(n)} </span>
      {children}
    </p>
  );
}

const bracketClass = (strong: boolean, className?: string) =>
  cn(
    HUD,
    'hud-bracket inline-flex min-h-10 items-center justify-center gap-2 px-4 py-2 text-[12.5px] font-medium text-ink outline-offset-4 focus-visible:outline-2 focus-visible:outline-accent',
    strong ? 'bg-ink text-canvas hover:bg-ink-2' : 'hover:bg-ink/5',
    className,
  );

/** [ Close ]: a button in brackets. */
export function Bracket({ strong = false, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { strong?: boolean }) {
  return (
    <button type="button" className={bracketClass(strong, className)} {...rest}>
      {children}
    </button>
  );
}

export function BracketLink({ strong = false, className, children, ...rest }: LinkProps & { strong?: boolean }) {
  return (
    <Link className={bracketClass(strong, className)} {...rest}>
      {children}
    </Link>
  );
}

export { Scramble } from '@/components/ui/Scramble';

/** Paragraphs whose words brighten under the pointer (a brighter copy shown through a soft circle). */
export function Spotlight({ paragraphs, className }: { paragraphs: string[]; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const move = (x: number, y: number) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${x - r.left}px`);
    el.style.setProperty('--my', `${y - r.top}px`);
  };
  const body = paragraphs.map((p) => <p key={p}>{p}</p>);
  return (
    <div
      ref={ref}
      className={cn('relative', className)}
      onPointerMove={(e) => move(e.clientX, e.clientY)}
      onPointerLeave={() => {
        ref.current?.style.setProperty('--mx', '-999px');
        ref.current?.style.setProperty('--my', '-999px');
      }}
    >
      <div className="space-y-4 text-muted">{body}</div>
      <div className="loft-spot-hi pointer-events-none absolute inset-0 space-y-4 text-ink" aria-hidden="true">
        {body}
      </div>
    </div>
  );
}
