import * as RD from '@radix-ui/react-dialog';
import { ArrowDown, ArrowLeft, ArrowRight, Volume2, VolumeX } from 'lucide-react';
import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState, type MouseEvent as ReactMouseEvent, type PointerEvent as ReactPointerEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router';
import { useAppDispatch, useAppSelector } from '@/app/store';
import { themeChanged } from '@/app/uiSlice';
import { Logo } from '@/components/layout/Logo';
import { useSearchShortcut } from '@/components/layout/PublicFrame';
import { USE_MOCK_API } from '@/config';
import { openCookieSettings } from '@/features/consent/consent';
import { openContact } from '@/features/contact/contactStore';
import { cn } from '@/lib/cn';
import { useMediaQuery } from '@/lib/hooks';
import { readJson, writeStorage } from '@/lib/storage';
import type { LoftShape, LoftWorld } from '@/three/LoftWorld';
import { disciplineAt, disciplineWord, landedShare } from '@/three/snowMath';
import { AmbientSound } from '../ambientSound';
import { ONBOARDING_SAMPLE } from '../sampleProject';
import { Bracket, BracketLink, HUD, Mark, Scramble } from './hud';
import { SECTIONS, SectionBody, useReadings, type SectionId } from './sections';

const SiteSearchDialog = lazy(() => import('@/features/public/SiteSearchDialog').then((m) => ({ default: m.SiteSearchDialog })));
// Flurry arrives after the page has painted (it isn't needed for the first screen).
const LoftFlurry = lazy(() => import('./LoftFlurry').then((m) => ({ default: m.LoftFlurry })));

/** Every shape the platform's particles can take (the world is built with all of them). */
const SHAPES: LoftShape[] = ['mountain', 'flurry', 'plus', 'login', 'book', 'flake'];
const BLOCK_KEYS = ONBOARDING_SAMPLE.tasks.map((t) => `${ONBOARDING_SAMPLE.key}-${t.n}`);
const SECTION_IDS = new Set<string>(SECTIONS.map((s) => s.id));
/** The front page's own Flurry setting (visitors aren't signed in): whether it roams. */
const FLURRY_HOME_KEY = 'projectflow.flurry.home';

interface NextStep {
  label: string;
  shape: LoftShape;
  to?: string;
  open?: SectionId;
}

/**
 * The front page: one journey in three places, in the manner of a film rather than a brochure.
 *
 * 1. The mountain: an avalanche of snow blocks, one per task, scattered down a misty mountain
 *    face. Scrolling disciplines it: the blocks settle into ordered rows on the slope. Hover lifts
 *    them and shows their keys. The promise and one action.
 * 2. The void: five ice crystals, one per part of the product. Each opens a dark summary panel
 *    with the real thing inside it (the sample workspace, the role graphs, the forecast, Flurry,
 *    questions).
 * 3. The platform: particles gather into the next step (explore, meet Flurry, create, log in,
 *    read the introduction).
 *
 * The words are ordinary page content in the scroll; the 3D world (three.js, loaded when the
 * browser is idle) is decoration behind them, with a still before it loads and without WebGL.
 */
export function LoftHome() {
  const signedIn = useAppSelector((s) => s.auth.token !== null);
  const theme = useAppSelector((s) => s.ui.theme);
  const dispatch = useAppDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const compact = !useMediaQuery('(min-width: 768px)');
  const reducedMotion = useMediaQuery('(prefers-reduced-motion: reduce)');
  const canvas = useRef<HTMLCanvasElement>(null);
  const labelRefs = useRef<HTMLSpanElement[]>([]);
  const world = useRef<LoftWorld | null>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [s, setS] = useState(0);
  const [panel, setPanel] = useState<SectionId | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [sound] = useState(() => new AmbientSound());
  const [soundOn, setSoundOn] = useState(false);
  const soundRef = useRef(false);
  soundRef.current = soundOn;
  const readings = useReadings();
  const [flurryStill, setFlurryStill] = useState(() => readJson<{ still?: boolean }>(FLURRY_HOME_KEY)?.still === true);
  const toggleFlurryStill = () => {
    setFlurryStill((v) => {
      writeStorage(FLURRY_HOME_KEY, JSON.stringify({ still: !v }));
      return !v;
    });
  };
  useSearchShortcut(useCallback(() => setSearching(true), []));

  const steps: NextStep[] = useMemo(
    () =>
      signedIn
        ? [
            { label: 'Open Niveloft', shape: 'mountain', to: '/dashboard' },
            { label: 'Meet Flurry', shape: 'flurry', open: 'flurry' },
            { label: 'Explore the demo', shape: 'flake', open: 'product' },
            { label: 'Read the introduction', shape: 'book', to: '/introduction' },
          ]
        : [
            { label: 'Explore the demo', shape: 'mountain', open: 'product' },
            { label: 'Meet Flurry', shape: 'flurry', open: 'flurry' },
            { label: 'Create your workspace', shape: 'plus', to: '/register' },
            { label: 'Log in', shape: 'login', to: '/login' },
            { label: 'Read the introduction', shape: 'book', to: '/introduction' },
          ],
    [signedIn],
  );
  const [step, setStep] = useState(0);
  const current = steps[step % steps.length];

  const open = useCallback((id: SectionId) => {
    setMenuOpen(false);
    setPanel(id);
  }, []);
  const closePanel = () => {
    setPanel(null);
    if (location.hash && SECTION_IDS.has(location.hash.slice(1))) navigate({ hash: '' }, { replace: true });
  };

  // Deep links: /#product (and the other sections) open that crystal's panel; /#begin goes to the end.
  useEffect(() => {
    const id = decodeURIComponent(location.hash.slice(1));
    if (!id) {
      window.scrollTo(0, 0);
      return;
    }
    const target = id === 'demo' ? 'product' : id;
    const el = document.getElementById(target);
    el?.scrollIntoView({ block: 'start' });
    if (SECTION_IDS.has(target)) setPanel(target as SectionId);
  }, [location.hash]);

  // Scroll → story position: one screen per step (0 ridge … 2 first crystal … 6 last … 7 platform).
  useEffect(() => {
    let raf = 0;
    const measure = () => {
      raf = 0;
      const unit = document.getElementById('product')?.offsetHeight || window.innerHeight;
      const next = Math.min(7, Math.max(0, window.scrollY / unit));
      setS(next);
      world.current?.setStory(next);
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  // A soft chime when a new place settles (only with sound on).
  const place = Math.round(s);
  const lastPlace = useRef(place);
  useEffect(() => {
    if (place !== lastPlace.current) {
      lastPlace.current = place;
      if (soundRef.current) sound.chime();
    }
  }, [place, sound]);
  useEffect(() => () => sound.dispose(), [sound]);

  // The world: loaded once the browser is idle after the first paint, only where WebGL works.
  useEffect(() => {
    const el = canvas.current;
    if (!el) return;
    let disposed = false;
    let stopTheme: (() => void) | null = null;
    const onResize = () => world.current?.resize(window.innerWidth, window.innerHeight);
    const onVisibility = () => world.current?.setActive(!document.hidden && !reducedMotion);
    const begin = async () => {
      try {
        const [{ LoftWorld }, { webglAvailable, onThemeChange }] = await Promise.all([import('@/three/LoftWorld'), import('@/three/sceneUtils')]);
        if (disposed) return;
        if (!webglAvailable()) {
          setFailed(true);
          return;
        }
        const w = new LoftWorld(el, {
          compact,
          reducedMotion,
          dark: document.documentElement.classList.contains('dark'),
          blockKeys: BLOCK_KEYS,
          labels: labelRefs.current.filter(Boolean),
          crystals: SECTIONS.map((x) => x.glyph),
          shapes: SHAPES,
          flurrySrc: '/flurry/flurry-480.webp',
          onReady: () => !disposed && setReady(true),
          onPickBlock: () => open('product'),
          onPickCrystal: (i) => open(SECTIONS[i].id),
          onHoverChange: setHovering,
          onBlockTouch: () => soundRef.current && sound.tick(),
        });
        world.current = w;
        w.resize(window.innerWidth, window.innerHeight);
        const unit = document.getElementById('product')?.offsetHeight || window.innerHeight;
        w.setStory(Math.min(7, window.scrollY / unit));
        await w.prepare();
        if (disposed) return;
        w.renderOnce();
        // The crystals and the platform are built once the mountain is showing and the browser is idle.
        if (typeof window.requestIdleCallback === 'function') window.requestIdleCallback(() => void w.warm(), { timeout: 4000 });
        else window.setTimeout(() => void w.warm(), 1500);
        window.addEventListener('resize', onResize);
        document.addEventListener('visibilitychange', onVisibility);
        stopTheme = onThemeChange(() => w.setTheme(document.documentElement.classList.contains('dark')));
        onVisibility();
      } catch {
        if (!disposed) setFailed(true);
      }
    };
    const idle = typeof window.requestIdleCallback === 'function';
    const start = idle ? window.requestIdleCallback(() => void begin(), { timeout: 1200 }) : window.setTimeout(() => void begin(), 300);
    return () => {
      disposed = true;
      if (idle) window.cancelIdleCallback(start);
      else window.clearTimeout(start);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
      stopTheme?.();
      world.current?.dispose();
      world.current = null;
      setReady(false);
    };
  }, [compact, reducedMotion, open, sound]);

  // Pause while a panel or the menu covers everything.
  useEffect(() => {
    world.current?.setActive(!panel && !menuOpen && !document.hidden && !reducedMotion);
  }, [panel, menuOpen, reducedMotion]);

  useEffect(() => {
    world.current?.setShape(SHAPES.indexOf(current.shape));
  }, [current.shape, ready]);

  const toPointer = (e: ReactPointerEvent | ReactMouseEvent) => [(e.clientX / window.innerWidth) * 2 - 1, -((e.clientY / window.innerHeight) * 2 - 1)] as const;
  const toggleSound = () => {
    if (soundOn) {
      sound.stop();
      setSoundOn(false);
    } else setSoundOn(sound.start());
  };
  const go = (n: NextStep) => {
    if (n.open) open(n.open);
    else if (n.to) navigate(n.to);
  };

  const dark = theme === 'dark' || (theme === 'system' && typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
  const act = s < 1.5 ? 1 : s < 6.5 ? 2 : 3;
  const year = new Date().getFullYear();
  const today = new Date();
  const stamp = `${String(today.getDate()).padStart(2, '0')}.${String(today.getMonth() + 1).padStart(2, '0')}.${today.getFullYear()}`;
  // Reduced motion jumps between places, and the avalanche with them.
  const discipline = disciplineAt(reducedMotion ? Math.round(s) : s);

  return (
    <div className="relative min-h-dvh text-ink" style={{ background: act === 1 ? 'var(--loft-fog)' : 'var(--loft-void)' }} data-loft="" data-loft-act={act} data-loft-s={s.toFixed(2)}>
      <a
        href="#loft-contents"
        className={`${HUD} sr-only z-[60] bg-ink px-3 py-2 text-[12px] text-canvas focus:not-sr-only focus:fixed focus:top-3 focus:left-3`}
        data-skip-story=""
      >
        Skip to what’s inside
      </a>

      {/* The world, and a still of it until it's drawn (or instead, without WebGL). */}
      <div className="fixed inset-0" aria-hidden="true" data-print="hide">
        <div className={cn('loft-poster absolute inset-0 transition-opacity duration-700', ready && !failed ? 'opacity-0' : 'opacity-100')} />
        <canvas
          ref={canvas}
          className={cn('absolute inset-0 size-full transition-opacity duration-700', ready && !failed ? 'opacity-100' : 'opacity-0', hovering && 'cursor-pointer')}
          onPointerMove={(e) => {
            if (e.pointerType === 'touch') return;
            const [x, y] = toPointer(e);
            world.current?.setPointer(x, y, true);
          }}
          onPointerLeave={() => world.current?.setPointer(0, 0, false)}
          onClick={(e) => {
            const [x, y] = toPointer(e);
            world.current?.click(x, y);
          }}
          data-loft-canvas=""
        />
        <div className="pointer-events-none absolute inset-0">
          {[0, 1, 2, 3].map((i) => (
            <span
              key={i}
              ref={(el) => {
                if (el) labelRefs.current[i] = el;
              }}
              className="loft-label hud-glow"
            />
          ))}
        </div>
      </div>

      {/* The instrument frame: the mark, the menu, the sound. */}
      <header className="pointer-events-none fixed inset-x-0 top-0 z-30 flex items-start justify-between px-5 pt-5 sm:px-8 sm:pt-7" data-print="hide">
        <div className="pointer-events-auto flex items-center gap-3">
          <Link to="/" className="rounded-md transition-opacity hover:opacity-75" aria-label="Niveloft, front page" onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? 'auto' : 'smooth' })}>
            <Logo />
          </Link>
          {USE_MOCK_API && (
            <span className={`${HUD} hud-bracket px-2 py-1 text-[11px] text-ink-2`} title="Demo mode: data lives in this browser only" data-demo-tag="">
              Demo
            </span>
          )}
        </div>
        <div className="pointer-events-auto flex items-center gap-2">
          {!signedIn && (
            <BracketLink to="/login" className="hidden sm:inline-flex">
              Log in
            </BracketLink>
          )}
          <Bracket onClick={() => setMenuOpen(true)} aria-haspopup="dialog" aria-expanded={menuOpen} data-loft-menu-button="">
            Menu
          </Bracket>
        </div>
      </header>

      <button
        type="button"
        onClick={toggleSound}
        aria-pressed={soundOn}
        className={`${HUD} fixed bottom-4 left-4 z-30 flex min-h-10 items-center gap-2 px-2 text-[12px] font-medium text-ink-2 hover:text-ink sm:bottom-6 sm:left-7`}
        title={soundOn ? 'Turn the sound off' : 'Play a soft wind and the sound of the ice'}
        data-sound-toggle=""
        data-print="hide"
      >
        {soundOn ? <Volume2 className="size-4" aria-hidden="true" /> : <VolumeX className="size-4" aria-hidden="true" />}
        Sound: {soundOn ? 'On' : 'Off'}
      </button>

      <main id="main" tabIndex={-1} className="pointer-events-none relative z-10 focus:outline-none">
        {/* 1. The ridge ------------------------------------------------------------------ */}
        <section id="top" aria-labelledby="loft-title" className="h-[200svh]">
          <div className="sticky top-0 h-svh transition-opacity duration-300" style={{ opacity: s < 1 ? 1 : Math.max(0, 1 - (s - 1) / 0.35) }} data-act-one="">
            {/* On phones the heading sits over the mountain: a little fog behind it keeps it legible. */}
            <div className="absolute inset-x-0 top-0 h-[300px] bg-gradient-to-b from-[var(--loft-fog)] via-[var(--loft-fog)]/70 to-transparent sm:hidden" aria-hidden="true" />
            <div className={`${HUD} pointer-events-auto absolute top-[84px] left-8 hidden max-w-[240px] text-[12px] leading-relaxed text-ink-2 sm:block`}>
              <p>// Copyright © {year}</p>
              <p className="mt-2 text-ink">Niveloft (working name).</p>
              <p>Project workspace for focused teams.</p>
              {/* The avalanche's own readout: how much of it has settled, from the scroll. */}
              <dl className="mt-8 space-y-0.5 text-[11.5px]" data-avalanche-readout="">
                <div className="flex gap-3">
                  <dt>AVALANCHE_01</dt>
                  <dd className="text-ink">{stamp}</dd>
                </div>
                <div className="flex gap-3">
                  <dt>STATE</dt>
                  <dd className="text-ink" data-avalanche-state={disciplineWord(discipline)}>
                    {disciplineWord(discipline)}
                  </dd>
                </div>
                <div className="flex gap-3">
                  <dt>IN ROWS</dt>
                  <dd className="text-ink tabular-nums">{Math.round(landedShare(discipline) * 100)}%</dd>
                </div>
              </dl>
              <p className="mt-3 max-w-[220px] text-[11.5px] leading-relaxed">Every block is a task. Work arrives as an avalanche; Niveloft lays it down in order.</p>
            </div>
            <div className="pointer-events-auto absolute top-[84px] right-5 left-5 sm:right-8 sm:left-auto sm:max-w-[330px] sm:text-right">
              <Mark>Manifesto</Mark>
              <h1 id="loft-title" className={`${HUD} hud-glow mt-3 text-[17px] leading-[1.45] font-medium text-ink sm:text-[19px]`}>
                See what will finish, when, and what’s in the way.
              </h1>
              <p className={`${HUD} mt-3 text-[12.5px] leading-relaxed text-ink-2`}>Built for small software and student teams who share work and reviews.</p>
            </div>
            <div className="pointer-events-auto absolute inset-x-0 bottom-20 flex flex-col items-center gap-3 px-5 sm:bottom-10">
              <Bracket strong onClick={() => open('product')} data-hero-demo="">
                Explore the demo
              </Bracket>
              <Link to="/register" className={`${HUD} text-[12px] text-ink-2 underline decoration-ink/30 underline-offset-4 hover:text-ink hover:decoration-ink`}>
                or create your workspace
              </Link>
              <a
                href="#product"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('product')?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' });
                }}
                className={`${HUD} mt-1 flex min-h-8 items-center gap-2 text-[11.5px] text-ink-2 hover:text-ink`}
                data-skip-arrow=""
              >
                <ArrowDown className="nudge-down size-3.5" aria-hidden="true" /> Scroll to settle the snow<span className="hidden md:inline"> · hover it: every block is a task</span>
              </a>
            </div>
            {failed && (
              <p className={`${HUD} pointer-events-auto absolute bottom-20 left-5 max-w-[260px] text-[11.5px] text-ink-2 sm:left-8`}>
                This browser can’t show the 3D scene, so here’s a still of it. Everything else works the same.
              </p>
            )}
          </div>
        </section>

        {/* 2. The void: one crystal per screen --------------------------------------------- */}
        <section id="loft-contents" aria-label="What’s inside Niveloft" tabIndex={-1} className="focus:outline-none">
          {SECTIONS.map((sec, i) => (
            <article key={sec.id} id={sec.id} className="relative h-svh" aria-labelledby={`${sec.id}-title`} data-crystal={sec.id}>
              <div className="absolute inset-0">
                {/* Label and leader line, top left of the crystal. */}
                <div className={`${HUD} absolute top-[14%] left-5 max-w-[280px] sm:left-[max(2rem,calc(50%-480px))] sm:top-[calc(50%-200px)]`}>
                  <p className="text-[11.5px] text-ink-2">
                    SECTION_{sec.code} / {stamp}
                  </p>
                  <h2 id={`${sec.id}-title`} className="hud-glow mt-1 text-[18px] leading-tight font-medium tracking-[0.06em] text-ink uppercase">
                    <Scramble text={sec.name} play={Math.abs(s - (2 + i)) < 0.5} />
                  </h2>
                  <p className="mt-2 text-[12.5px] leading-relaxed text-ink-2">{sec.line}</p>
                </div>
                <span className="absolute top-[calc(50%-112px)] left-[calc(50%-300px)] hidden h-px w-[150px] origin-left rotate-[20deg] bg-ink/50 sm:block" aria-hidden="true" />
                <span className="absolute top-[calc(50%-64px)] left-[calc(50%-163px)] hidden size-[7px] rounded-full border border-ink/70 sm:block" aria-hidden="true" />
                {/* Readings, right of the crystal: real figures from the sample. */}
                <dl className={`${HUD} absolute top-[calc(50%-140px)] right-5 hidden text-right text-[11.5px] leading-relaxed text-ink-2 sm:right-auto sm:left-[calc(50%+230px)] sm:block sm:text-left`}>
                  {readings[sec.id].map(([k, v]) => (
                    <div key={k} className="flex gap-3">
                      <dt className="text-ink-2">{k}</dt>
                      <dd className="text-ink">{v}</dd>
                    </div>
                  ))}
                </dl>
                {/* The way in. */}
                <div className="pointer-events-auto absolute bottom-[14%] left-1/2 -translate-x-1/2 sm:bottom-auto sm:left-[calc(50%+245px)] sm:top-[calc(50%+150px)] sm:translate-x-0">
                  <Bracket onClick={() => open(sec.id)} aria-label={`Explore: ${sec.name}`} data-open-section={sec.id}>
                    Click to explore <span aria-hidden="true">↗</span>
                  </Bracket>
                </div>
              </div>
            </article>
          ))}
        </section>

        {/* 3. The platform ----------------------------------------------------------------- */}
        <section id="begin" aria-labelledby="begin-title" className="h-[150svh]">
          <div className="sticky top-0 h-svh">
            <h2 id="begin-title" className="sr-only">
              Where to next
            </h2>
            <div className="pointer-events-auto absolute inset-x-0 bottom-20 flex flex-col items-center gap-4 px-4 sm:bottom-12" data-next-steps="">
              <Mark n={3}>Where to next</Mark>
              <div className="flex items-center gap-2 sm:gap-5">
                <span className={`${HUD} hidden w-44 truncate text-right text-[11.5px] text-ink-2 md:block`} aria-hidden="true">
                  {steps[(step + steps.length - 1) % steps.length].label}
                </span>
                <button
                  type="button"
                  onClick={() => setStep((step + steps.length - 1) % steps.length)}
                  className="flex size-10 items-center justify-center text-ink-2 hover:text-ink"
                  aria-label={`Previous: ${steps[(step + steps.length - 1) % steps.length].label}`}
                  data-step-prev=""
                >
                  <ArrowLeft className="size-4" aria-hidden="true" />
                </button>
                <Bracket strong onClick={() => go(current)} className="min-w-[210px]" data-step-go="">
                  <Scramble text={current.label} play duration={450} />
                </Bracket>
                <button
                  type="button"
                  onClick={() => setStep((step + 1) % steps.length)}
                  className="flex size-10 items-center justify-center text-ink-2 hover:text-ink"
                  aria-label={`Next: ${steps[(step + 1) % steps.length].label}`}
                  data-step-next=""
                >
                  <ArrowRight className="size-4" aria-hidden="true" />
                </button>
                <span className={`${HUD} hidden w-44 truncate text-[11.5px] text-ink-2 md:block`} aria-hidden="true">
                  {steps[(step + 1) % steps.length].label}
                </span>
              </div>
              <p className={`${HUD} text-[11px] text-ink-2`} aria-live="polite">
                {(step % steps.length) + 1} / {steps.length}
              </p>
            </div>
            <footer className={`${HUD} pointer-events-auto absolute right-5 bottom-4 max-w-[70%] text-right text-[11px] leading-relaxed text-ink-2 sm:right-8 sm:bottom-6`}>
              <p>// © {year} Niveloft (working name)</p>
              <p className="mt-1 flex flex-wrap justify-end gap-x-3">
                <Link to="/privacy" className="hover:text-ink hover:underline">
                  Privacy
                </Link>
                <Link to="/terms" className="hover:text-ink hover:underline">
                  Terms
                </Link>
                <button type="button" onClick={() => openCookieSettings()} className="hover:text-ink hover:underline">
                  Cookie settings
                </button>
                <button type="button" onClick={() => openContact()} className="hover:text-ink hover:underline">
                  Contact
                </button>
              </p>
            </footer>
          </div>
        </section>
      </main>

      {/* Flurry, roaming over the world until it's called. */}
      {!panel && !menuOpen && (
        <Suspense fallback={null}>
          <LoftFlurry onOpen={() => open('flurry')} still={reducedMotion || flurryStill} />
        </Suspense>
      )}

      {/* A crystal's panel: the summary, then the thing itself. */}
      <RD.Root open={panel !== null} onOpenChange={(o) => !o && closePanel()}>
        <RD.Portal>
          <RD.Content
            className="dark fixed inset-0 z-50 overflow-y-auto bg-canvas text-ink outline-none"
            style={{ colorScheme: 'dark' }}
            aria-describedby={undefined}
            // While the sample's own task panel is open, Escape closes that, not this.
            onEscapeKeyDown={(e) => {
              if (document.querySelector('[data-loft-panel] [data-sample-panel]')) e.preventDefault();
            }}
            data-loft-panel={panel ?? ''}
          >
            <RD.Title className="sr-only">{SECTIONS.find((x) => x.id === panel)?.name ?? 'Section'}</RD.Title>
            <div className="sticky top-0 z-10 flex items-start justify-between bg-canvas/95 px-5 pt-5 pb-3 sm:px-8 sm:pt-7">
              <Logo inverted />
              <RD.Close asChild>
                <Bracket data-loft-close="">Close</Bracket>
              </RD.Close>
            </div>
            <div className="px-4 pt-6 sm:px-8">{panel && <SectionBody id={panel} onOpen={open} />}</div>
          </RD.Content>
        </RD.Portal>
      </RD.Root>

      {/* The menu: everything, one keypress away. */}
      <RD.Root open={menuOpen} onOpenChange={setMenuOpen}>
        <RD.Portal>
          <RD.Content className="dark fixed inset-0 z-50 overflow-y-auto bg-canvas text-ink outline-none" style={{ colorScheme: 'dark' }} aria-describedby={undefined} data-loft-menu="">
            <RD.Title className="sr-only">Menu</RD.Title>
            <div className="flex items-start justify-between px-5 pt-5 sm:px-8 sm:pt-7">
              <Logo inverted />
              <RD.Close asChild>
                <Bracket>Close</Bracket>
              </RD.Close>
            </div>
            <nav aria-label="Menu" className={`${HUD} mx-auto grid max-w-[980px] gap-12 px-5 py-12 sm:grid-cols-3 sm:px-8`}>
              <div>
                <Mark>Inside</Mark>
                <ul className="mt-4 space-y-1">
                  {SECTIONS.map((x) => (
                    <li key={x.id}>
                      <button type="button" onClick={() => open(x.id)} className="flex min-h-10 items-baseline gap-3 text-left text-[17px] text-ink-2 hover:text-ink">
                        <span className="text-[11px] text-muted">{x.code}</span>
                        {x.name}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <Mark>Pages</Mark>
                <ul className="mt-4 space-y-1 text-[17px]">
                  {(signedIn
                    ? [
                        ['/dashboard', 'Open Niveloft'],
                        ['/introduction', 'Introduction'],
                        ['/faq', 'Questions and answers'],
                      ]
                    : [
                        ['/introduction', 'Introduction'],
                        ['/faq', 'Questions and answers'],
                        ['/login', 'Log in'],
                        ['/register', 'Create your workspace'],
                      ]
                  ).map(([to, label]) => (
                    <li key={to}>
                      <Link to={to} className="flex min-h-10 items-center text-ink-2 hover:text-ink">
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <Mark>Tools</Mark>
                <ul className="mt-4 space-y-1 text-[14px]">
                  <li>
                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        setSearching(true);
                      }}
                      className="flex min-h-10 items-center text-ink-2 hover:text-ink"
                    >
                      Search the site <span className="ml-2 text-[11px] text-muted">/</span>
                    </button>
                  </li>
                  <li>
                    <button type="button" onClick={() => dispatch(themeChanged(dark ? 'light' : 'dark'))} className="flex min-h-10 items-center text-ink-2 hover:text-ink">
                      {dark ? 'Use the light theme' : 'Use the dark theme'}
                    </button>
                  </li>
                  <li>
                    <button type="button" onClick={toggleFlurryStill} disabled={reducedMotion} aria-pressed={reducedMotion || flurryStill} className="flex min-h-10 items-center text-ink-2 hover:text-ink disabled:text-muted" data-flurry-still-toggle="">
                      Keep Flurry still<span className="ml-2 text-[11px] text-muted">{reducedMotion ? 'on (your system reduces motion)' : flurryStill ? 'on' : 'off'}</span>
                    </button>
                  </li>
                  <li>
                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        openContact();
                      }}
                      className="flex min-h-10 items-center text-ink-2 hover:text-ink"
                    >
                      Contact us
                    </button>
                  </li>
                  <li>
                    <button
                      type="button"
                      onClick={() => {
                        setMenuOpen(false);
                        openCookieSettings();
                      }}
                      className="flex min-h-10 items-center text-ink-2 hover:text-ink"
                    >
                      Cookie settings
                    </button>
                  </li>
                  <li>
                    <Link to="/privacy" className="flex min-h-10 items-center text-ink-2 hover:text-ink">
                      Privacy policy
                    </Link>
                  </li>
                  <li>
                    <Link to="/terms" className="flex min-h-10 items-center text-ink-2 hover:text-ink">
                      Terms
                    </Link>
                  </li>
                </ul>
              </div>
            </nav>
            <p className={`${HUD} px-5 pb-8 text-[11px] text-muted sm:px-8`}>
              {USE_MOCK_API ? 'Demo mode: this copy runs without a server, and everything you do stays in this browser.' : `© ${year} Niveloft (working name).`}
            </p>
          </RD.Content>
        </RD.Portal>
      </RD.Root>

      {searching && (
        <Suspense fallback={null}>
          <SiteSearchDialog open={searching} onOpenChange={setSearching} />
        </Suspense>
      )}
    </div>
  );
}
