import { ArrowUpRight, ChevronDown } from 'lucide-react';
import { useMemo } from 'react';
import { Link } from 'react-router';
import { useAppSelector } from '@/app/store';
import { buttonClass } from '@/components/ui/buttonStyles';
import { FlurryFigure, FlurryPortrait } from '@/features/flurry/FlurryFigure';
import { RolePicker } from '@/features/roles/RolePicker';
import { dateRange, dayText } from '@/lib/forecastText';
import { ForecastPlayground } from '../ForecastPlayground';
import { FAQ_ENTRIES } from '../faq';
import { RoleViews } from '../RoleViews';
import { NO_CHANGES, sampleForecast } from '../sampleForecast';
import { ONBOARDING_SAMPLE } from '../sampleProject';
import { SampleWorkspace } from '../SampleWorkspace';
import type { CrystalGlyph } from '@/three/LoftWorld';
import { HUD, Mark, Spotlight } from './hud';

/** The five crystals, in order. Their ids are the front page's section anchors (/#product, …). */
export type SectionId = 'product' | 'roles' | 'how' | 'flurry' | 'questions';

export interface SectionDef {
  id: SectionId;
  code: string;
  name: string;
  line: string;
  glyph: CrystalGlyph;
  summary: string[];
}

export const SECTIONS: SectionDef[] = [
  {
    id: 'product',
    code: '01',
    name: 'Workspace',
    line: 'One real workflow, start to finish.',
    glyph: 'board',
    summary: [
      'Launch the mobile onboarding update: seventeen tasks, six people, three milestones, one late task that holds others up, a review that is waiting and two tasks nobody owns yet.',
      'Open a task, submit it for review, approve it, give the unowned work an owner. Blocked work can’t start, and nothing counts as done until someone else has reviewed it against its criteria. It’s a labelled sample: nothing is saved anywhere, and Reset puts it back.',
    ],
  },
  {
    id: 'roles',
    code: '02',
    name: 'Views',
    line: 'The same project, a different question for each person.',
    glyph: 'rows',
    summary: [
      'A member wants to know what to work on next and when they’ll finish. A reviewer wants to know whose work is waiting on them. An owner wants to know what threatens the date. A client wants to know when to expect it.',
      'Each role opens on the graph that answers its own question: time across, one row per person, recorded work solid, planned work outlined, the forecast as a band. It only ever shows what that person could already see.',
    ],
  },
  {
    id: 'how',
    code: '03',
    name: 'Forecast',
    line: 'Change an assumption. Watch the forecast move.',
    glyph: 'window',
    summary: [
      'Niveloft doesn’t ask an AI for a date. It simulates the open work from the records: each person’s real pace against their estimates, what waits on what, and how long reviews take.',
      'You get a window with its uncertainty, the one thing holding delivery up, and what it all assumes. Every forecast also says how often its ranges have held for work that is already finished.',
    ],
  },
  {
    id: 'flurry',
    code: '04',
    name: 'Flurry',
    line: 'Find your next move.',
    glyph: 'flake',
    summary: [
      'Flurry is Niveloft’s AI project assistant: calm, concise and specific. It plans a project from a brief, summarises progress and reviews blockers, and it explains the forecast rather than inventing one.',
      'It answers only from what you can already see, keeps facts, estimates and missing information apart, and previews every change before anything happens. It never approves work, assigns people or changes deadlines on its own.',
    ],
  },
  {
    id: 'questions',
    code: '05',
    name: 'Questions',
    line: 'What people ask first.',
    glyph: 'question',
    summary: ['The short answers to the questions people ask first. There are more on the questions page, and you can always ask us directly.'],
  },
];

/** Readings shown beside each crystal: real figures from the sample project, nothing invented. */
export function useReadings(): Record<SectionId, [string, string][]> {
  return useMemo(() => {
    const s = sampleForecast(NO_CHANGES);
    const f = s.forecast;
    const done = s.data.tasks.filter((t) => t.status === 'DONE').length;
    const finish = f.project.finish;
    const pct = f.project.pDeadline === null ? '—' : `${Math.round(f.project.pDeadline * 100)}%`;
    return {
      product: [
        ['TASKS', String(s.data.tasks.length)],
        ['APPROVED', String(done)],
        ['PEOPLE', String(Object.keys(ONBOARDING_SAMPLE.people).length)],
      ],
      roles: [
        ['ROLES', '4'],
        ['VIEWS', 'MINE · REVIEWS · TEAM · DELIVERY'],
      ],
      how: [
        ['LIKELY', finish ? dateRange(s.model.originMs, finish).toUpperCase() : '—'],
        ['BY DEADLINE', pct],
        ['DEADLINE', f.deadlineDay !== null ? dayText(s.model.originMs, f.deadlineDay).toUpperCase() : '—'],
      ],
      flurry: [
        ['ABILITIES', '3'],
        ['CHANGES', 'PREVIEWED FIRST'],
      ],
      questions: [['ANSWERS', String(FAQ_ENTRIES.length)]],
    };
  }, []);
}

const HOME_QUESTIONS = ['what-is-projectflow', 'who-is-flurry', 'drag-to-done', 'need-ai', 'is-it-free'];

/** What each crystal opens: the summary, then the thing itself, working. */
export function SectionBody({ id, onOpen }: { id: SectionId; onOpen: (id: SectionId) => void }) {
  const signedIn = useAppSelector((s) => s.auth.token !== null);
  const def = SECTIONS.find((s) => s.id === id)!;
  const wide = 'mx-auto mt-12 w-full max-w-[1240px]';
  return (
    <div className="pb-24">
      <div className="mx-auto max-w-[620px]">
        <Mark>Summary</Mark>
        <h2 className={`${HUD} mt-5 text-[22px] leading-tight font-medium text-ink sm:text-[26px]`} id="loft-panel-title">
          {def.line}
        </h2>
        <Spotlight className={`${HUD} mt-6 text-[14px] leading-[1.75]`} paragraphs={def.summary} />
      </div>

      {id === 'product' && (
        <>
          <div className={wide}>
            <Mark n={3}>Try it</Mark>
            <SampleWorkspace className="mt-4" />
            <ul className={`${HUD} mt-6 grid gap-4 text-[12.5px] leading-relaxed text-ink-2 md:grid-cols-3`} aria-label="What you can rely on">
              {[
                ['Done means reviewed.', 'A task reaches Done only when someone else approves it against its criteria. Dragging it there, or a direct API call, is refused.'],
                ['Roles, checked on every request.', 'Owner, manager, member or viewer, per project. The server checks each one; the graph and Flurry only see what you can see.'],
                ['Estimates, labelled.', 'Anything about the future is a range from the records, marked as an estimate, with what it assumes.'],
              ].map(([t, x]) => (
                <li key={t}>
                  <span className="text-ink">{t}</span> {x}
                </li>
              ))}
            </ul>
          </div>
          <div className="mx-auto mt-14 max-w-[620px]">
            <Mark n={3}>Try the full app</Mark>
            <div className="mt-4 rounded-lg border border-line bg-surface p-5 sm:p-6">
              {signedIn ? (
                <Link to="/dashboard" className={buttonClass('primary', 'lg')}>
                  Open Niveloft
                </Link>
              ) : (
                <RolePicker />
              )}
            </div>
          </div>
        </>
      )}

      {id === 'roles' && (
        <div className={wide}>
          <Mark n={3}>Choose whose eyes</Mark>
          <RoleViews className="mt-4" />
        </div>
      )}

      {id === 'how' && (
        <div className={wide}>
          <Mark n={3}>Try a change</Mark>
          <ForecastPlayground className="mt-4" />
        </div>
      )}

      {id === 'flurry' && (
        <div className="mx-auto mt-12 grid max-w-[1000px] items-center gap-10 md:grid-cols-[minmax(0,7fr)_minmax(0,4fr)]">
          <div>
            <Mark n={3}>Abilities</Mark>
            <ul className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                ['Plan a project', 'A brief becomes draft tasks you review, rename or drop before anything is created.'],
                ['Summarise progress', 'Where things stand, what that suggests, and what the records don’t show.'],
                ['Review blockers', 'Waiting work, late work and missing owners, each with a suggested next move.'],
              ].map(([t, x]) => (
                <li key={t} className="rounded-lg border border-line bg-surface p-4">
                  <p className="text-[14px] font-semibold text-ink">{t}</p>
                  <p className="mt-1 text-[13px] leading-relaxed text-muted">{x}</p>
                </li>
              ))}
            </ul>
            <Mark n={3} className="mt-8">
              Promises
            </Mark>
            <ul className={`${HUD} mt-3 space-y-2 text-[12.5px] leading-relaxed text-ink-2`}>
              {[
                'Answers only from what you can already see, and links the tasks it used.',
                'Keeps facts, estimates and missing information apart. It never makes up dates.',
                'Never approves work, assigns people or changes deadlines on its own; changes are previewed and can be undone.',
                'Always says it’s AI, and which model (or none) wrote each answer.',
              ].map((l) => (
                <li key={l}>
                  <span aria-hidden="true">— </span>
                  {l}
                </li>
              ))}
            </ul>
          </div>
          <figure className="mx-auto w-full max-w-[280px]">
            <FlurryPortrait size={480} className="h-auto w-full" />
            <figcaption className={`${HUD} mt-2 flex items-center gap-2 text-[12px] text-muted`}>
              <FlurryFigure className="size-5" glow={false} still /> Ask Flurry · Alt+A, inside the app
            </figcaption>
          </figure>
        </div>
      )}

      {id === 'questions' && (
        <div className="mx-auto mt-10 max-w-[760px]">
          <div className="divide-y divide-line border-y border-line">
            {HOME_QUESTIONS.map((q) => FAQ_ENTRIES.find((e) => e.id === q))
              .filter((e): e is NonNullable<typeof e> => e !== undefined)
              .map((e) => (
                <details key={e.id} className="disclosure" data-home-question={e.id}>
                  <summary className="flex items-start gap-4 px-1 py-4 transition-colors hover:bg-surface/70">
                    <h3 className="min-w-0 flex-1 text-[15px] leading-snug font-medium text-ink">{e.question}</h3>
                    <ChevronDown className="disclosure-icon mt-0.5 size-4 shrink-0 text-muted" aria-hidden="true" />
                  </summary>
                  <div className="disclosure-body space-y-2 px-1 pb-5 text-[14px] leading-relaxed text-ink-2">
                    {e.answer.map((p, i) => (
                      <p key={i}>{p}</p>
                    ))}
                  </div>
                </details>
              ))}
          </div>
        </div>
      )}

      <div className="mx-auto mt-14 max-w-[620px]">
        <Mark n={3}>Discover</Mark>
        <ul className={`${HUD} mt-3 flex flex-wrap gap-x-6 gap-y-2 text-[12.5px]`}>
          {SECTIONS.filter((s) => s.id !== id).map((s) => (
            <li key={s.id}>
              <button type="button" onClick={() => onOpen(s.id)} className="inline-flex min-h-8 items-center gap-1 text-ink-2 underline-offset-4 hover:text-ink hover:underline">
                [{s.name}] <ArrowUpRight className="size-3.5" aria-hidden="true" />
              </button>
            </li>
          ))}
          <li>
            <Link to="/introduction" className="inline-flex min-h-8 items-center gap-1 text-ink-2 underline-offset-4 hover:text-ink hover:underline">
              [Introduction] <ArrowUpRight className="size-3.5" aria-hidden="true" />
            </Link>
          </li>
          <li>
            <Link to="/faq" className="inline-flex min-h-8 items-center gap-1 text-ink-2 underline-offset-4 hover:text-ink hover:underline">
              [All questions] <ArrowUpRight className="size-3.5" aria-hidden="true" />
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
}
