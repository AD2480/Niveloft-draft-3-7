/**
 * The front page's world, drawn with three.js. Three places, one continuous journey driven by
 * scroll (the "story position" s):
 *
 *   0 … 1   The mountain. A misty mountain face with an avalanche coming down it: hundreds of
 *           snow blocks, one per task, tumbling in a loose, scattered stream with powder around
 *           them. Scrolling disciplines it: block after block flies out of the stream and lands
 *           in ordered rows on the slope, and the mountain turns to fresh snow. Hovering lifts the
 *           nearest blocks and shows their task keys. Their seams glow.
 *   1 … 2   Into the cloud. The camera climbs the slope; the view whites out and clears.
 *   2 … 6   The void. Five ice crystals, one per section of the product, each with its symbol
 *           raised on its face. The camera sinks past them, one screen per crystal, so the page's
 *           words scroll in step with them.
 *   6 … 7   The platform. A ring platform under a ring of light, where particles gather into a
 *           shape: the mountain, Flurry, and one symbol per next step.
 *
 * Everything is procedural (no downloaded models or textures); only Flurry's portrait is sampled
 * for its particle shape. Rendering pauses off screen and in hidden tabs; reduced motion jumps
 * between places instead of flying, and shows the avalanche still.
 */
import * as THREE from 'three';
import { Avalanche, clamp01, lerp, makeNoise, mulberry32, smooth, type LiftedBlock } from './snowfield';

// ------------------------------------------------------------------------------------------ types

export type LoftShape = 'mountain' | 'flurry' | 'plus' | 'login' | 'book' | 'flake';
export type CrystalGlyph = 'board' | 'rows' | 'window' | 'flake' | 'question';

export interface LoftOptions {
  compact: boolean;
  reducedMotion: boolean;
  dark: boolean;
  /** Task keys, handed out to the snow blocks in turn (the hover labels). */
  blockKeys: string[];
  /** A small pool of label elements the world positions over lifted blocks. */
  labels: HTMLElement[];
  crystals: CrystalGlyph[];
  shapes: LoftShape[];
  /** Flurry's portrait, sampled for the "flurry" particle shape. */
  flurrySrc?: string;
  onReady?: () => void;
  onPickBlock?: () => void;
  onPickCrystal?: (index: number) => void;
  onHoverChange?: (hovering: boolean) => void;
  onBlockTouch?: () => void;
}

interface Palette {
  skyTop: string;
  skyHorizon: string;
  fog: string;
  snow: string;
  block: string;
  seam: string;
  seamStrength: number;
  powder: string;
  hemiSky: string;
  hemiGround: string;
  key: number;
  voidBg: string;
  crystal: string;
  glyph: string;
  platform: string;
  ring: string;
  particles: string;
  snowflakes: string;
  exposure: number;
}

const PALETTES: Record<'light' | 'dark', Palette> = {
  light: {
    skyTop: '#a3abb4',
    skyHorizon: '#bcc2c9',
    fog: '#b3bac1',
    snow: '#c9cfd5',
    block: '#c6cdd5',
    seam: '#ffffff',
    seamStrength: 1.1,
    powder: '#ffffff',
    hemiSky: '#d9dfe5',
    hemiGround: '#4c5560',
    key: 1.2,
    voidBg: '#c9cfd5',
    crystal: '#96a2ae',
    glyph: '#f2f6f9',
    platform: '#a7afb7',
    ring: '#ffffff',
    particles: '#35404b',
    snowflakes: '#ffffff',
    exposure: 0.95,
  },
  dark: {
    skyTop: '#0c1116',
    skyHorizon: '#27303b',
    fog: '#1b222b',
    snow: '#7d8894',
    block: '#8793a0',
    seam: '#e8f4ff',
    seamStrength: 1.15,
    powder: '#d8e2ec',
    hemiSky: '#aeb9c6',
    hemiGround: '#1a2027',
    key: 0.9,
    voidBg: '#1d242d',
    crystal: '#8795a3',
    glyph: '#c9d6e2',
    platform: '#262e37',
    ring: '#b9c8d6',
    particles: '#d5dee7',
    snowflakes: '#c9d4de',
    exposure: 1.05,
  },
};

// ------------------------------------------------------------------------------------------ the mountain

/** The mountain face the avalanche comes down: a broad peak behind the settled rows. */
const MOUNTAIN = { x: -1, z: -31, h: 17, sx: 520, sz: 150 };
/** Where the settled rows lie: across x, from the lowest row (z0) up the slope (z1). */
const ROWS = { x0: -7.5, x1: 7.5, z0: -9, z1: -21.5 };
const BLOCKS = { desktop: { count: 420, cols: 28, powder: 2600 }, compact: { count: 220, cols: 20, powder: 1200 } };

// ------------------------------------------------------------------------------------------ shapes

function roundedRect(x: number, y: number, w: number, h: number, r: number): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + h - r);
  s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  s.lineTo(x + r, y + h);
  s.quadraticCurveTo(x, y + h, x, y + h - r);
  s.lineTo(x, y + r);
  s.quadraticCurveTo(x, y, x + r, y);
  return s;
}

function band(cx: number, cy: number, r0: number, r1: number, a0: number, a1: number): THREE.Shape {
  const s = new THREE.Shape();
  s.absarc(cx, cy, r1, a0, a1, false);
  s.absarc(cx, cy, r0, a1, a0, true);
  return s;
}

function disc(cx: number, cy: number, r: number): THREE.Shape {
  const s = new THREE.Shape();
  s.absarc(cx, cy, r, 0, Math.PI * 2, false);
  return s;
}

function bar(x0: number, y0: number, x1: number, y1: number, w: number): THREE.Shape {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const l = Math.hypot(dx, dy) || 1;
  const nx = (-dy / l) * (w / 2);
  const ny = (dx / l) * (w / 2);
  const s = new THREE.Shape();
  s.moveTo(x0 + nx, y0 + ny);
  s.lineTo(x1 + nx, y1 + ny);
  s.lineTo(x1 - nx, y1 - ny);
  s.lineTo(x0 - nx, y0 - ny);
  s.closePath();
  return s;
}

/** The raised symbol on each crystal, about 1.2 units across, centred on the origin. */
function glyphShapes(kind: CrystalGlyph): THREE.Shape[] {
  switch (kind) {
    case 'board':
      return [roundedRect(-0.62, -0.1, 0.34, 0.62, 0.06), roundedRect(-0.17, -0.42, 0.34, 0.94, 0.06), roundedRect(0.28, -0.26, 0.34, 0.78, 0.06)];
    case 'rows':
      return [roundedRect(-0.62, 0.3, 0.8, 0.16, 0.05), roundedRect(-0.3, 0.02, 0.9, 0.16, 0.05), roundedRect(-0.1, -0.26, 0.72, 0.16, 0.05), bar(0.08, -0.5, 0.08, 0.6, 0.05)];
    case 'window':
      return [
        band(-0.1, 0, 0.5, 0.62, Math.PI * 0.62, Math.PI * 1.38),
        band(0.1, 0, 0.5, 0.62, -Math.PI * 0.38, Math.PI * 0.38),
        // A window with its most likely point: a range, and a dot a little right of centre.
        roundedRect(-0.34, -0.035, 0.68, 0.07, 0.03),
        disc(0.08, 0, 0.12),
      ];
    case 'flake': {
      const out: THREE.Shape[] = [];
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + Math.PI / 2;
        const [c, s] = [Math.cos(a), Math.sin(a)];
        out.push(bar(0, 0, c * 0.62, s * 0.62, 0.09));
        for (const side of [-1, 1]) {
          const b = a + side * 0.7;
          out.push(bar(c * 0.36, s * 0.36, c * 0.36 + Math.cos(b) * 0.2, s * 0.36 + Math.sin(b) * 0.2, 0.07));
        }
      }
      out.push(disc(0, 0, 0.12));
      return out;
    }
    case 'question':
      return [band(0, 0.22, 0.2, 0.36, -Math.PI * 0.5, Math.PI * 1.05), roundedRect(-0.08, -0.26, 0.16, 0.34, 0.05), disc(0, -0.5, 0.1)];
  }
}

// ------------------------------------------------------------------------------------------ the world

interface CrystalRig {
  group: THREE.Group;
  body: THREE.Mesh;
  glow: THREE.Sprite;
  phase: number;
  hover: number;
}

/** One crystal per screen: the vertical distance a screen of scroll moves the camera. */
const CAM_DIST = 7.5;
const FOV = 35;
const SPACING = 2 * CAM_DIST * Math.tan(THREE.MathUtils.degToRad(FOV / 2));
const PARTICLES = { desktop: 7000, compact: 3200 };

export class LoftWorld {
  private opts: LoftOptions;
  private pal: Palette;
  private renderer: THREE.WebGLRenderer;
  private camera: THREE.PerspectiveCamera;
  private ridge = new THREE.Scene();
  private void = new THREE.Scene();
  private overlay = new THREE.Scene();
  private overlayCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private whiteout!: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  private noise = makeNoise(7);
  private rand = mulberry32(19);

  // The first place: the mountain and its avalanche (the scene is still called `ridge`).
  private terrain!: THREE.Mesh<THREE.BufferGeometry, THREE.MeshLambertMaterial>;
  private sky!: THREE.Mesh<THREE.SphereGeometry, THREE.ShaderMaterial>;
  private hemi!: THREE.HemisphereLight;
  private key!: THREE.DirectionalLight;
  private avalanche!: Avalanche;
  /** How fresh the snow on the mountain is (0 = scoured by the avalanche … 1 = fresh). */
  private snowUniform = { value: 0 };
  private mist: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>[] = [];
  private snowRidge!: THREE.Points<THREE.BufferGeometry, THREE.ShaderMaterial>;

  // The void and the platform.
  private crystals: CrystalRig[] = [];
  private crystalMat!: THREE.MeshPhysicalMaterial;
  private glyphMat!: THREE.MeshStandardMaterial;
  private platform = new THREE.Group();
  private platformMat!: THREE.MeshStandardMaterial;
  private ringMats: THREE.MeshBasicMaterial[] = [];
  private particles!: THREE.Points<THREE.BufferGeometry, THREE.ShaderMaterial>;
  private targets: Float32Array[] = [];
  private morphFrom: Float32Array | null = null;
  private morphT = 1;
  private shape = 0;
  private snowVoid!: THREE.Points<THREE.BufferGeometry, THREE.ShaderMaterial>;
  private platformY = -(6.4 * SPACING);

  // State.
  private s = 0;
  private shown = 0;
  private pointer = new THREE.Vector2(0, 0);
  private pointerSmooth = new THREE.Vector2(0, 0);
  private pointerIn = false;
  private raycaster = new THREE.Raycaster();
  private hoverBlock = -1;
  private hoverCrystal = -1;
  private hovering = false;
  private envTarget: THREE.WebGLRenderTarget | null = null;
  private width = 1;
  private height = 1;
  private running = false;
  private raf = 0;
  private last = 0;
  private time = 0;
  private ready = false;
  private disposed = false;
  /** Resolution adapts to the device: it steps down while frames are slow, and back up. */
  private maxRatio = 1;
  private ratio = 1;
  private frameAvg = 16;
  private slowFrames = 0;
  /** On hardware that can't keep up even at half resolution, the world stops animating and only redraws on change. */
  private lowPower = false;
  private tmpV = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement, opts: LoftOptions) {
    this.opts = opts;
    this.pal = PALETTES[opts.dark ? 'dark' : 'light'];
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !opts.compact, alpha: false, powerPreference: 'high-performance' });
    this.maxRatio = Math.min(window.devicePixelRatio || 1, opts.compact ? 1.25 : 1.5);
    // Phones start a little below full resolution and climb as soon as frames prove quick.
    this.ratio = opts.compact ? Math.min(this.maxRatio, 0.8) : this.maxRatio;
    this.renderer.setPixelRatio(this.ratio);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    if (!opts.compact) {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFShadowMap;
    }
    this.camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 400);

    if (!opts.compact) this.buildEnvironment();
    this.buildRidge();
    this.buildAvalanche();
    this.buildMist();
    this.snowRidge = this.buildSnow(this.ridge, opts.compact ? 700 : 1400, new THREE.Vector3(0, 5, -3), new THREE.Vector3(30, 14, 26));
    this.whiteout = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0, depthTest: false, depthWrite: false }));
    this.overlay.add(this.whiteout);
    this.overlayCam.position.z = 0.5;
    this.applyPalette();
  }

  // ---------------------------------------------------------------------------------------- API

  /** The story position: 0 at the mountain … 2 at the first crystal … 6 at the last … 7 on the platform. */
  setStory(s: number): void {
    const next = Math.min(7, Math.max(0, s));
    const changed = this.opts.reducedMotion ? Math.round(next) !== Math.round(this.s) : next !== this.s;
    this.s = next;
    if (!this.running && changed) this.renderOnce();
  }

  setPointer(nx: number, ny: number, inside = true): void {
    this.pointer.set(nx, ny);
    this.pointerIn = inside;
    if (!this.running) this.renderOnce();
  }

  /** A click on the canvas: a snow block opens the workspace, a crystal opens its section. */
  click(nx: number, ny: number): void {
    this.pointer.set(nx, ny);
    this.pick();
    if (this.hoverBlock >= 0) this.opts.onPickBlock?.();
    else if (this.hoverCrystal >= 0) this.opts.onPickCrystal?.(this.hoverCrystal);
  }

  /** How settled the avalanche is (0 … 1), for the page's readout. */
  get discipline(): number {
    return this.avalanche.settled;
  }

  /**
   * Compiles the mountain's shaders without blocking where the browser can (KHR_parallel_shader_compile),
   * so the first frame doesn't stall the page.
   */
  async prepare(): Promise<void> {
    // Without the extension compiling can't happen in the background anyway (and three.js warns).
    if (!this.parallelCompile) return;
    try {
      await this.renderer.compileAsync(this.ridge, this.camera);
    } catch {
      /* compiled on first render instead */
    }
  }

  private get parallelCompile(): boolean {
    return !!this.renderer.getContext().getExtension('KHR_parallel_shader_compile');
  }

  /** Builds the crystals and the platform ahead of time (call when the browser is idle). */
  async warm(): Promise<void> {
    if (this.disposed) return;
    this.buildVoidParts();
    try {
      // Compiled now, while the browser is idle, rather than when you scroll into the void.
      if (!this.parallelCompile) this.renderer.compile(this.void, this.camera);
      else await this.renderer.compileAsync(this.void, this.camera);
    } catch {
      /* compiled on first render instead */
    }
  }

  private voidBuilt = false;
  private buildVoidParts() {
    if (this.voidBuilt || this.disposed) return;
    this.voidBuilt = true;
    if (!this.envTarget) this.buildEnvironment();
    this.buildVoid();
    this.buildCrystals();
    this.buildPlatform();
    this.buildParticles();
    this.snowVoid = this.buildSnow(this.void, this.opts.compact ? 500 : 1000, new THREE.Vector3(0, -2.6 * SPACING, -2), new THREE.Vector3(16, 7 * SPACING, 12));
    this.applyPalette();
  }

  /** Gathers the particles into shape i. */
  setShape(i: number): void {
    if (!this.voidBuilt) {
      this.shape = i;
      return;
    }
    const n = this.targets.length;
    if (!n) return;
    const next = ((i % n) + n) % n;
    if (next === this.shape && this.morphT >= 1) return;
    this.morphFrom = (this.particles.geometry.getAttribute('position').array as Float32Array).slice();
    this.shape = next;
    this.morphT = this.opts.reducedMotion ? 1 : 0;
    if (this.opts.reducedMotion) this.particles.geometry.getAttribute('position').array.set(this.targets[next]);
    this.particles.geometry.getAttribute('position').needsUpdate = true;
    if (!this.running) this.renderOnce();
  }

  setTheme(dark: boolean): void {
    this.opts.dark = dark;
    this.pal = PALETTES[dark ? 'dark' : 'light'];
    this.applyPalette();
    if (!this.running) this.renderOnce();
  }

  resize(width: number, height: number): void {
    this.width = Math.max(1, width);
    this.height = Math.max(1, height);
    this.renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    if (!this.running) this.renderOnce();
  }

  setActive(active: boolean): void {
    if (active && this.lowPower) return;
    if (active === this.running || this.disposed) return;
    this.running = active;
    if (active) {
      this.last = performance.now();
      const loop = () => {
        if (!this.running) return;
        this.frame();
        this.raf = requestAnimationFrame(loop);
      };
      this.raf = requestAnimationFrame(loop);
    } else cancelAnimationFrame(this.raf);
  }

  renderOnce(): void {
    if (!this.disposed) this.frame(true);
  }

  dispose(): void {
    this.disposed = true;
    this.running = false;
    cancelAnimationFrame(this.raf);
    for (const scene of [this.ridge, this.void, this.overlay]) {
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        m.geometry?.dispose?.();
        const mats = Array.isArray(m.material) ? m.material : m.material ? [m.material] : [];
        for (const mat of mats) {
          for (const v of Object.values(mat)) if (v instanceof THREE.Texture) v.dispose();
          mat.dispose();
        }
      });
    }
    this.envTarget?.dispose();
    this.renderer.dispose();
  }

  // ---------------------------------------------------------------------------------------- building: the mountain

  private buildEnvironment() {
    // Soft reflections from an overcast sky over snow: enough to read as ice, never glossy.
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const env = new THREE.Scene();
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(50, 24, 12),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'varying vec3 vDir; void main(){ float h = clamp(vDir.y * 0.5 + 0.5, 0.0, 1.0); gl_FragColor = vec4(mix(vec3(0.55,0.6,0.66), vec3(0.95,0.97,1.0), pow(h, 0.8)), 1.0); }',
      }),
    );
    env.add(dome);
    // Small and unblurred: the reflections only need to suggest an overcast sky, and a large
    // prefiltered map is slow to make on weak graphics hardware.
    this.envTarget = pmrem.fromScene(env, 0, 0.1, 100, { size: 64 });
    this.ridge.environment = this.envTarget.texture;
    this.void.environment = this.envTarget.texture;
    this.ridge.environmentIntensity = 0.55;
    this.void.environmentIntensity = 0.9;
    dome.geometry.dispose();
    dome.material.dispose();
    pmrem.dispose();
  }

  private groundHeight(x: number, z: number): number {
    const { fbm } = this.noise;
    const r = Math.hypot(x, z);
    // Where the rows lie the slope is smoother, so they read as laid rather than strewn.
    const rows = smooth(3, 0, Math.max(ROWS.x0 - x, x - ROWS.x1, ROWS.z1 - z - 1, z - ROWS.z0 - 1, 0));
    let h = fbm(x * 0.13, z * 0.13, 4) * 1.3 * (1 - rows * 0.6) + fbm(x * 0.55 + 9, z * 0.55, 2) * 0.14 * (1 - rows * 0.8);
    const mx = x - MOUNTAIN.x;
    const mz = z - MOUNTAIN.z;
    h += MOUNTAIN.h * Math.exp(-(mx * mx) / MOUNTAIN.sx - (mz * mz) / MOUNTAIN.sz); // the face the avalanche comes down
    if (z > 0) h -= smooth(2.6, 11, z) * 1.5 * smooth(0, 6, 10 - Math.abs(x)); // falls away towards the viewer
    const ridged = 1 - Math.abs(fbm(x * 0.03 + 3.1, z * 0.03 - 7.7, 5) * 1.6);
    h += ridged * ridged * 17 * smooth(26, 64, r) * (z < 8 ? 1 : 0.35); // a range behind, lower in front
    return h;
  }

  private buildRidge() {
    const seg = this.opts.compact ? 130 : 170;
    const geo = new THREE.PlaneGeometry(2, 2, seg, seg);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.getAttribute('position') as THREE.BufferAttribute;
    // Finer near the mountain face, coarser far away: the grid is stretched with distance.
    for (let i = 0; i < pos.count; i++) {
      const u = pos.getX(i);
      const v = pos.getZ(i);
      const x = Math.sign(u) * Math.pow(Math.abs(u), 1.9) * 150;
      const z = Math.sign(v) * Math.pow(Math.abs(v), 1.9) * 150 - 12;
      pos.setXYZ(i, x, this.groundHeight(x, z), z);
    }
    geo.computeVertexNormals();
    // Two sets of greys: the face scoured by the avalanche (dark, streaked down the fall line) and
    // fresh snow once it has settled (bright, only the steepest ground a little darker).
    const nrm = geo.getAttribute('normal') as THREE.BufferAttribute;
    const scoured = new Float32Array(pos.count * 3);
    const fresh = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const slope = 1 - nrm.getY(i);
      const grain = this.noise.fbm(x * 0.9, z * 0.9, 3);
      const streak = this.noise.fbm(x * 1.6, z * 0.12 + 40, 3);
      const face = Math.exp(-((x - MOUNTAIN.x) ** 2) / 300 - ((z - MOUNTAIN.z + 8) ** 2) / 260);
      const a = clamp01(0.84 - slope * 0.9 + grain * 0.34 - face * (0.16 + streak * 0.5));
      const b = clamp01(0.97 - slope * 0.3 + grain * 0.1);
      scoured.set([a, a, a * 1.01], i * 3);
      fresh.set([b, b, b * 1.012], i * 3);
    }
    geo.setAttribute('color', new THREE.BufferAttribute(scoured, 3));
    geo.setAttribute('aFresh', new THREE.BufferAttribute(fresh, 3));
    const bump = this.opts.compact ? null : this.noiseTexture(192, 6, 4);
    bump?.repeat.set(70, 70);
    // Lambert: snow is matte, and it's the largest surface on screen, so it's kept cheap.
    const mat = new THREE.MeshLambertMaterial({ vertexColors: true, bumpMap: bump, bumpScale: 1.4 });
    const uSnow = this.snowUniform;
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uSnow = uSnow;
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec3 aFresh;\nvarying vec3 vFresh;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvFresh = aFresh;');
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>', '#include <common>\nuniform float uSnow;\nvarying vec3 vFresh;')
        .replace('#include <color_fragment>', '#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\ndiffuseColor.rgb *= mix(vColor.rgb, vFresh, uSnow);\n#endif');
    };
    this.terrain = new THREE.Mesh(geo, mat);
    this.terrain.receiveShadow = true;
    this.ridge.add(this.terrain);

    this.sky = new THREE.Mesh(
      new THREE.SphereGeometry(300, 32, 16),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: { uTop: { value: new THREE.Color() }, uHorizon: { value: new THREE.Color() } },
        vertexShader: 'varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'uniform vec3 uTop; uniform vec3 uHorizon; varying vec3 vDir; void main(){ float h = clamp(vDir.y, 0.0, 1.0); gl_FragColor = vec4(mix(uHorizon, uTop, pow(h, 0.55)), 1.0);\n#include <colorspace_fragment>\n}',
      }),
    );
    this.ridge.add(this.sky);

    this.hemi = new THREE.HemisphereLight('#ffffff', '#666666', 1.1);
    this.key = new THREE.DirectionalLight('#ffffff', 1.6);
    this.key.position.set(-10, 22, 2);
    this.key.target.position.set(0, 3.5, -13);
    if (!this.opts.compact) {
      this.key.castShadow = true;
      this.key.shadow.mapSize.set(1024, 1024);
      const cam = this.key.shadow.camera;
      cam.left = -11;
      cam.right = 11;
      cam.top = 11;
      cam.bottom = -11;
      cam.near = 4;
      cam.far = 60;
      this.key.shadow.bias = -0.0006;
      this.key.shadow.normalBias = 0.03;
      this.key.shadow.radius = 3;
    }
    this.ridge.add(this.hemi, this.key, this.key.target);
  }

  /** Tileable grey noise, for the snow's grain and the mist. */
  private noiseTexture(size: number, freq: number, octaves: number, alpha = false): THREE.CanvasTexture {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const g = c.getContext('2d');
    if (g) {
      const img = g.createImageData(size, size);
      const n = makeNoise(alpha ? 23 : 5);
      for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
          // Tile by blending the four offsets.
          const fx = x / size;
          const fy = y / size;
          const f = (a: number, b: number) => n.fbm(a * freq, b * freq, octaves);
          const v = lerp(lerp(f(fx, fy), f(fx - 1, fy), fx), lerp(f(fx, fy - 1), f(fx - 1, fy - 1), fx), fy);
          const i = (y * size + x) * 4;
          if (alpha) {
            const d = Math.hypot(fx - 0.5, (fy - 0.5) * 2.2) * 2;
            const a = clamp01((0.55 + v * 1.6) * (1 - smooth(0.35, 1, d)));
            img.data.set([255, 255, 255, a * 255], i);
          } else {
            const b = clamp01(0.5 + v * 1.4) * 255;
            img.data.set([b, b, b, 255], i);
          }
        }
      }
      g.putImageData(img, 0, 0);
    }
    const tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = alpha ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
    return tex;
  }

  /**
   * The avalanche: a stream from high on the face, bending down towards the viewer, and the rows
   * it settles into on the lower slope, lowest rows first.
   */
  private buildAvalanche() {
    const c = this.opts.compact;
    const cfg = c ? BLOCKS.compact : BLOCKS.desktop;
    const rows = Math.ceil(cfg.count / cfg.cols);
    const sx = (ROWS.x1 - ROWS.x0) / cfg.cols;
    const along = Math.hypot(ROWS.z1 - ROWS.z0, this.groundHeight(0, ROWS.z1) - this.groundHeight(0, ROWS.z0)) / Math.max(1, rows - 1);
    this.avalanche = new Avalanche({
      count: cfg.count,
      keys: this.opts.blockKeys,
      ground: (x, z) => this.groundHeight(x, z),
      path: [new THREE.Vector2(-15, -38), new THREE.Vector2(8, -21), new THREE.Vector2(1.5, -3.5)],
      width: [1.8, 6.2],
      rows: { ...ROWS, cols: cfg.cols },
      block: new THREE.Vector3(sx * 0.9, 0.3, Math.min(0.95, along * 0.84)),
      powder: cfg.powder,
      compact: c,
      pixelRatio: this.renderer.getPixelRatio(),
      seed: 29,
      bounce: 1.5,
    });
    this.ridge.add(this.avalanche.group);
  }

  private buildMist() {
    const tex = this.noiseTexture(128, 3, 4, true);
    const n = this.opts.compact ? 5 : 8;
    for (let i = 0; i < n; i++) {
      const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.4, depthWrite: false, color: '#ffffff' });
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), mat);
      const d = 30 + this.rand() * 36;
      m.scale.set(30 + this.rand() * 30, 6 + this.rand() * 6, 1);
      m.position.set((this.rand() - 0.5) * 60, 9 + this.rand() * 9, -d);
      m.userData.drift = (this.rand() - 0.5) * 0.5;
      this.mist.push(m);
      this.ridge.add(m);
    }
  }

  private buildSnow(scene: THREE.Scene, count: number, center: THREE.Vector3, size: THREE.Vector3) {
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos.set([(this.rand() - 0.5) * size.x, (this.rand() - 0.5) * size.y, (this.rand() - 0.5) * size.z], i * 3);
      seed[i] = this.rand();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: { uTime: { value: 0 }, uHeight: { value: size.y }, uColor: { value: new THREE.Color('#ffffff') }, uScale: { value: this.renderer.getPixelRatio() * 60 } },
      vertexShader: `
        uniform float uTime; uniform float uHeight; uniform float uScale;
        attribute float aSeed; varying float vA;
        void main(){
          vec3 p = position;
          p.y = mod(p.y + uHeight * 0.5 - uTime * (0.18 + aSeed * 0.25), uHeight) - uHeight * 0.5;
          p.x += sin(uTime * 0.4 + aSeed * 40.0) * 0.25;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          // Flakes right in front of the lens would cover the screen: keep them small, and fade them.
          gl_PointSize = min(uScale * (0.35 + aSeed * 0.45) / -mv.z, uScale * 0.06);
          vA = (0.35 + aSeed * 0.5) * smoothstep(0.8, 2.5, -mv.z);
        }`,
      fragmentShader: `
        uniform vec3 uColor; varying float vA;
        void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; gl_FragColor = vec4(uColor, smoothstep(0.5, 0.0, d) * vA);
        #include <colorspace_fragment>
        }`,
    });
    const pts = new THREE.Points(geo, mat);
    pts.position.copy(center);
    pts.frustumCulled = false;
    scene.add(pts);
    return pts;
  }

  // ---------------------------------------------------------------------------------------- building: the void

  private buildVoid() {
    const hemi = new THREE.HemisphereLight('#ffffff', '#5d6773', 0.9);
    const key = new THREE.DirectionalLight('#ffffff', 2.2);
    key.position.set(-4, 6, 8);
    const rim = new THREE.DirectionalLight('#dfefff', 1.1);
    rim.position.set(5, -2, -6);
    this.void.add(hemi, key, rim);
  }

  private buildCrystals() {
    this.crystalMat = new THREE.MeshPhysicalMaterial({
      color: '#ffffff',
      roughness: 0.3,
      metalness: 0,
      clearcoat: 0.7,
      clearcoatRoughness: 0.3,
      flatShading: true,
      transparent: true,
      opacity: 0.93,
      envMapIntensity: 1.2,
    });
    this.glyphMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.35, metalness: 0, emissive: '#ffffff', emissiveIntensity: 0.22 });
    const glowTex = this.radialTexture();
    const scale = this.opts.compact ? 0.5 : 0.74;
    const xs = [0.15, -0.25, 0.3, -0.2, 0.1];
    this.opts.crystals.forEach((glyph, i) => {
      const n = makeNoise(31 + i * 7);
      const geo = new THREE.BoxGeometry(2.1, 2.6, 1.3, 8, 10, 5);
      const p = geo.getAttribute('position') as THREE.BufferAttribute;
      for (let k = 0; k < p.count; k++) {
        const x = p.getX(k);
        const y = p.getY(k);
        const z = p.getZ(k);
        const e = Math.max(Math.abs(x) / 1.05, Math.abs(y) / 1.3);
        const jag = n.fbm(x * 1.3 + 5, y * 1.3 + z, 3);
        const ragged = 1 + jag * 0.42 * Math.pow(e, 3);
        const front = z > 0 && e < 0.62 ? 0.25 : 1; // a flatter face where the symbol sits
        p.setXYZ(
          k,
          x * ragged + n.noise(y * 2.1, z * 2) * 0.16 * e * e,
          y * ragged + n.noise(x * 2.3, z * 2 + 4) * 0.16 * e * e,
          z * (1 - 0.3 * Math.pow(e, 2)) + jag * 0.34 * front * (0.4 + e),
        );
      }
      geo.computeVertexNormals();
      const body = new THREE.Mesh(geo, this.crystalMat);
      const glyphGeo = new THREE.ExtrudeGeometry(glyphShapes(glyph), { depth: 0.12, bevelEnabled: true, bevelThickness: 0.035, bevelSize: 0.03, bevelSegments: 2, curveSegments: 20 });
      const g = new THREE.Mesh(glyphGeo, this.glyphMat);
      g.position.z = 0.56;
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: '#ffffff', transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending }));
      halo.scale.set(5.2, 5.2, 1);
      halo.position.z = -0.9;
      const group = new THREE.Group();
      group.add(halo, body, g);
      group.scale.setScalar(scale);
      group.position.set(this.opts.compact ? 0 : xs[i % xs.length], -i * SPACING, 0);
      group.userData.index = i;
      body.userData.index = i;
      g.userData.index = i;
      this.void.add(group);
      this.crystals.push({ group, body, glow: halo, phase: i * 1.7, hover: 0 });
    });
  }

  private radialTexture(): THREE.CanvasTexture {
    const c = document.createElement('canvas');
    c.width = c.height = 128;
    const g = c.getContext('2d');
    if (g) {
      const grad = g.createRadialGradient(64, 64, 2, 64, 64, 62);
      grad.addColorStop(0, 'rgba(255,255,255,0.9)');
      grad.addColorStop(0.35, 'rgba(255,255,255,0.28)');
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = grad;
      g.fillRect(0, 0, 128, 128);
    }
    return new THREE.CanvasTexture(c);
  }

  private buildPlatform() {
    const y = this.platformY;
    this.platformMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.62, metalness: 0.05, bumpMap: this.noiseTexture(128, 9, 3), bumpScale: 0.6 });
    const disk = new THREE.Mesh(new THREE.CylinderGeometry(7, 7.4, 0.8, 128, 1), this.platformMat);
    disk.position.y = -0.4;
    const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.8, 0.28, 96, 1), this.platformMat);
    pedestal.position.y = 0.14;
    this.platform.add(disk, pedestal);
    for (const [r, t] of [
      [1.95, 0.018],
      [2.9, 0.012],
      [3.9, 0.02],
      [5.1, 0.012],
      [6.4, 0.03],
    ] as const) {
      const mat = new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.85 });
      const ring = new THREE.Mesh(new THREE.TorusGeometry(r, t, 6, 160), mat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.02;
      this.ringMats.push(mat);
      this.platform.add(ring);
    }
    const haloMat = new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.95 });
    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.9, 0.05, 10, 160), haloMat);
    halo.rotation.x = Math.PI / 2;
    halo.position.y = 4.5;
    this.ringMats.push(haloMat);
    this.platform.add(halo);
    const lamp = new THREE.PointLight('#ffffff', 9, 12, 1.4);
    lamp.position.y = 4.6;
    this.platform.add(lamp);
    this.platform.position.y = y;
    this.void.add(this.platform);
  }

  private buildParticles() {
    const count = this.opts.compact ? PARTICLES.compact : PARTICLES.desktop;
    const pos = new Float32Array(count * 3);
    const seed = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos.set([(this.rand() - 0.5) * 4, (this.rand() - 0.5) * 4, (this.rand() - 0.5) * 4], i * 3);
      seed[i] = this.rand();
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: { uColor: { value: new THREE.Color() }, uScale: { value: this.renderer.getPixelRatio() * (this.opts.compact ? 22 : 24) }, uTime: { value: 0 } },
      vertexShader: `
        uniform float uScale; uniform float uTime; attribute float aSeed; varying float vA;
        void main(){
          vec3 p = position + 0.012 * vec3(sin(uTime * 1.3 + aSeed * 60.0), cos(uTime * 1.1 + aSeed * 40.0), sin(uTime * 0.9 + aSeed * 20.0));
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = min(uScale * (0.55 + fract(aSeed * 7.13) * 0.7) / -mv.z, uScale * 0.12);
          vA = 0.55 + fract(aSeed * 3.7) * 0.45;
        }`,
      fragmentShader: `
        uniform vec3 uColor; varying float vA;
        void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; gl_FragColor = vec4(uColor, smoothstep(0.5, 0.12, d) * vA);
        #include <colorspace_fragment>
        }`,
    });
    this.particles = new THREE.Points(geo, mat);
    this.particles.frustumCulled = false;
    this.particles.position.set(0, this.platformY + 2.1, 0);
    this.void.add(this.particles);
    // Shapes are sampled from drawings; Flurry's once its portrait has loaded.
    this.targets = this.opts.shapes.map((s) => this.sampleShape(s, count));
    const fi = this.opts.shapes.indexOf('flurry');
    if (fi >= 0 && this.opts.flurrySrc) {
      const img = new Image();
      img.decoding = 'async';
      img.onload = () => {
        if (this.disposed) return;
        this.targets[fi] = this.sampleShape('flurry', count, img);
        if (this.shape === fi) {
          this.shape = -1;
          this.setShape(fi);
        }
      };
      img.src = this.opts.flurrySrc;
    }
    const first = ((this.shape % this.targets.length) + this.targets.length) % this.targets.length;
    this.shape = first;
    this.particles.geometry.getAttribute('position').array.set(this.targets[first]);
  }

  /** Draws a shape on a small canvas and scatters points over it, a little depth added. */
  private sampleShape(kind: LoftShape, count: number, img?: HTMLImageElement): Float32Array {
    const N = 180;
    const c = document.createElement('canvas');
    c.width = c.height = N;
    const g = c.getContext('2d', { willReadFrequently: true });
    const out = new Float32Array(count * 3);
    if (!g) return out;
    g.fillStyle = '#fff';
    g.strokeStyle = '#fff';
    g.lineCap = 'round';
    g.lineJoin = 'round';
    const u = N / 32;
    switch (kind) {
      case 'mountain':
        // A mountain with its snow laid in rows: the avalanche, disciplined.
        g.beginPath();
        [[2, 27], [11.5, 8], [15, 13.5], [19.5, 6], [30, 27]].forEach(([x, y], i) => (i ? g.lineTo(x * u, y * u) : g.moveTo(x * u, y * u)));
        g.closePath();
        g.fill();
        g.globalCompositeOperation = 'destination-out';
        for (const y of [15.5, 19.2, 22.9]) g.fillRect(0, y * u, N, 1.1 * u);
        g.globalCompositeOperation = 'source-over';
        break;
      case 'plus':
        g.lineWidth = 5 * u;
        g.beginPath();
        g.moveTo(16 * u, 6 * u);
        g.lineTo(16 * u, 26 * u);
        g.moveTo(6 * u, 16 * u);
        g.lineTo(26 * u, 16 * u);
        g.stroke();
        break;
      case 'login':
        g.lineWidth = 3.2 * u;
        g.beginPath();
        g.moveTo(17 * u, 6 * u);
        g.lineTo(26 * u, 6 * u);
        g.lineTo(26 * u, 26 * u);
        g.lineTo(17 * u, 26 * u);
        g.moveTo(5 * u, 16 * u);
        g.lineTo(19 * u, 16 * u);
        g.moveTo(14 * u, 11 * u);
        g.lineTo(19 * u, 16 * u);
        g.lineTo(14 * u, 21 * u);
        g.stroke();
        break;
      case 'book':
        g.lineWidth = 2.6 * u;
        g.beginPath();
        g.moveTo(16 * u, 9 * u);
        g.quadraticCurveTo(10 * u, 6 * u, 4 * u, 7.5 * u);
        g.lineTo(4 * u, 25 * u);
        g.quadraticCurveTo(10 * u, 23.5 * u, 16 * u, 26 * u);
        g.quadraticCurveTo(22 * u, 23.5 * u, 28 * u, 25 * u);
        g.lineTo(28 * u, 7.5 * u);
        g.quadraticCurveTo(22 * u, 6 * u, 16 * u, 9 * u);
        g.lineTo(16 * u, 26 * u);
        g.stroke();
        break;
      case 'flake':
        g.lineWidth = 2.6 * u;
        g.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
          const [cx, cy] = [16 * u, 16 * u];
          g.moveTo(cx, cy);
          g.lineTo(cx + Math.cos(a) * 11 * u, cy + Math.sin(a) * 11 * u);
          for (const side of [-1, 1]) {
            const b = a + side * 0.7;
            const [bx, by] = [cx + Math.cos(a) * 6.5 * u, cy + Math.sin(a) * 6.5 * u];
            g.moveTo(bx, by);
            g.lineTo(bx + Math.cos(b) * 3.8 * u, by + Math.sin(b) * 3.8 * u);
          }
        }
        g.stroke();
        break;
      case 'flurry':
        if (img && img.naturalWidth) {
          const s = Math.min(N / img.naturalWidth, N / img.naturalHeight) * 0.96;
          const w = img.naturalWidth * s;
          const h = img.naturalHeight * s;
          g.drawImage(img, (N - w) / 2, (N - h) / 2, w, h);
        } else return this.sampleShape('flake', count);
        break;
    }
    const data = g.getImageData(0, 0, N, N).data;
    const pts: number[] = [];
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const i = (y * N + x) * 4;
        if (data[i + 3] > 110 && (kind !== 'flurry' || data[i] + data[i + 1] + data[i + 2] > 120)) pts.push(x, y);
      }
    }
    const size = kind === 'flurry' ? 3.3 : 2.9;
    if (!pts.length) return out;
    for (let i = 0; i < count; i++) {
      const j = Math.floor(this.rand() * (pts.length / 2)) * 2;
      const x = ((pts[j] + this.rand()) / N - 0.5) * size;
      const y = (0.5 - (pts[j + 1] + this.rand()) / N) * size;
      out.set([x, y, (this.rand() - 0.5) * (kind === 'flurry' ? 0.55 : 0.32)], i * 3);
    }
    return out;
  }

  private applyPalette() {
    const p = this.pal;
    this.renderer.toneMappingExposure = p.exposure;
    this.ridge.background = new THREE.Color(p.fog);
    this.ridge.fog = new THREE.FogExp2(p.fog, this.opts.compact ? 0.013 : 0.016);
    this.sky.material.uniforms.uTop.value.set(p.skyTop);
    this.sky.material.uniforms.uHorizon.value.set(p.skyHorizon);
    this.terrain.material.color.set(p.snow);
    this.hemi.color.set(p.hemiSky);
    this.hemi.groundColor.set(p.hemiGround);
    this.key.intensity = p.key;
    this.avalanche.setPalette({ block: p.block, seam: p.seam, seamStrength: p.seamStrength, powder: p.powder, warm: this.opts.dark ? '#f0c98f' : '#c98a3a' });
    for (const m of this.mist) m.material.color.set(this.opts.dark ? '#3a4552' : '#ffffff');
    this.snowRidge.material.uniforms.uColor.value.set(p.snowflakes);
    this.whiteout.material.color.set(this.opts.dark ? '#dfe8f0' : '#ffffff');
    if (!this.voidBuilt) return;
    this.void.background = new THREE.Color(p.voidBg);
    this.void.fog = new THREE.Fog(p.voidBg, 9, 34);
    this.crystalMat.color.set(p.crystal);
    this.glyphMat.color.set(p.glyph);
    this.glyphMat.emissive.set(p.glyph);
    this.platformMat.color.set(p.platform);
    for (const m of this.ringMats) m.color.set(p.ring);
    this.particles.material.uniforms.uColor.value.set(p.particles);
    this.snowVoid.material.uniforms.uColor.value.set(p.snowflakes);
    for (const c of this.crystals) c.glow.material.opacity = this.opts.dark ? 0.28 : 0.55;
  }

  // ---------------------------------------------------------------------------------------- per frame

  private pick() {
    this.raycaster.setFromCamera(this.pointer, this.camera);
    let block = -1;
    let crystal = -1;
    let point: THREE.Vector3 | null = null;
    if (this.pointerIn) {
      if (this.shown < 1.2) {
        const hit = this.avalanche.pick(this.raycaster);
        if (hit) {
          block = hit.index;
          point = hit.point;
        }
      } else if (this.voidBuilt && this.shown > 1.6 && this.shown < 6.4) {
        const hit = this.raycaster.intersectObjects(
          this.crystals.map((c) => c.body),
          false,
        )[0];
        if (hit) crystal = hit.object.userData.index as number;
      }
    }
    // Lift the blocks around the point under the pointer.
    if (point || this.hoverBlock >= 0) this.avalanche.hoverAt(point, this.opts.compact ? 1.2 : 1.05);
    if (block >= 0 && this.hoverBlock < 0) this.opts.onBlockTouch?.();
    this.hoverBlock = block;
    this.hoverCrystal = crystal;
    const hovering = block >= 0 || crystal >= 0;
    if (hovering !== this.hovering) {
      this.hovering = hovering;
      this.opts.onHoverChange?.(hovering);
    }
  }

  private frame(still = false) {
    const now = performance.now();
    const raw = now - (this.last || now);
    const dt = Math.min(0.05, Math.max(0, raw / 1000));
    this.last = now;
    if (!still) this.adapt(raw);
    const motion = !this.opts.reducedMotion && !still;
    if (motion) this.time += dt;
    const target = this.opts.reducedMotion ? Math.round(this.s) : this.s;
    if (!motion) this.shown = target;
    else this.shown += (target - this.shown) * Math.min(1, dt * 5);
    const s = this.shown;
    if (motion) this.pointerSmooth.lerp(this.pointer, Math.min(1, dt * 2.5));
    else this.pointerSmooth.copy(this.pointer);
    this.pick();

    const onRidge = s < 1.75;
    if (!onRidge) this.buildVoidParts();
    if (onRidge) this.ridgeFrame(s, dt, motion);
    else this.voidFrame(s, dt, motion);

    // White-out while passing into the light.
    const w = smooth(1.25, 1.75, s) * (1 - smooth(1.75, 2.2, s));
    this.whiteout.material.opacity = w;

    this.renderer.render(onRidge ? this.ridge : this.void, this.camera);
    if (w > 0.001) {
      this.renderer.autoClear = false;
      this.renderer.clearDepth();
      this.renderer.render(this.overlay, this.overlayCam);
      this.renderer.autoClear = true;
    }
    if (!this.ready) {
      this.ready = true;
      this.opts.onReady?.();
    }
  }

  private adapt(ms: number) {
    this.frameAvg = this.frameAvg * 0.9 + ms * 0.1;
    this.slowFrames = this.frameAvg > 34 ? this.slowFrames + 1 : 0;
    let next = this.ratio;
    if (this.frameAvg > 90 && this.slowFrames > 3 && this.ratio > 0.5) next = 0.5;
    else if (this.slowFrames > 12 && this.ratio > 0.5) next = Math.max(0.5, this.ratio * 0.8);
    else if (this.frameAvg < 18 && this.ratio < this.maxRatio) next = Math.min(this.maxRatio, this.ratio * 1.05);
    if (Math.abs(next - this.ratio) > 0.01) {
      this.ratio = next;
      this.slowFrames = 0;
      this.renderer.setPixelRatio(next);
      this.renderer.setSize(this.width, this.height, false);
    } else if (this.ratio <= 0.5 && this.frameAvg > 120 && this.slowFrames > 6) {
      this.lowPower = true;
      this.setActive(false);
    }
  }

  private ridgeFrame(s: number, dt: number, motion: boolean) {
    const c = this.opts.compact;
    const px = this.pointerSmooth.x;
    const py = this.pointerSmooth.y;
    // Arrive facing the mountain, drift a little closer as the snow settles, then climb the
    // slope into the cloud.
    const a = clamp01(s);
    const b = smooth(1, 1.75, s);
    // Phones stand further back and look a little higher, so the stream stays below the heading.
    const start = c ? new THREE.Vector3(1.4, 4.6, 24) : new THREE.Vector3(3.2, 3.4, 12.5);
    const near = c ? new THREE.Vector3(0.9, 5.2, 20.5) : new THREE.Vector3(1.8, 4.4, 9.5);
    const into = new THREE.Vector3(-0.8, 13.5, -15);
    const pos = start.clone().lerp(near, smooth(0, 1, a)).lerp(into, b);
    const look = (c ? new THREE.Vector3(-0.2, 6.6, -14) : new THREE.Vector3(-0.6, 4.6, -14)).lerp(new THREE.Vector3(-1.5, 15.5, -34), b);
    pos.x += px * 0.5 * (1 - b);
    pos.y += py * 0.25 * (1 - b);
    this.camera.position.copy(pos);
    this.camera.lookAt(look);
    this.camera.fov = FOV;
    this.camera.updateProjectionMatrix();

    // The avalanche: scattered at the top of the page, disciplined into rows by the time the
    // first screen has scrolled away. The mountain's snow freshens with it.
    const d = smooth(0.04, 0.92, s);
    this.avalanche.setDiscipline(d);
    this.snowUniform.value = smooth(0.35, 1, d);
    const ease = motion ? Math.min(1, dt * 2.6) : 1;
    const lifted = this.avalanche.update(this.time, ease, motion);
    this.placeLabels(lifted);

    // Mist drifts; snow falls.
    if (motion) for (const m of this.mist) m.position.x += (m.userData.drift as number) * dt;
    this.snowRidge.material.uniforms.uTime.value = this.time;
  }

  private placeLabels(lifted: LiftedBlock[]) {
    const els = this.opts.labels;
    lifted.sort((x, y) => y.lift - x.lift);
    // At most one label per little patch of blocks, so they don't overlap.
    const chosen: { key: string; lift: number; sx: number; sy: number }[] = [];
    for (const l of lifted) {
      if (chosen.length >= els.length) break;
      this.tmpV.copy(l.world);
      this.avalanche.group.localToWorld(this.tmpV);
      this.tmpV.project(this.camera);
      if (this.tmpV.z > 1) continue;
      const sx = ((this.tmpV.x + 1) / 2) * this.width;
      const sy = ((1 - this.tmpV.y) / 2) * this.height;
      if (chosen.some((c) => Math.abs(c.sx - sx) < 70 && Math.abs(c.sy - sy) < 30)) continue;
      chosen.push({ key: l.key, lift: l.lift, sx, sy });
    }
    els.forEach((el, n) => {
      const c = chosen[n];
      if (!c) {
        if (el.style.opacity !== '0') el.style.opacity = '0';
        return;
      }
      if (el.textContent !== c.key) el.textContent = c.key;
      el.style.opacity = String(clamp01((c.lift - 0.2) * 3));
      el.style.transform = `translate(${Math.round(c.sx)}px, ${Math.round(c.sy)}px)`;
    });
  }

  private voidFrame(s: number, dt: number, motion: boolean) {
    const c = this.opts.compact;
    const px = this.pointerSmooth.x;
    const py = this.pointerSmooth.y;
    // One crystal per screen (s = 2 … 6), then down onto the platform (s = 6 … 7).
    const idx = s - 2;
    const land = smooth(6, 7, s);
    const camY = -Math.min(idx, 4 + (s > 6 ? (s - 6) * 1.2 : 0)) * SPACING;
    const fly = new THREE.Vector3(px * 0.25, camY + py * 0.12, CAM_DIST);
    const lookFly = new THREE.Vector3(0, camY, 0);
    const py0 = this.platformY;
    const onPlatform = c ? new THREE.Vector3(0, py0 + 4.2, 12.5) : new THREE.Vector3(px * 0.6, py0 + 3.6 + py * 0.2, 9.4);
    const lookPlatform = new THREE.Vector3(0, py0 + 1.9, 0);
    this.camera.position.copy(fly.lerp(onPlatform, land));
    this.camera.lookAt(lookFly.lerp(lookPlatform, land));
    this.camera.updateProjectionMatrix();

    // Crystals turn slowly; the one under the pointer turns towards it and brightens.
    const k = motion ? Math.min(1, dt * 5) : 1;
    this.crystals.forEach((cr, i) => {
      cr.hover += ((i === this.hoverCrystal ? 1 : 0) - cr.hover) * k;
      const t = this.time * 0.35 + cr.phase;
      cr.group.rotation.y = (i % 2 ? -0.42 : 0.38) + Math.sin(t) * 0.3 + (i === this.hoverCrystal ? px * 0.35 : 0) * cr.hover;
      cr.group.rotation.x = -0.16 + Math.sin(t * 0.8) * 0.1 - (i === this.hoverCrystal ? py * 0.25 : 0) * cr.hover;
      cr.group.rotation.z = (i % 2 ? 0.08 : -0.1) + Math.sin(t * 0.6) * 0.05;
      cr.group.position.y = -i * SPACING + Math.sin(t * 1.3) * 0.06;
      cr.glow.material.opacity = (this.opts.dark ? 0.28 : 0.55) + cr.hover * 0.25;
    });

    // Particles gather into the current shape and turn gently.
    const pos = this.particles.geometry.getAttribute('position') as THREE.BufferAttribute;
    if (this.morphT < 1 && this.morphFrom) {
      this.morphT = Math.min(1, this.morphT + dt / 1.6);
      const to = this.targets[this.shape];
      const from = this.morphFrom;
      const arr = pos.array as Float32Array;
      const n = arr.length / 3;
      for (let i = 0; i < n; i++) {
        const delay = ((i * 0.618) % 1) * 0.35;
        const t = clamp01((this.morphT - delay) / 0.65);
        const e = t * t * (3 - 2 * t);
        const swirl = Math.sin(t * Math.PI) * 0.9;
        const a = i * 2.399;
        arr[i * 3] = lerp(from[i * 3], to[i * 3], e) + Math.cos(a) * swirl;
        arr[i * 3 + 1] = lerp(from[i * 3 + 1], to[i * 3 + 1], e) + Math.sin(a * 1.3) * swirl * 0.6;
        arr[i * 3 + 2] = lerp(from[i * 3 + 2], to[i * 3 + 2], e) + Math.sin(a) * swirl;
      }
      pos.needsUpdate = true;
      if (this.morphT >= 1) this.morphFrom = null;
    }
    this.particles.rotation.y = motion ? Math.sin(this.time * 0.25) * 0.45 : 0;
    this.particles.material.uniforms.uTime.value = this.time;
    this.snowVoid.material.uniforms.uTime.value = this.time;
  }
}

export const LOFT_SPACING = SPACING;
