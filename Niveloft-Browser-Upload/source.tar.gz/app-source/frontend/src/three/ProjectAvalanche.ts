/**
 * A project's avalanche, for its Overview: one snow block per task on a small mountain. Approved
 * work has settled into rows on the slope (lowest rows first, in the order it was approved); work
 * waiting for review hovers just above its place; everything else is still tumbling down; a task
 * that holds others up glows amber.
 *
 * It only shows what the records say (the blocks follow task statuses; nothing here changes
 * anything). Rendering stops while it's off screen or the tab is hidden; reduced motion shows the
 * stream standing still.
 */
import * as THREE from 'three';
import { Avalanche, makeNoise } from './snowfield';
import { disposeObject, prefersReducedMotion, readTheme } from './sceneUtils';

export interface AvalancheBlock {
  key: string;
  /** 1 in its row, 0.85 hovering over it, 0 in the stream. */
  target: number;
  warm: number;
}

const FOV = 32;

export class ProjectAvalancheScene {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 200);
  private avalanche: Avalanche | null = null;
  private terrain: THREE.Mesh<THREE.BufferGeometry, THREE.MeshLambertMaterial>;
  private hemi = new THREE.HemisphereLight('#ffffff', '#555555', 1.2);
  private key = new THREE.DirectionalLight('#ffffff', 1.4);
  private noise = makeNoise(11);
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private pointerIn = false;
  private hovered = -1;
  private listed: number | null = null;
  private blocks: AvalancheBlock[] = [];
  private rowsDepth = 3;
  private resizeObserver: ResizeObserver;
  private visibility: IntersectionObserver;
  private onScreen = true;
  private running = false;
  private raf = 0;
  private last = 0;
  private time = 3;
  private width = 1;
  private height = 1;
  private reduced = prefersReducedMotion();
  private disposed = false;

  constructor(
    private container: HTMLElement,
    private onHover: (index: number | null, x: number, y: number) => void,
    private onOpen: (index: number) => void,
  ) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'low-power' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    const el = this.renderer.domElement;
    el.style.display = 'block';
    el.style.width = '100%';
    el.style.height = '100%';
    container.appendChild(el);

    this.terrain = this.buildTerrain();
    this.key.position.set(-8, 14, 6);
    this.key.target.position.set(0, 2, -8);
    this.scene.add(this.terrain, this.hemi, this.key, this.key.target);

    el.addEventListener('pointermove', this.onPointerMove);
    el.addEventListener('pointerleave', this.onPointerLeave);
    el.addEventListener('click', this.onClick);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.visibility = new IntersectionObserver((entries) => {
      this.onScreen = entries.some((e) => e.isIntersecting);
      this.updateRunning();
    });
    this.visibility.observe(container);
    document.addEventListener('visibilitychange', this.updateRunning);
    this.refreshTheme();
    this.resize();
  }

  // ---------------------------------------------------------------------------------------- the mountain

  private ground = (x: number, z: number): number => {
    const { fbm } = this.noise;
    const peak = 6.5 * Math.exp(-((x + 1) ** 2) / 300 - ((z + 22) ** 2) / 90);
    const slope = z < 0 ? Math.min(-z, 20) * 0.22 : -Math.min(z, 6) * 0.1;
    return peak + slope + fbm(x * 0.12, z * 0.12, 3) * 0.7;
  };

  private buildTerrain() {
    const geo = new THREE.PlaneGeometry(70, 60, 110, 90);
    geo.rotateX(-Math.PI / 2);
    geo.translate(0, 0, -16);
    const pos = geo.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) pos.setY(i, this.ground(pos.getX(i), pos.getZ(i)));
    geo.computeVertexNormals();
    const nrm = geo.getAttribute('normal') as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    for (let i = 0; i < pos.count; i++) {
      const c = Math.min(1, Math.max(0, 0.95 - (1 - nrm.getY(i)) * 0.55 + this.noise.fbm(pos.getX(i) * 0.8, pos.getZ(i) * 0.8, 2) * 0.12));
      colors.set([c, c, c * 1.01], i * 3);
    }
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true }));
  }

  // ---------------------------------------------------------------------------------------- API

  /** The blocks, in the order they take their places (settled first). */
  setBlocks(blocks: AvalancheBlock[]): void {
    const rebuild = !this.avalanche || this.avalanche.blocks.length !== blocks.length || blocks.some((b, i) => this.blocks[i]?.key !== b.key);
    this.blocks = blocks;
    if (rebuild) this.build();
    this.avalanche?.setTargets(
      blocks.map((b) => b.target),
      blocks.map((b) => b.warm),
    );
    this.renderOnce();
  }

  /** Lifts the block for a task pointed at in the list. */
  highlight(index: number | null): void {
    this.listed = index;
    this.avalanche?.lift(index);
    if (!this.running) this.renderSettled();
  }

  refreshTheme(): void {
    const t = readTheme();
    const bg = new THREE.Color(t.surface);
    this.scene.background = bg;
    this.scene.fog = new THREE.Fog(bg, 16, 46);
    this.terrain.material.color.set(t.dark ? '#5d6875' : '#c3cbd3');
    this.hemi.color.set(t.dark ? '#b5c2cf' : '#eef2f5');
    this.hemi.groundColor.set(t.dark ? '#1a2027' : '#6b7580');
    this.key.intensity = t.dark ? 0.9 : 1.3;
    this.renderer.toneMappingExposure = t.dark ? 1.05 : 0.95;
    this.avalanche?.setPalette({ block: t.dark ? '#aab5c1' : '#f3f6f8', seam: t.dark ? '#e8f4ff' : '#ffffff', seamStrength: t.dark ? 0.9 : 0.55, powder: t.dark ? '#dbe5ee' : '#ffffff', warm: t.review });
    this.renderOnce();
  }

  dispose(): void {
    this.disposed = true;
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.resizeObserver.disconnect();
    this.visibility.disconnect();
    document.removeEventListener('visibilitychange', this.updateRunning);
    const el = this.renderer.domElement;
    el.removeEventListener('pointermove', this.onPointerMove);
    el.removeEventListener('pointerleave', this.onPointerLeave);
    el.removeEventListener('click', this.onClick);
    disposeObject(this.scene);
    this.renderer.dispose();
    el.remove();
  }

  // ---------------------------------------------------------------------------------------- building

  private build() {
    if (this.avalanche) {
      this.scene.remove(this.avalanche.group);
      disposeObject(this.avalanche.group);
      this.avalanche = null;
    }
    const n = this.blocks.length;
    if (!n) return;
    const cols = Math.max(4, Math.min(16, Math.ceil(Math.sqrt(n * 2.4))));
    const rows = Math.ceil(n / cols);
    const halfW = cols * 0.5;
    const z0 = -3;
    const z1 = z0 - Math.max(1, rows - 1) * 1.05;
    this.rowsDepth = z0 - z1;
    this.avalanche = new Avalanche({
      count: n,
      keys: this.blocks.map((b) => b.key),
      ground: this.ground,
      path: [new THREE.Vector2(-6.5, -17), new THREE.Vector2(4.5, -10.5), new THREE.Vector2(0.5, -1.5)],
      width: [1.2, Math.max(2.5, halfW * 0.7)],
      rows: { x0: -halfW, x1: halfW, z0, z1, cols },
      block: new THREE.Vector3(0.9, 0.3, 0.86),
      powder: Math.min(900, 200 + n * 12),
      compact: true,
      pixelRatio: this.renderer.getPixelRatio(),
      seed: 13,
      bounce: 1.2,
      chunk: 1.5,
    });
    this.scene.add(this.avalanche.group);
    this.refreshTheme();
    this.frameCamera();
  }

  private frameCamera() {
    const n = this.blocks.length;
    const cols = Math.max(4, Math.min(16, Math.ceil(Math.sqrt(Math.max(1, n) * 2.4))));
    const half = cols * 0.5 + 1.5;
    const aspect = this.width / this.height;
    // Far enough back that the rows fit across, looking up the slope so the stream comes down
    // towards you from the top of the picture.
    const fit = half / (Math.tan(THREE.MathUtils.degToRad(FOV / 2)) * aspect);
    const dist = Math.max(18, fit + 5);
    const look = new THREE.Vector3(0, 3.6, -8 - this.rowsDepth / 4);
    this.camera.position.set(look.x + dist * 0.08, look.y + 0.8 + dist * 0.03, look.z + dist);
    this.camera.lookAt(look);
    this.camera.updateProjectionMatrix();
  }

  private resize() {
    const r = this.container.getBoundingClientRect();
    this.width = Math.max(1, r.width);
    this.height = Math.max(1, r.height);
    this.renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    this.frameCamera();
    this.renderOnce();
  }

  // ---------------------------------------------------------------------------------------- frames

  private updateRunning = () => {
    const run = !this.disposed && this.onScreen && !document.hidden && !this.reduced;
    if (run === this.running) return;
    this.running = run;
    if (run) {
      this.last = performance.now();
      const loop = () => {
        if (!this.running) return;
        this.frame(true);
        this.raf = requestAnimationFrame(loop);
      };
      this.raf = requestAnimationFrame(loop);
    } else cancelAnimationFrame(this.raf);
  };

  private renderOnce() {
    if (!this.running && !this.disposed) this.renderSettled();
  }

  /** A still frame with every block where it belongs (reduced motion, off screen, changes). */
  private renderSettled() {
    if (this.disposed) return;
    this.frame(false);
  }

  private frame(motion: boolean) {
    const now = performance.now();
    const dt = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    if (motion) this.time += dt;
    this.pick();
    if (this.avalanche) this.avalanche.update(this.time, motion ? Math.min(1, dt * 3) : 1, motion);
    this.renderer.render(this.scene, this.camera);
  }

  private pick() {
    if (!this.avalanche || !this.pointerIn) {
      if (this.hovered >= 0) {
        this.hovered = -1;
        if (this.listed === null) this.avalanche?.lift(null);
        this.onHover(null, 0, 0);
      }
      return;
    }
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hit = this.avalanche.pick(this.raycaster);
    const index = hit ? hit.index : -1;
    if (index !== this.hovered) {
      this.hovered = index;
      this.avalanche.lift(index >= 0 ? index : this.listed);
      this.renderer.domElement.style.cursor = index >= 0 ? 'pointer' : '';
    }
    if (index >= 0) {
      const p = this.avalanche.positionOf(index);
      if (p) {
        const v = p.clone().project(this.camera);
        const r = this.renderer.domElement.getBoundingClientRect();
        this.onHover(index, r.left + ((v.x + 1) / 2) * r.width, r.top + ((1 - v.y) / 2) * r.height);
      }
    } else this.onHover(null, 0, 0);
  }

  private onPointerMove = (e: PointerEvent) => {
    const r = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.pointerIn = true;
    if (!this.running) this.renderSettled();
  };

  private onPointerLeave = () => {
    this.pointerIn = false;
    if (!this.running) this.renderSettled();
  };

  private onClick = () => {
    if (this.hovered >= 0) this.onOpen(this.hovered);
  };
}

