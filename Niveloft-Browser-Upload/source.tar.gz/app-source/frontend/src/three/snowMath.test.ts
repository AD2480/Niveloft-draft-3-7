import { describe, expect, it } from 'vitest';
import { disciplineAt, disciplineWord, landedShare, landsAt, settleOf, slotOf } from './snowMath';

describe('the avalanche story', () => {
  it('is scattered at the top and in rows after one screen', () => {
    expect(disciplineAt(0)).toBe(0);
    expect(disciplineAt(1)).toBe(1);
    expect(disciplineAt(0.5)).toBeGreaterThan(0.3);
    expect(disciplineAt(0.5)).toBeLessThan(0.7);
    expect(disciplineWord(disciplineAt(0))).toBe('SCATTERED');
    expect(disciplineWord(disciplineAt(0.5))).toBe('SETTLING');
    expect(disciplineWord(disciplineAt(1.2))).toBe('IN ROWS');
  });

  it('only ever moves forward as you scroll down', () => {
    let last = -1;
    for (let s = 0; s <= 1.5; s += 0.01) {
      const d = disciplineAt(s);
      expect(d).toBeGreaterThanOrEqual(last);
      last = d;
    }
  });

  it('lands the lowest rows first, and every block by the end', () => {
    expect(settleOf(0, 0)).toBe(0);
    expect(settleOf(1, 0)).toBe(1);
    expect(settleOf(1, 1)).toBe(1);
    expect(settleOf(0.4, 0)).toBe(1);
    expect(settleOf(0.4, 1)).toBe(0);
    for (let o = 0; o <= 1; o += 0.1) expect(settleOf(1, o)).toBe(1);
    // A block is either in the stream or in its row: never left hanging halfway.
    for (let d = 0; d <= 1; d += 0.05) for (let o = 0; o <= 1; o += 0.05) expect([0, 1]).toContain(settleOf(d, o));
  });

  it('reports the share in rows truthfully for evenly spread landing orders', () => {
    const n = 200;
    const orders = Array.from({ length: n }, (_, i) => i / (n - 1));
    for (const d of [0, 0.2, 0.5, 0.8, 1]) {
      const landed = orders.filter((o) => settleOf(d, o) === 1).length / n;
      expect(Math.abs(landed - landedShare(d))).toBeLessThan(0.02);
    }
    expect(landsAt(0)).toBeGreaterThan(0);
    expect(landsAt(1)).toBeLessThan(1);
  });

  it('lays blocks out row by row', () => {
    expect(slotOf(0, 10, 4)).toEqual({ row: 0, col: 0, rows: 3, order: 0 });
    expect(slotOf(5, 10, 4)).toEqual({ row: 1, col: 1, rows: 3, order: 0.5 });
    expect(slotOf(9, 10, 4).order).toBe(1);
    expect(slotOf(0, 1, 4).order).toBe(0);
  });
});
