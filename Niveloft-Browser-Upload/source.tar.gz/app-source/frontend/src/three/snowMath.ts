/**
 * The snow world's arithmetic, without three.js: the page can use it before the 3D world has
 * loaded, and it's tested on its own.
 */

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** The discipline at which block `order` (0 = first to land … 1 = last) lands in its row. */
export function landsAt(order: number): number {
  return 0.06 + clamp01(order) * 0.88;
}

/**
 * Where block `order` should be when the whole avalanche is disciplined to `d` (0 = scattered,
 * 1 = every block in its row): 0 in the stream, 1 in its row. Blocks land one after another, the
 * lowest rows first; the flight itself is animated over time, so scrolling never leaves a block
 * hanging halfway.
 */
export function settleOf(d: number, order: number): number {
  return d >= landsAt(order) ? 1 : 0;
}

/** The share of blocks in their rows at discipline `d` (landing orders are spread evenly). */
export function landedShare(d: number): number {
  return clamp01((d - 0.06) / 0.88);
}

/** Where block i of n sits in the settled rows: its row, column and landing order. */
export function slotOf(i: number, n: number, cols: number): { row: number; col: number; rows: number; order: number } {
  const c = Math.max(1, cols);
  const rows = Math.max(1, Math.ceil(n / c));
  const row = Math.floor(i / c);
  const col = i % c;
  return { row, col, rows, order: rows > 1 ? row / (rows - 1) : 0 };
}

/**
 * How disciplined the avalanche is at story position `s`: 0 (a scattered stream) at the top of
 * the page, 1 (every block in its row on the mountain) once the first screen has scrolled away.
 */
export function disciplineAt(s: number): number {
  return smooth(0.04, 0.92, s);
}

/** The avalanche's state in words, for the page's readout. */
export function disciplineWord(d: number): 'SCATTERED' | 'SETTLING' | 'IN ROWS' {
  const share = landedShare(d);
  return share <= 0 ? 'SCATTERED' : share < 1 ? 'SETTLING' : 'IN ROWS';
}
