/**
 * Shared pieces of Niveloft's snow world: noise, a few easing helpers, the glowing-seam snow block
 * material, and the Avalanche: blocks of snow (one per task) that tumble down a slope in a loose,
 * scattered stream and, as they're "disciplined", fly into ordered rows lying on the mountain.
 *
 * The front page drives the whole avalanche with one number (how far you've scrolled). A project's
 * Overview drives each block on its own: approved tasks have settled, open ones are still moving.
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { clamp01, lerp, settleOf, slotOf } from './snowMath';

// ------------------------------------------------------------------------------------------ math

export { clamp01, lerp, settleOf, slotOf, smooth } from './snowMath';

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** 2D gradient noise in about [-0.7, 0.7], and fractal sums of it. */
export function makeNoise(seed: number) {
  const rand = mulberry32(seed);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [p[i], p[j]] = [p[j], p[i]];
  }
  const perm = new Uint8Array(512);
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  const G = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
    [0.7071, 0.7071],
    [-0.7071, 0.7071],
    [0.7071, -0.7071],
    [-0.7071, -0.7071],
  ];
  const fade = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
  const noise = (x: number, y: number) => {
    const X = Math.floor(x);
    const Y = Math.floor(y);
    const xf = x - X;
    const yf = y - Y;
    const xi = X & 255;
    const yi = Y & 255;
    const g = (ix: number, iy: number, dx: number, dy: number) => {
      const h = perm[perm[ix] + iy] & 7;
      return G[h][0] * dx + G[h][1] * dy;
    };
    const u = fade(xf);
    const v = fade(yf);
    return lerp(lerp(g(xi, yi, xf, yf), g(xi + 1, yi, xf - 1, yf), u), lerp(g(xi, yi + 1, xf, yf - 1), g(xi + 1, yi + 1, xf - 1, yf - 1), u), v);
  };
  const fbm = (x: number, y: number, octaves: number) => {
    let sum = 0;
    let amp = 0.5;
    let f = 1;
    for (let i = 0; i < octaves; i++) {
      sum += amp * noise(x * f, y * f);
      f *= 2.03;
      amp *= 0.5;
    }
    return sum;
  };
  return { noise, fbm };
}

export type Ground = (x: number, z: number) => number;

/** The ground's normal at (x, z), by finite differences. */
export function groundNormal(ground: Ground, x: number, z: number, out = new THREE.Vector3()): THREE.Vector3 {
  const e = 0.25;
  const dx = (ground(x + e, z) - ground(x - e, z)) / (2 * e);
  const dz = (ground(x, z + e) - ground(x, z - e)) / (2 * e);
  return out.set(-dx, 1, -dz).normalize();
}

// ------------------------------------------------------------------------------------------ material

export interface SeamUniforms {
  uSeam: { value: number };
  uSeamColor: { value: THREE.Color };
  uWarmColor: { value: THREE.Color };
}

/**
 * Snow blocks with glowing seams: light seems to leak along every block's edges. Each instance
 * has a glow (it lights up when lifted) and a warmth (a task that holds others up glows amber).
 * Phones get Lambert shading, which is much cheaper.
 */
export function seamMaterial(compact: boolean, uniforms: SeamUniforms): THREE.MeshStandardMaterial | THREE.MeshLambertMaterial {
  const mat = compact ? new THREE.MeshLambertMaterial({ color: '#ffffff' }) : new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.6, metalness: 0, envMapIntensity: 0.7 });
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uSeam = uniforms.uSeam;
    shader.uniforms.uSeamColor = uniforms.uSeamColor;
    shader.uniforms.uWarmColor = uniforms.uWarmColor;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nattribute float aGlow;\nattribute float aWarm;\nvarying float vGlow;\nvarying float vWarm;\nvarying vec3 vBox;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvBox = position;\nvGlow = aGlow;\nvWarm = aWarm;');
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nuniform float uSeam;\nuniform vec3 uSeamColor;\nuniform vec3 uWarmColor;\nvarying float vGlow;\nvarying float vWarm;\nvarying vec3 vBox;')
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        vec3 q = abs(vBox) * 2.0;
        float qmax = max(q.x, max(q.y, q.z));
        float qmin = min(q.x, min(q.y, q.z));
        float qmid = q.x + q.y + q.z - qmax - qmin;
        float edge = smoothstep(0.84, 0.99, qmid);
        vec3 seam = mix(uSeamColor, uWarmColor, vWarm);
        totalEmissiveRadiance += seam * (edge * (uSeam + vGlow * 1.6 + vWarm * 1.2) + vGlow * 0.42 + vWarm * 0.18);`,
      );
  };
  return mat;
}

// ------------------------------------------------------------------------------------------ the avalanche

export interface AvalancheOptions {
  count: number;
  /** A label per block (task keys), handed out in turn. */
  keys: string[];
  ground: Ground;
  /** The stream's path over the ground in x/z: where it starts (high), bends, and ends (low). */
  path: [THREE.Vector2, THREE.Vector2, THREE.Vector2];
  /** How wide the stream is at its start and its end. */
  width: [number, number];
  /** The settled rows: across x, stacked from z0 (lowest row) to z1 (highest). */
  rows: { x0: number; x1: number; z0: number; z1: number; cols: number };
  /** Block size when settled. */
  block: THREE.Vector3;
  powder: number;
  compact: boolean;
  seed?: number;
  pixelRatio: number;
  /** How far blocks fly up the slope and back down in the scattered stream (world units). */
  bounce?: number;
  /** How big blocks are in the stream, relative to the default rubble (1). */
  chunk?: number;
}

interface Block {
  key: string;
  settledPos: THREE.Vector3;
  settledQuat: THREE.Quaternion;
  settledScale: THREE.Vector3;
  normal: THREE.Vector3;
  order: number;
  phase: number;
  speed: number;
  lateral: number;
  lift: number;
  spinAxis: THREE.Vector3;
  spin: number;
  scatterScale: THREE.Vector3;
  settle: number;
  target: number;
  hover: number;
  hoverTarget: number;
  warm: number;
  pos: THREE.Vector3;
}

export interface LiftedBlock {
  index: number;
  key: string;
  lift: number;
  world: THREE.Vector3;
}

const tmpM = new THREE.Matrix4();
const tmpQ = new THREE.Quaternion();
const tmpQ2 = new THREE.Quaternion();
const tmpV = new THREE.Vector3();
const tmpS = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

export class Avalanche {
  readonly group = new THREE.Group();
  readonly mesh: THREE.InstancedMesh<RoundedBoxGeometry, THREE.MeshStandardMaterial | THREE.MeshLambertMaterial>;
  readonly powder: THREE.Points<THREE.BufferGeometry, THREE.ShaderMaterial>;
  readonly uniforms: SeamUniforms = { uSeam: { value: 0.9 }, uSeamColor: { value: new THREE.Color('#ffffff') }, uWarmColor: { value: new THREE.Color('#e9c99a') } };
  readonly blocks: Block[] = [];
  private glow: THREE.InstancedBufferAttribute;
  private warmAttr: THREE.InstancedBufferAttribute;
  private opts: AvalancheOptions;
  private settledShare = 0;

  constructor(opts: AvalancheOptions) {
    this.opts = opts;
    const rand = mulberry32(opts.seed ?? 29);
    const { count, rows, ground, block } = opts;
    const cols = Math.max(1, Math.min(rows.cols, count));
    const slotsPerRow = cols;
    const nRows = Math.max(1, Math.ceil(count / slotsPerRow));
    const sx = (rows.x1 - rows.x0) / cols;
    for (let i = 0; i < count; i++) {
      const slot = slotOf(i, count, cols);
      // Running bond: every other row is offset by half a block.
      const x = rows.x0 + sx * (slot.col + 0.5 + (slot.row % 2) * 0.5 - 0.25);
      const z = lerp(rows.z0, rows.z1, nRows > 1 ? slot.row / (nRows - 1) : 0.5);
      const normal = groundNormal(ground, x, z);
      const settledQuat = new THREE.Quaternion().setFromUnitVectors(UP, normal);
      const y = ground(x, z) + block.y / 2 + 0.02;
      // Chunks in the stream: broken, uneven, a few big slabs among many small pieces.
      const s = (0.16 + Math.pow(rand(), 1.6) * 0.62) * (opts.chunk ?? 1);
      this.blocks.push({
        key: opts.keys.length ? opts.keys[i % opts.keys.length] : '',
        settledPos: new THREE.Vector3(x, y, z),
        settledQuat,
        settledScale: block.clone(),
        normal,
        order: clamp01(slot.order * 0.85 + rand() * 0.15), // ranked below, so orders are evenly spread
        phase: rand(),
        speed: 0.035 + rand() * 0.045,
        lateral: (rand() - 0.5) * 2,
        lift: 0.15 + Math.pow(rand(), 2) * (opts.bounce ?? 2.2),
        spinAxis: new THREE.Vector3(rand() - 0.5, rand() - 0.5, rand() - 0.5).normalize(),
        spin: (rand() - 0.5) * 3,
        scatterScale: new THREE.Vector3(s * (0.8 + rand() * 1.1), s * (0.45 + rand() * 0.55), s * (0.7 + rand() * 0.9)),
        settle: 0,
        target: 0,
        hover: 0,
        hoverTarget: 0,
        warm: 0,
        pos: new THREE.Vector3(),
      });
    }

    // One segment per rounded edge: blocks are small on screen, and there are hundreds of them.
    // Landing order: lowest rows first with a little shuffle, spread evenly over 0 … 1.
    [...this.blocks].sort((p, q) => p.order - q.order).forEach((b, rank) => (b.order = count > 1 ? rank / (count - 1) : 0));

    const geo = new RoundedBoxGeometry(1, 1, 1, 1, 0.12);
    this.glow = new THREE.InstancedBufferAttribute(new Float32Array(count), 1);
    this.glow.setUsage(THREE.DynamicDrawUsage);
    this.warmAttr = new THREE.InstancedBufferAttribute(new Float32Array(count), 1);
    this.warmAttr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('aGlow', this.glow);
    geo.setAttribute('aWarm', this.warmAttr);
    this.mesh = new THREE.InstancedMesh(geo, seamMaterial(opts.compact, this.uniforms), Math.max(1, count));
    this.mesh.count = count;
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.castShadow = !opts.compact;
    this.mesh.receiveShadow = !opts.compact;
    this.mesh.frustumCulled = false;
    const color = new THREE.Color();
    for (let i = 0; i < count; i++) {
      const shade = 0.9 + rand() * 0.14;
      this.mesh.setColorAt(i, color.setRGB(shade, shade, shade * 1.015));
    }
    this.powder = this.buildPowder(rand);
    this.group.add(this.mesh, this.powder);
  }

  private pathAt(u: number, out: THREE.Vector2, tangent?: THREE.Vector2): THREE.Vector2 {
    const [a, b, c] = this.opts.path;
    const m = 1 - u;
    out.set(m * m * a.x + 2 * m * u * b.x + u * u * c.x, m * m * a.y + 2 * m * u * b.y + u * u * c.y);
    if (tangent) tangent.set(2 * m * (b.x - a.x) + 2 * u * (c.x - b.x), 2 * m * (b.y - a.y) + 2 * u * (c.y - b.y)).normalize();
    return out;
  }

  private buildPowder(rand: () => number) {
    const n = this.opts.powder;
    const phase = new Float32Array(n);
    const lat = new Float32Array(n);
    const lift = new Float32Array(n);
    const seed = new Float32Array(n);
    const settled = new Float32Array(n * 3);
    const { rows, ground } = this.opts;
    for (let i = 0; i < n; i++) {
      phase[i] = rand();
      lat[i] = (rand() - 0.5) * 2;
      lift[i] = Math.pow(rand(), 1.5);
      seed[i] = rand();
      // Settled powder: a dusting over the rows, and a little beyond them.
      const x = lerp(rows.x0 - 1.5, rows.x1 + 1.5, rand());
      const z = lerp(rows.z0 - 1, rows.z1 + 1.5, rand());
      settled.set([x, ground(x, z) + 0.05 + rand() * 0.08, z], i * 3);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(settled.slice(), 3));
    geo.setAttribute('aSettled', new THREE.BufferAttribute(settled, 3));
    geo.setAttribute('aPhase', new THREE.BufferAttribute(phase, 1));
    geo.setAttribute('aLat', new THREE.BufferAttribute(lat, 1));
    geo.setAttribute('aLift', new THREE.BufferAttribute(lift, 1));
    geo.setAttribute('aSeed', new THREE.BufferAttribute(seed, 1));
    // The path, with its ground heights, for the shader (a quadratic Bézier in 3D).
    const [a, b, c] = this.opts.path;
    const p3 = (v: THREE.Vector2) => new THREE.Vector3(v.x, ground(v.x, v.y), v.y);
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uD: { value: 0 },
        uA: { value: p3(a) },
        uB: { value: p3(b) },
        uC: { value: p3(c) },
        uW: { value: new THREE.Vector2(this.opts.width[0], this.opts.width[1]) },
        uColor: { value: new THREE.Color('#ffffff') },
        uScale: { value: this.opts.pixelRatio * 60 },
      },
      vertexShader: `
        uniform float uTime; uniform float uD; uniform vec3 uA; uniform vec3 uB; uniform vec3 uC; uniform vec2 uW; uniform float uScale;
        attribute vec3 aSettled; attribute float aPhase; attribute float aLat; attribute float aLift; attribute float aSeed;
        varying float vA;
        void main(){
          float u = fract(aPhase + uTime * (0.03 + aSeed * 0.04));
          float m = 1.0 - u;
          vec3 p = m * m * uA + 2.0 * m * u * uB + u * u * uC;
          vec3 tg = normalize(2.0 * m * (uB - uA) + 2.0 * u * (uC - uB));
          vec3 side = normalize(vec3(-tg.z, 0.0, tg.x));
          p += side * aLat * mix(uW.x, uW.y, u) * 1.3;
          p.y += aLift * (0.6 + u * 2.6) + sin(uTime * 0.8 + aSeed * 30.0) * 0.18;
          float k = smoothstep(aSeed * 0.55, aSeed * 0.55 + 0.45, uD);
          vec3 pos = mix(p, aSettled, k);
          vec4 mv = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mv;
          // A third of the powder is soft billows round the stream; the rest is fine spray.
          float puff = step(aSeed, 0.22) * (1.0 - k);
          gl_PointSize = min(uScale * mix(0.35 + aSeed * 0.7, 3.0 + aSeed * 4.0, puff) / -mv.z, uScale * mix(0.1, 0.45, puff));
          vA = mix(mix(0.55 * (1.0 - u * 0.3), 0.3, k), 0.1 + u * 0.08, puff) * smoothstep(0.8, 2.5, -mv.z);
        }`,
      fragmentShader: `
        uniform vec3 uColor; varying float vA;
        void main(){ float d = length(gl_PointCoord - 0.5); if (d > 0.5) discard; gl_FragColor = vec4(uColor, smoothstep(0.5, 0.05, d) * vA);
        #include <colorspace_fragment>
        }`,
    });
    const pts = new THREE.Points(geo, mat);
    pts.frustumCulled = false;
    return pts;
  }

  /** The front page: one number for the whole avalanche, blocks landing lowest rows first. */
  setDiscipline(d: number): void {
    for (const b of this.blocks) b.target = settleOf(d, b.order);
    this.powder.material.uniforms.uD.value = clamp01(d);
  }

  /** A project: each block's own target (0 in the stream … 1 in its row) and warmth (holds work up). */
  setTargets(targets: readonly number[], warm?: readonly number[]): void {
    let sum = 0;
    this.blocks.forEach((b, i) => {
      b.target = clamp01(targets[i] ?? 0);
      b.warm = warm?.[i] ?? 0;
      sum += b.target;
    });
    this.settledShare = this.blocks.length ? sum / this.blocks.length : 0;
    this.powder.material.uniforms.uD.value = this.settledShare;
  }

  /** Lifts the blocks near a point (in the group's space), or lets them down. */
  hoverAt(point: THREE.Vector3 | null, radius = 0.95): void {
    for (const b of this.blocks) {
      const d = point ? b.pos.distanceTo(point) : Infinity;
      b.hoverTarget = d < radius ? Math.pow(1 - d / radius, 1.4) : 0;
    }
  }

  /** Lifts one block (pointed at in a list), or lets them all down. */
  lift(index: number | null): void {
    this.blocks.forEach((b, i) => (b.hoverTarget = i === index ? 1 : 0));
  }

  /** Where block i is now, in the group's space. */
  positionOf(index: number): THREE.Vector3 | null {
    return this.blocks[index]?.pos ?? null;
  }

  setPalette(p: { block: string; seam: string; seamStrength: number; powder: string; warm?: string }): void {
    this.mesh.material.color.set(p.block);
    this.uniforms.uSeam.value = p.seamStrength;
    this.uniforms.uSeamColor.value.set(p.seam);
    if (p.warm) this.uniforms.uWarmColor.value.set(p.warm);
    this.powder.material.uniforms.uColor.value.set(p.powder);
  }

  /**
   * Moves every block: the stream at `time`, eased towards its target settle, lifted if hovered.
   * `ease` is how quickly settle follows its target (1 = at once). Returns the lifted blocks.
   */
  update(time: number, ease: number, motion: boolean): LiftedBlock[] {
    const lifted: LiftedBlock[] = [];
    const xz = new THREE.Vector2();
    const tg = new THREE.Vector2();
    const t = motion ? time : 0;
    const w = this.opts.width;
    this.blocks.forEach((b, i) => {
      b.settle += (b.target - b.settle) * ease;
      if (Math.abs(b.target - b.settle) < 1e-4) b.settle = b.target;
      b.hover += (b.hoverTarget - b.hover) * Math.min(1, ease * 1.3);
      if (b.hover < 1e-4) b.hover = 0;
      const k = b.settle;
      if (k >= 1) {
        tmpV.copy(b.settledPos);
        tmpQ.copy(b.settledQuat);
        tmpS.copy(b.settledScale);
      } else {
        // In the stream: along the path, spread sideways, bouncing and tumbling.
        const u = (((b.phase + b.speed * t) % 1) + 1) % 1;
        this.pathAt(u, xz, tg);
        const width = lerp(w[0], w[1], u);
        const x = xz.x - tg.y * b.lateral * width;
        const z = xz.y + tg.x * b.lateral * width;
        const hop = Math.abs(Math.sin(u * Math.PI * 4 + b.phase * 9));
        const y = this.opts.ground(x, z) + 0.12 + b.lift * (0.3 + 0.7 * hop) * (0.5 + u);
        const e = k * k * (3 - 2 * k);
        tmpV.set(x, y, z).lerp(b.settledPos, e);
        tmpV.y += Math.sin(e * Math.PI) * 1.4;
        tmpQ.setFromAxisAngle(b.spinAxis, b.spin * t + b.phase * 10);
        tmpQ.slerp(b.settledQuat, e);
        tmpS.copy(b.scatterScale).lerp(b.settledScale, e);
      }
      if (b.hover > 0) {
        tmpV.addScaledVector(b.normal, b.hover * 0.5);
        tmpQ2.setFromAxisAngle(b.spinAxis, b.hover * 0.45);
        tmpQ.premultiply(tmpQ2);
      }
      b.pos.copy(tmpV);
      tmpM.compose(tmpV, tmpQ, tmpS);
      this.mesh.setMatrixAt(i, tmpM);
      this.glow.setX(i, b.hover);
      this.warmAttr.setX(i, b.warm);
      if (b.hover > 0.2) lifted.push({ index: i, key: b.key, lift: b.hover, world: tmpV.clone() });
    });
    this.mesh.instanceMatrix.needsUpdate = true;
    this.glow.needsUpdate = true;
    this.warmAttr.needsUpdate = true;
    this.powder.material.uniforms.uTime.value = t;
    return lifted;
  }

  /** The block under a ray, and where it was hit (in the group's space). */
  pick(raycaster: THREE.Raycaster): { index: number; point: THREE.Vector3 } | null {
    this.mesh.boundingSphere = null; // blocks move: recompute
    const hit = raycaster.intersectObject(this.mesh, false)[0];
    if (!hit || hit.instanceId === undefined) return null;
    return { index: hit.instanceId, point: this.group.worldToLocal(hit.point.clone()) };
  }

  /** Share of blocks settled (0 … 1). */
  get settled(): number {
    return this.settledShare;
  }
}
