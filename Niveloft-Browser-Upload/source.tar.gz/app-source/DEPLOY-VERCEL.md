# Publish Niveloft using GitHub and Vercel

## Upload through your browser
1. Extract Niveloft-GitHub-Ready.zip on your computer.
2. Open the extracted Niveloft-GitHub-Ready folder.
3. On GitHub, open your repository, then Add file > Upload files.
4. Upload the CONTENTS of the extracted folder, not the ZIP or a .bundle file.
   The repository should show frontend/, backend/, README.md and this guide at its top level.
5. Commit the upload. If GitHub limits a batch, upload the frontend folder first, then the remaining folders separately. For the Vercel demo only frontend/ is required.
6. Remove the obsolete niveloft-update.bundle from the repository if desired; it is not used by the site.

## Vercel settings for the shareable browser demo
- Framework: Vite
- Root Directory: frontend
- Build Command: npm run build
- Output Directory: dist
- Install Command: npm install
- Environment variable key: VITE_USE_MOCK_API
- Environment variable value: true
- Use a supported Node version satisfying frontend/package.json (>=20.19).

The frontend/vercel.json preserves the application's existing routing and security headers and now explicitly declares the build settings.
Click Deploy. After it succeeds, click Visit and share the resulting URL.

## Demo limitations
This mode runs without a backend. Demo accounts and changes are stored in each visitor's browser. Team data is not shared across devices, and real account emails and server-backed AI features require the backend. The backend source is included, but Vercel's frontend deployment does not deploy the Spring Boot server or database.

For a real backend deployment, follow README.md and frontend/.env.example. Set VITE_USE_MOCK_API=false and VITE_API_BASE_URL to the deployed HTTPS backend API URL, including /api. Never put private keys or passwords in VITE_ variables.

## What was prepared
- Preserved frontend and backend source, tests, public assets, documentation and sample configuration.
- Strengthened .gitignore for environment files, Vercel credentials, archives and private key files.
- Preserved .env.backend because it contains only non-secret local development switches.
- Added explicit Vercel build settings and this browser-based upload guide.
- This package uses the uploaded ZIP as its source. The separate incremental bundle was not applied.
- Verified npm dependency installation and npm run build successfully (TypeScript + Vite). Added package-lock.json to preserve tested dependency versions. The build reported non-fatal chunk-size and mixed-import warnings. Set VITE_SITE_URL after deployment if canonical links need an explicit domain.
- This was a build check, not a full browser or backend functional test.
